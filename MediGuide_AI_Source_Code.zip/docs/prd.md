# Requirements Document

## 1. Application Overview

**Application Name**: MediGuide AI

**Description**: An AI-powered hospital assistant web application serving patients, doctors, hospital staff, hospital members, and administrators. The system provides intelligent healthcare services including appointment management, AI medical consultation, document management, voice assistance, emergency services, hospital operations optimization, pill/tablet scanning, AI medical report analysis, personalized diet planning, and blood bank management. Doctors access a dedicated Doctor Portal with separate authentication and management interface. Hospital staff access a dedicated Staff Portal with hospital-specific data access. Hospital members access a dedicated Hospital Member Portal with blood bank management capabilities.

## 2. Users and Usage Scenarios

**Target Users**:
  - Patients: Book appointments, consult AI assistant, manage medical records, access emergency services, scan pills/tablets, generate AI medical reports, receive personalized diet plans
  - Doctors: Access dedicated Doctor Portal to manage appointments, view patient information, use AI clinical assistant
  - Hospital Staff/Receptionist: Access dedicated Staff Portal to handle patient registration, manage hospital-specific appointments, oversee billing, view OP timings
  - Hospital Members: Access dedicated Hospital Member Portal to manage blood bank inventory, track patient blood groups, update guardian blood groups
  - Administrators: Monitor system analytics, manage users, configure system settings, manage doctor database

**Core Usage Scenarios**:
  - Patients book and manage medical appointments
  - Patients consult AI for medical guidance and report explanations
  - Patients scan pills/tablets to view dose, uses, and side effects
  - Patients upload medical reports for AI analysis and health suggestions
  - Patients access emergency services, locate nearest hospitals and pharmacies across India
  - Patients receive personalized diet and wellness plans based on their health conditions
  - Doctors log into dedicated portal to manage appointments and patient care
  - Doctors view patient lists and appointment details
  - Hospital staff log into Staff Portal to view hospital-specific patient appointments and doctor schedules
  - Staff handle patient registration and appointment coordination for their hospital
  - Hospital members log into Hospital Member Portal to manage blood bank inventory
  - Hospital members track patient blood groups and update guardian blood groups
  - Hospital members view blood type inventory and available quantities
  - Administrators monitor hospital operations and manage doctor database

## 3. Page Structure and Functionality

### Page Hierarchy

```
MediGuide AI
├── Landing Page
├── Authentication
│   ├── Sign Up
│   ├── Login
│   ├── Forgot Password
│   └── Reset Password
├── Patient Portal
│   ├── Patient Dashboard
│   ├── Appointment Booking
│   ├── AI Medical Assistant
│   ├── Voice Assistant
│   ├── Doctor Directory (with Google Maps)
│   ├── Medical Reports
│   ├── Pill/Tablet Scanner
│   ├── AI Medical Report Maker
│   ├── Medicine Reminder
│   ├── Emergency SOS Page
│   ├── Diet & Personal Health Agent
│   ├── Notifications
│   ├── Profile (with Emergency Contacts)
│   └── Settings
├── Doctor Portal (/doctor)
│   ├── Doctor Login (/doctor-login)
│   ├── Doctor Dashboard (/doctor-dashboard)
│   ├── Doctor Appointments (/doctor-appointments)
│   └── Doctor Patients (/doctor-patients)
├── Staff Portal (/staff)
│   ├── Staff Login (/staff-login)
│   ├── Staff Dashboard (/staff-dashboard)
│   ├── Patient Registration
│   ├── Appointment Management (Hospital-Specific)
│   ├── Doctor Schedules (Hospital-Specific)
│   ├── Billing Overview
│   ├── Notifications
│   └── Analytics
├── Hospital Member Portal (/hospital-member)
│   ├── Hospital Member Login (/hospital-member-login)
│   ├── Hospital Member Dashboard (/hospital-member-dashboard)
│   ├── Blood Bank Management
│   │   ├── Patient Blood Group Tracking
│   │   ├── Guardian Blood Group Management
│   │   └── Blood Inventory Management
│   └── Notifications
├── Admin Portal
│   ├── Admin Dashboard
│   ├── User Management
│   ├── Department Management
│   ├── Doctor Database Management
│   ├── System Settings
│   ├── Document Upload (RAG)
│   └── Audit Logs
└── Global Components
    └── SOS Button (Floating)
```

### 3.1 Landing Page

**Purpose**: Introduce application and guide users to registration or login

**Sections**:
  - Hero Section: Display title, subtitle, CTA buttons (Book Appointment, Talk to AI), illustration
  - About MediGuide AI: Brief introduction to the platform
  - Features: Highlight key capabilities
  - Services: List available medical services
  - Testimonials: Display user feedback
  - FAQs: Answer common questions
  - Contact Form: Allow users to submit inquiries
  - Footer: Hospital contact information, social media links
  - Theme Toggle: Switch between dark and light mode

### 3.2 Authentication

**Sign Up**:
  - Email input
  - Password input
  - Confirm Password input
  - User Role selection (Patient/Doctor/Hospital Staff/Hospital Member/Administrator)
  - Sign Up button
  - Link to Login page

**Login**:
  - Email input
  - Password input
  - Remember Me checkbox
  - Login button
  - Links to Sign Up and Forgot Password

**Forgot Password**:
  - Email input
  - Submit button to receive reset link

**Reset Password**:
  - New Password input
  - Confirm New Password input
  - Submit button

### 3.3 Patient Dashboard

**Purpose**: Central hub for patient activities

**Components**:
  - Welcome Card: Personalized greeting with patient name
  - Upcoming Appointments: List of scheduled appointments with date, time, doctor, department
  - Medical History Overview: Summary of recent medical activities
  - Quick Actions: Shortcuts to Book Appointment, AI Assistant, Voice Assistant, Medicine Reminder, Medical Reports, Pill Scanner, AI Report Maker, Emergency SOS, Diet Agent
  - Notifications Panel: Recent alerts and reminders
  - Profile Management: Link to profile settings

### 3.4 Appointment Booking

**Purpose**: Allow patients to schedule appointments

**Multi-Step Process**:
  - Step 1: Select Department
  - Step 2: Select Doctor (filtered by department)
  - Step 3: Choose Date
  - Step 4: Select Available Time Slot
  - Step 5: Describe Symptoms (text area)
  - Step 6: Review and Confirm

**Confirmation Screen**:
  - Display appointment details
  - Show confirmation message
  - Provide option to return to dashboard

### 3.5 AI Medical Assistant

**Purpose**: Provide AI-powered medical consultation

**Capabilities**:
  - General medical Q&A
  - Explain prescriptions
  - Explain lab reports
  - Lifestyle guidance
  - Diet suggestions
  - Hospital FAQs
  - Doctor recommendations

**Interface**:
  - Chat History: Display conversation between user and AI
  - Input Area: Text input, send button, voice input button, file upload button
  - Quick Prompts: \"Explain my report\", \"Find a doctor\", \"Book appointment\", \"Common symptoms\"
  - Disclaimer: Display notice that AI responses are informational only

### 3.6 Voice Assistant

**Purpose**: Enable voice-based interaction with AI

**Components**:
  - Microphone Button: Start/stop recording
  - Listening Animation: Visual feedback during recording
  - Waveform Visualization: Display audio input
  - Live Transcription: Show real-time speech-to-text conversion
  - AI Response Card: Display AI's response
  - Audio Playback Controls: Play/pause AI audio response

### 3.7 Doctor Directory

**Purpose**: Help patients find and select doctors

**Search and Filter**:
  - Search Bar: Search by doctor name
  - Department Filter: Filter by medical department
  - Hospital Filter: Filter by hospital name

**Doctor Cards**:
  - Profile Photo
  - Name
  - Specialization
  - Experience (years)
  - Rating
  - Hospital Affiliation (Apollo, AIIMS, Fortis, Manipal, Narayana, etc.)
  - Availability Status (Available/Busy/Offline)
  - Consultation Fee
  - Book Appointment button

**Hospital Location Display**:
  - Embedded Google Map showing hospital location
  - Use Google Maps Embed API
  - Display hospital address below map

### 3.8 Medical Reports

**Purpose**: Manage patient medical reports

**Patient Actions**:
  - Upload new reports
  - View report details
  - Download reports
  - Request AI explanation of report

**Report Cards**:
  - Report Title
  - Date
  - Doctor Name
  - View, Download, Explain with AI buttons

### 3.9 Pill/Tablet Scanner

**Purpose**: Scan pills/tablets to identify and display information

**Functionality**:
  - Upload Photo Button: Upload photo of pill/tablet
  - Image Preview: Display uploaded photo before analysis
  - Analyze/Scan Button: Trigger AI recognition after photo upload
  - AI Recognition: Identify pill/tablet from image
  - Information Display:
    - Pill/Tablet Name
    - Dosage Information
    - Uses and Indications
    - Side Effects
    - Precautions
  - Save to History: Save scanned pills for future reference
  - Disclaimer: Display notice that information is for reference only

### 3.10 AI Medical Report Maker

**Purpose**: Analyze uploaded medical reports and provide health suggestions

**Functionality**:
  - Upload Report: Upload medical report (PDF, image, or document)
  - AI Analysis: Process and analyze report content
  - Results Display:
    - Summary of Key Findings
    - Health Status Assessment
    - Actionable Health Suggestions
    - Recommended Follow-up Actions
    - Lifestyle Modifications
  - Save Analysis: Save AI-generated analysis to patient profile
  - Download Report: Download analysis as PDF
  - Disclaimer: Display notice that AI analysis is informational only

### 3.11 Medicine Reminder

**Purpose**: Help patients track medication schedules

**Functionality**:
  - Add Medicine: Name, dosage, frequency
  - Set Reminder Times: Specify times for each dose
  - Mark as Taken: Record when medicine is consumed
  - View Medicine List: Display all active medications

### 3.12 Emergency SOS Page

**Purpose**: Provide comprehensive emergency assistance to patients

**Sections**:
  - One-Tap SOS Call Button:
    - Large prominent button to call emergency services (108/112)
  - Nearest Hospital and Pharmacy Locator:
    - Embedded Google Map showing patient's current location
    - Display nearby hospitals across India with distance and directions
    - Display nearby pharmacies across India with distance and directions
    - Click hospital or pharmacy marker to view details and get directions
  - Emergency Contacts List:
    - Display all saved emergency contacts from user profile
    - Each contact shows: Name, Phone Number, Relationship
    - Quick call button for each contact
  - Ambulance Booking CTA:
    - Button to request ambulance service
    - Display estimated arrival time
  - First-Aid Quick Tips:
    - Expandable sections with common emergency scenarios
    - Step-by-step first-aid instructions
    - Examples: CPR, choking, bleeding, burns, heart attack symptoms

### 3.13 Diet & Personal Health Agent

**Purpose**: Provide personalized diet and wellness plans based on patient's health condition

**Input Section**:
  - Health Condition Input:
    - Text area to describe current disease or health condition
    - Dropdown to select common conditions (Diabetes, Hypertension, Obesity, Heart Disease, etc.)
  - Submit button to generate plan

**Output Section**:
  - Weekly Meal Plan:
    - Day-by-day meal suggestions (Breakfast, Lunch, Dinner, Snacks)
    - Portion sizes and calorie information
  - Foods to Avoid:
    - List of foods that may worsen the condition
    - Explanation for each restriction
  - Lifestyle Tips:
    - Exercise recommendations
    - Sleep guidelines
    - Stress management techniques
    - Habits to adopt or avoid
  - Treatment Agent Guidance:
    - AI-generated personalized advice to reduce disease impact
    - Progress tracking suggestions

### 3.14 Doctor Portal - Doctor Login (/doctor-login)

**Purpose**: Dedicated authentication page for doctors

**Components**:
  - Doctor-branded header and visual design
  - Email input
  - Password input
  - Remember Me checkbox
  - Login button
  - Link to Forgot Password

### 3.15 Doctor Portal - Doctor Dashboard (/doctor-dashboard)

**Purpose**: Central hub for doctor activities after login

**Components**:
  - Welcome Card: Personalized greeting with doctor name and specialization
  - Stat Cards:
    - Today's Appointments Count
    - Upcoming Appointments Count
    - Total Patients Count
  - Today's Appointments List:
    - Patient Name
    - Time
    - Symptoms
    - Status (Pending/Confirmed/Completed)
  - Quick Actions:
    - View All Appointments button
    - View Patient List button

### 3.16 Doctor Portal - Doctor Appointments (/doctor-appointments)

**Purpose**: Manage all appointments assigned to logged-in doctor

**Filter Options**:
  - All
  - Pending
  - Confirmed
  - Completed
  - Cancelled

**Appointment Cards**:
  - Patient Name
  - Date and Time
  - Symptoms
  - Status Badge
  - Action Buttons:
    - Mark as Confirmed
    - Mark as Completed
    - Cancel Appointment

### 3.17 Doctor Portal - Doctor Patients (/doctor-patients)

**Purpose**: View all unique patients who have booked with this doctor

**Search**:
  - Search Bar: Search by patient name

**Patient Cards**:
  - Patient Name
  - Email
  - Phone
  - Last Appointment Date
  - Total Appointments Count

### 3.18 Staff Portal - Staff Login (/staff-login)

**Purpose**: Dedicated authentication page for hospital staff

**Components**:
  - Staff-branded header and visual design
  - Hospital Email input (staff identified by hospital email domain or role flag)
  - Password input
  - Remember Me checkbox
  - Login button
  - Link to Forgot Password

### 3.19 Staff Portal - Staff Dashboard (/staff-dashboard)

**Purpose**: Central hub for hospital staff to view hospital-specific data

**Components**:
  - Hospital Name Display: Show staff's affiliated hospital name
  - Today's Patient List:
    - Display patients with appointments at this hospital today
    - Patient Name
    - Appointment Time
    - Doctor Name
    - Department
    - Status
  - OP Doctor Timings:
    - Display outpatient timings for doctors at this hospital
    - Doctor Name
    - Department
    - OP Hours
    - Availability Status
  - Appointment Statuses:
    - Summary of appointment statuses (Pending/Confirmed/Completed/Cancelled)
    - Filtered to staff's hospital only
  - Quick Actions:
    - Register New Patient
    - Manage Appointments
    - View Doctor Schedules

### 3.20 Staff Portal - Patient Registration

**Purpose**: Allow staff to register new patients

**Form Fields**:
  - Patient Name
  - Age
  - Gender
  - Contact Number
  - Email
  - Address
  - Emergency Contact
  - Medical History (optional)

### 3.21 Staff Portal - Appointment Management (Hospital-Specific)

**Purpose**: Manage appointments for staff's hospital only

**Functionality**:
  - View all appointments at this hospital
  - Filter by date, doctor, department, status
  - Edit appointment details
  - Cancel appointments
  - Confirm appointments

### 3.22 Staff Portal - Doctor Schedules (Hospital-Specific)

**Purpose**: View doctor schedules for staff's hospital only

**Display**:
  - Doctor Name
  - Department
  - OP Timings
  - Availability Status
  - Appointment Slots

### 3.23 Staff Portal - Billing Overview

**Purpose**: Summary of billing activities for staff's hospital

**Components**:
  - Total Revenue
  - Pending Payments
  - Completed Payments
  - Billing History

### 3.24 Staff Portal - Notifications

**Purpose**: Display notifications relevant to staff's hospital

**Types**:
  - New Appointments
  - Cancelled Appointments
  - Patient Registration Alerts
  - Admin Announcements

### 3.25 Staff Portal - Analytics

**Purpose**: Visualize hospital-specific operations data

**Charts and Metrics**:
  - Appointment Trends for this hospital
  - Patient Statistics for this hospital
  - Doctor Workload for this hospital
  - Department Utilization for this hospital

### 3.26 Hospital Member Portal - Hospital Member Login (/hospital-member-login)

**Purpose**: Dedicated authentication page for hospital members

**Components**:
  - Hospital Member-branded header and visual design
  - Email input
  - Password input
  - Remember Me checkbox
  - Login button
  - Link to Forgot Password

### 3.27 Hospital Member Portal - Hospital Member Dashboard (/hospital-member-dashboard)

**Purpose**: Central hub for hospital members to manage blood bank

**Components**:
  - Welcome Card: Personalized greeting with hospital member name
  - Blood Inventory Summary:
    - Total Blood Units Available
    - Blood Type Breakdown (A+, A-, B+, B-, AB+, AB-, O+, O-)
    - Low Stock Alerts
  - Quick Actions:
    - Manage Blood Inventory
    - Track Patient Blood Groups
    - Update Guardian Blood Groups
  - Recent Activities:
    - Recent blood group updates
    - Recent inventory changes
  - Notifications Panel: Alerts for low stock, urgent requests

### 3.28 Hospital Member Portal - Patient Blood Group Tracking

**Purpose**: Track and manage patient blood groups

**Functionality**:
  - View all patients with registered blood groups
  - Search patients by name or ID
  - Filter by blood group
  - Display patient information:
    - Patient Name
    - Patient ID
    - Blood Group
    - Last Updated Date
  - Add new patient blood group
  - Edit existing patient blood group

### 3.29 Hospital Member Portal - Guardian Blood Group Management

**Purpose**: Manage guardian blood groups for patients

**Functionality**:
  - View patients with guardians
  - Search by patient name or guardian name
  - Display guardian information:
    - Patient Name
    - Guardian Name
    - Guardian Blood Group
    - Relationship
  - Add guardian blood group for patient
  - Update guardian blood group

### 3.30 Hospital Member Portal - Blood Inventory Management

**Purpose**: Manage blood bank inventory

**Functionality**:
  - View blood inventory by blood type
  - Display for each blood type:
    - Blood Type (A+, A-, B+, B-, AB+, AB-, O+, O-)
    - Available Quantity (in units)
    - Last Updated Date
    - Status (Adequate/Low Stock/Critical)
  - Add blood units to inventory
  - Remove blood units from inventory
  - Update blood unit quantities
  - Set low stock threshold alerts

### 3.31 Hospital Member Portal - Notifications

**Purpose**: Display notifications for hospital members

**Types**:
  - Low blood stock alerts
  - Critical blood stock alerts
  - Blood group update confirmations
  - Admin announcements

### 3.32 Admin Dashboard

**Purpose**: Monitor system performance and manage operations

**Metrics**:
  - Total Users
  - Total Doctors
  - Total Patients
  - Total Appointments
  - Revenue Analytics
  - Department Statistics

**Quick Actions**:
  - User Management
  - Department Management
  - Doctor Database Management
  - System Settings
  - Document Upload (RAG)
  - Audit Logs

### 3.33 User Management (Admin)

**Purpose**: Manage all system users

**Functionality**:
  - View all users
  - Search users by name, email, role
  - Edit user information
  - Deactivate/activate user accounts
  - Assign roles and permissions

### 3.34 Doctor Database Management (Admin)

**Purpose**: Manage doctor database in Supabase

**Functionality**:
  - View all doctors in database
  - Add new verified real Indian specialist doctors
  - Edit doctor information (name, specialization, hospital affiliation, experience, consultation fee)
  - Link doctors to hospitals (Apollo, AIIMS, Fortis, Manipal, Narayana, etc.)
  - Deactivate/activate doctor profiles
  - Seed additional doctors covering multiple specialties

### 3.35 RAG Knowledge Assistant (Admin)

**Purpose**: Upload hospital documents for AI-powered knowledge retrieval

**Functionality**:
  - Upload documents (PDF, DOCX, TXT)
  - Index documents for AI retrieval
  - View uploaded documents
  - Delete documents

**Chatbot Integration**:
  - AI answers questions using uploaded documents
  - Display source citations for responses

### 3.36 Analytics Dashboard

**Purpose**: Visualize hospital operations data

**Charts and Metrics**:
  - Appointment Trends: Line chart showing appointments over time
  - Patient Statistics: Bar chart of patient demographics
  - Doctor Workload: Chart showing appointments per doctor
  - Department Utilization: Pie chart of appointments by department
  - Revenue Charts: Financial performance visualization

### 3.37 Global Search

**Purpose**: Allow users to search across the system

**Search Scope**:
  - Doctors
  - Patients (role-based access)
  - Reports
  - Appointments
  - Documents

### 3.38 Profile Page

**Purpose**: Manage user profile information and emergency contacts

**Sections**:
  - Profile Photo: Upload and update photo
  - Personal Information: Name, email, phone, address
  - Emergency Contacts Section:
    - Display list of saved emergency contacts
    - Each contact shows: Name, Phone Number, Relationship
    - Add Emergency Contact button
    - Edit button for each contact
    - Delete button for each contact
  - Change Password: Update account password
  - Edit Profile: Modify personal details

**Add/Edit Emergency Contact Form**:
  - Contact Name input
  - Phone Number input
  - Relationship input (e.g., Spouse, Parent, Sibling, Friend)
  - Save button
  - Cancel button

### 3.39 Settings Page

**Purpose**: Configure user preferences

**Options**:
  - Notification Preferences: Choose notification types and delivery methods
  - Language Selection: Select preferred language
  - Theme Selection: Choose dark or light mode
  - Account Settings: Manage account options
  - Privacy Settings: Configure privacy preferences

### 3.40 Notifications Page

**Purpose**: Display all user notifications

**Types**:
  - Appointment Reminders
  - Medicine Reminders
  - Report Uploads
  - AI Alerts
  - Admin Announcements

**Actions**:
  - Mark as read/unread
  - Delete notifications
  - Filter by type

### 3.41 SOS Button (Floating Global Component)

**Purpose**: Provide quick access to emergency services

**Appearance**:
  - Persistent floating button in bottom-right corner of screen
  - Red color for high visibility
  - Always visible throughout the application
  - Displays SOS icon or text

**Behavior**:
  - Clicking button opens Emergency Modal

### 3.42 Emergency Modal

**Purpose**: Provide emergency contact options and ambulance connection

**Components**:
  - Emergency Services Section:
    - Call 108 button (India national ambulance number)
    - Call 112 button (India unified emergency number)
  - User's Emergency Contacts Section:
    - Display all saved emergency contacts from user profile
    - Each contact shows: Name, Phone Number, Relationship
    - Call button for each contact
  - Location Sharing Section:
    - Display current location hint text
    - Copy to clipboard button
    - Share location button
  - Close button to dismiss modal

## 4. Business Rules and Logic

### 4.1 Authentication Rules

  - All users must register with unique email addresses
  - Passwords must meet security requirements
  - Users select role during registration (Patient/Doctor/Hospital Staff/Hospital Member/Administrator)
  - Password reset requires email verification
  - Users remain logged in if \"Remember Me\" is selected
  - Doctors authenticate via dedicated Doctor Login page at /doctor-login
  - Doctor Login page uses same Supabase authentication with role='doctor' validation
  - Hospital staff authenticate via dedicated Staff Login page at /staff-login
  - Staff are identified by hospital email domain or staff role flag in Supabase
  - Hospital members authenticate via dedicated Hospital Member Login page at /hospital-member-login
  - Hospital members are identified by role='hospital_member' in Supabase

### 4.2 Role-Based Access Control

  - Patients: Access patient portal only
  - Doctors: Access Doctor Portal (/doctor routes) only after authenticating via /doctor-login
  - Hospital Staff: Access Staff Portal (/staff routes) only after authenticating via /staff-login
  - Hospital Members: Access Hospital Member Portal (/hospital-member routes) only after authenticating via /hospital-member-login
  - Administrators: Access admin portal and all system features
  - Doctor Portal uses separate sidebar layout from patient AppLayout
  - Staff Portal uses separate sidebar layout from patient and doctor layouts
  - Hospital Member Portal uses separate sidebar layout from other portals

### 4.3 Appointment Booking Rules

  - Patients can only book appointments for future dates
  - Time slots are based on doctor availability
  - One patient can book multiple appointments with different doctors
  - Appointment requires department, doctor, date, time slot, and symptoms
  - Confirmation is displayed after successful booking

### 4.4 Doctor Portal - Appointment Management Rules

  - Doctors view only appointments assigned to them
  - Doctors can filter appointments by status: All, Pending, Confirmed, Completed, Cancelled
  - Doctors can mark appointments as Confirmed
  - Doctors can mark appointments as Completed
  - Doctors can cancel appointments
  - Status changes update in Supabase backend

### 4.5 Doctor Portal - Patient List Rules

  - Doctors view only unique patients who have booked with them
  - Patient cards display: name, email, phone, last appointment date, total appointments count
  - Doctors can search patients by name

### 4.6 Doctor Portal - Dashboard Rules

  - Dashboard displays today's appointments count, upcoming appointments count, total patients count
  - Today's appointments list shows appointments scheduled for current date
  - Quick actions provide navigation to appointments and patient list pages

### 4.7 Staff Portal - Hospital-Specific Data Access Rules

  - Staff view only data related to their affiliated hospital
  - Staff's hospital is identified by email domain or role flag in Supabase
  - Today's patient list shows only patients with appointments at staff's hospital
  - OP doctor timings show only doctors working at staff's hospital
  - Appointment management shows only appointments at staff's hospital
  - Doctor schedules show only doctors at staff's hospital
  - Analytics display only data for staff's hospital

### 4.8 Staff Portal - Patient Registration Rules

  - Staff can register new patients
  - Registered patients are linked to staff's hospital
  - Patient information is saved to Supabase

### 4.9 Staff Portal - Appointment Management Rules

  - Staff can view, edit, confirm, and cancel appointments for their hospital
  - Staff can filter appointments by date, doctor, department, status
  - Changes update in Supabase backend

### 4.10 Hospital Member Portal - Blood Bank Management Rules

  - Hospital members can view all patient blood groups
  - Hospital members can add and update patient blood groups
  - Hospital members can view and update guardian blood groups for patients
  - Hospital members can view blood inventory by blood type
  - Hospital members can add, remove, and update blood unit quantities
  - System displays blood type, available quantity, and status (Adequate/Low Stock/Critical)
  - Low stock alerts are triggered when blood units fall below threshold
  - All blood bank data is saved to Supabase backend

### 4.11 AI Medical Assistant Rules

  - AI provides informational responses only
  - Disclaimer is always displayed
  - Chat history is saved per user session
  - File uploads (medical reports) can be analyzed by AI
  - AI can recommend doctors based on symptoms

### 4.12 Voice Assistant Rules

  - Voice input is transcribed to text
  - Transcribed text is sent to AI for processing
  - AI response is converted to audio
  - Users can replay audio responses

### 4.13 Medical Reports Rules

  - Patients can upload, view, and download their own reports
  - Doctors can upload reports for patients
  - Doctors can add comments to reports
  - AI can explain report content when requested
  - Reports display doctor name and date

### 4.14 Pill/Tablet Scanner Rules

  - Patients can upload photo of pill/tablet
  - System displays preview of uploaded photo
  - User must click Analyze/Scan button to trigger AI recognition
  - AI identifies pill/tablet from image after user initiates analysis
  - System displays pill name, dosage, uses, side effects, and precautions
  - Scanned pills are saved to patient history
  - Disclaimer is displayed that information is for reference only

### 4.15 AI Medical Report Maker Rules

  - Patients upload medical reports (PDF, image, or document)
  - AI analyzes report content and generates summary
  - System displays key findings, health status assessment, actionable suggestions, follow-up actions, and lifestyle modifications
  - AI-generated analysis is saved to patient profile
  - Patients can download analysis as PDF
  - Disclaimer is displayed that AI analysis is informational only

### 4.16 Medicine Reminder Rules

  - Patients add medicines with dosage and reminder times
  - System sends reminders at specified times
  - Patients mark medicines as taken
  - Reminder history is tracked

### 4.17 Emergency SOS Page Rules

  - One-tap SOS call button initiates call to emergency services (108/112)
  - Nearest hospital and pharmacy locator uses Google Maps to display patient's current location
  - System displays nearby hospitals across India with distance and directions
  - System displays nearby pharmacies across India with distance and directions
  - Emergency contacts list displays all saved contacts from user profile
  - Each emergency contact has quick call button
  - Ambulance booking CTA allows patient to request ambulance
  - First-aid quick tips provide expandable instructions for common emergencies

### 4.18 Diet & Personal Health Agent Rules

  - Patients input their health condition or disease
  - AI generates personalized weekly meal plan
  - AI provides list of foods to avoid with explanations
  - AI suggests lifestyle tips including exercise, sleep, stress management
  - AI acts as personal treatment agent to help reduce disease impact
  - Diet plan is saved to patient profile

### 4.19 Doctor Directory Rules

  - Doctors are categorized by department
  - Search filters results by name, department, or hospital
  - Availability status updates in real-time
  - Ratings are calculated from patient feedback
  - Doctor cards display hospital affiliation
  - Embedded Google Map shows hospital location using Google Maps Embed API
  - Hospital address is displayed below map

### 4.20 Prescription Management Rules

  - Doctors create prescriptions for patients
  - Prescriptions include medicine name, dosage, and instructions
  - Prescription history is saved
  - Patients can view their prescriptions

### 4.21 Admin Operations Rules

  - Admins can view all system users
  - Admins can edit user information and roles
  - Admins can deactivate/activate accounts
  - Admins can manage doctor database in Supabase
  - Admins can add verified real Indian specialist doctors
  - Admins can link doctors to hospitals (Apollo, AIIMS, Fortis, Manipal, Narayana, etc.)
  - Admins can seed additional doctors covering multiple specialties
  - Admins can upload documents for RAG knowledge base
  - Admins can view audit logs of system activities

### 4.22 RAG Knowledge Assistant Rules

  - Admins upload hospital documents (PDF, DOCX, TXT)
  - Documents are indexed for AI retrieval
  - AI chatbot answers questions using uploaded documents
  - Responses include source citations

### 4.23 Analytics Rules

  - Analytics display data based on user role
  - Admins see system-wide analytics
  - Staff see hospital-specific analytics
  - Charts update based on selected date range

### 4.24 Notification Rules

  - Appointment reminders are sent before scheduled time
  - Medicine reminders are sent at specified times
  - Report upload notifications are sent to patients
  - AI alerts are sent based on system analysis
  - Admin announcements are sent to all users
  - Blood bank low stock alerts are sent to hospital members

### 4.25 Search Rules

  - Search results are filtered by user role
  - Patients can search doctors, reports, appointments
  - Doctors can search patients, appointments
  - Staff can search patients, doctors, appointments (hospital-specific)
  - Hospital members can search patients by blood group
  - Admins can search all entities

### 4.26 Emergency Contacts Rules

  - Users can add multiple emergency contacts to their profile
  - Each emergency contact requires: Name, Phone Number, Relationship
  - Emergency contacts are saved to Supabase
  - Users can edit or delete emergency contacts
  - Emergency contacts are displayed on profile page
  - Emergency contacts are accessible via SOS Emergency Modal and Emergency SOS Page

### 4.27 SOS Button Rules

  - SOS button is visible throughout the application
  - SOS button is positioned in bottom-right corner
  - SOS button is red for high visibility
  - Clicking SOS button opens Emergency Modal

### 4.28 Emergency Modal Rules

  - Emergency Modal displays emergency service numbers (108, 112)
  - Emergency Modal displays user's saved emergency contacts
  - Each emergency contact has a call button
  - Emergency Modal provides location sharing functionality
  - Users can copy location text to clipboard
  - Users can close Emergency Modal

### 4.29 Google Maps Integration Rules

  - Google Maps Embed API is used to display hospital and pharmacy locations
  - Maps are embedded in Doctor Directory page for each hospital
  - Maps are embedded in Emergency SOS Page to show nearest hospitals and pharmacies across India
  - Maps display patient's current location and nearby hospitals and pharmacies with distance
  - Users can click hospital or pharmacy markers to view details and get directions

## 5. Exception and Boundary Cases

| Scenario | Handling |
|----------|----------|
| User enters invalid email format | Display error message, prevent submission |
| User enters incorrect password | Display error message, allow retry |
| User forgets password | Provide password reset via email |
| No available time slots for selected date | Display message, suggest alternative dates |
| AI assistant fails to respond | Display error message, allow retry |
| Voice input not detected | Display message, prompt user to try again |
| No doctors available in selected department | Display empty state with message |
| Medical report file upload fails | Display error message, allow re-upload |
| Network connection lost | Display offline message |
| User tries to book appointment in past | Prevent selection, display error message |
| User tries to access unauthorized page | Redirect to appropriate dashboard, display access denied |
| Doctor rejects appointment | Send notification to patient |
| Patient uploads invalid file format | Display error message, specify allowed formats |
| Admin uploads non-document file for RAG | Display error message, specify allowed formats |
| Search returns no results | Display empty state with message |
| User tries to delete active appointment | Require confirmation before deletion |
| Medicine reminder time conflicts | Allow multiple reminders, display all |
| Prescription has no medicines | Prevent saving, display error message |
| User profile photo upload fails | Display error message, allow retry |
| Analytics data unavailable | Display empty state with message |
| Notification delivery fails | Retry delivery, log failure |
| User has no emergency contacts saved | Display empty state in Emergency Modal and Emergency SOS Page, prompt to add contacts |
| Emergency contact phone number invalid | Display error message, prevent saving |
| User tries to add duplicate emergency contact | Display warning message, allow or prevent based on design choice |
| SOS button clicked but no emergency contacts saved | Display emergency service numbers only |
| Location sharing unavailable | Display error message, provide manual location input option |
| Call button fails to initiate call | Display error message, show phone number for manual dialing |
| Admin tries to add doctor without hospital affiliation | Display error message, require hospital selection |
| Doctor database empty | Display empty state with message, prompt admin to add doctors |
| Doctor tries to access patient portal | Redirect to Doctor Portal, display access denied |
| Patient tries to access Doctor Portal | Redirect to patient portal, display access denied |
| Doctor has no appointments | Display empty state with message |
| Doctor has no patients | Display empty state with message |
| Doctor login with non-doctor role | Display error message, prevent login |
| Staff tries to access patient or doctor portal | Redirect to Staff Portal, display access denied |
| Staff login with non-staff role | Display error message, prevent login |
| Staff has no hospital affiliation | Display error message, prevent login |
| Staff tries to view data from other hospitals | Display access denied, show only own hospital data |
| Hospital member tries to access other portals | Redirect to Hospital Member Portal, display access denied |
| Hospital member login with non-hospital-member role | Display error message, prevent login |
| Hospital member tries to view data from other hospitals | Display access denied, show only own hospital data |
| Blood inventory quantity is zero | Display critical alert, prompt to add blood units |
| Blood inventory falls below threshold | Display low stock alert, send notification |
| Hospital member tries to add negative blood quantity | Display error message, prevent submission |
| Patient blood group already exists | Display warning, allow update or prevent duplicate |
| Guardian blood group not provided | Allow saving without guardian blood group |
| Hospital member tries to delete blood inventory | Require confirmation before deletion |
| Google Maps fails to load | Display error message, show hospital/pharmacy address as fallback |
| Patient location unavailable for nearest hospital/pharmacy locator | Display error message, prompt to enable location services |
| Ambulance booking service unavailable | Display error message, show emergency numbers as fallback |
| First-aid tips fail to load | Display error message, allow retry |
| Pill/tablet scanner fails to recognize pill | Display error message, prompt to retake photo or upload clearer image |
| User uploads invalid image format for pill scanner | Display error message, specify allowed formats |
| AI Medical Report Maker fails to analyze report | Display error message, allow retry |
| Uploaded report format not supported by AI Report Maker | Display error message, specify supported formats |
| AI Report Maker generates incomplete analysis | Display partial results with disclaimer |
| No pharmacies found near patient location | Display message, suggest expanding search radius |
| User clicks Analyze button without uploading photo | Display error message, prompt to upload photo first |

## 6. Acceptance Criteria

1. Hospital member navigates to /hospital-member-login page
2. Hospital member enters email and password and successfully logs in
3. Hospital member lands on Hospital Member Dashboard at /hospital-member-dashboard
4. Hospital member views blood inventory summary with blood type breakdown and low stock alerts
5. Hospital member navigates to Patient Blood Group Tracking page
6. Hospital member views all patients with registered blood groups
7. Hospital member adds or updates patient blood group
8. Hospital member navigates to Guardian Blood Group Management page
9. Hospital member views patients with guardians and their blood groups
10. Hospital member updates guardian blood group for a patient
11. Hospital member navigates to Blood Inventory Management page
12. Hospital member views blood inventory by blood type with available quantities and status
13. Hospital member adds blood units to inventory
14. Hospital member updates blood unit quantities
15. System displays low stock alert when blood units fall below threshold

## 7. Out of Scope for Current Release

**Features Not Included**:
  - Payment processing for consultation fees
  - Video consultation functionality
  - Insurance claim processing
  - Multi-language support beyond initial language selection
  - Integration with external hospital management systems
  - Patient-to-patient messaging
  - Advanced analytics and reporting beyond basic charts
  - Mobile native applications (iOS/Android)
  - Health tracking device integration
  - Pharmacy integration for medicine delivery
  - Lab test result integration
  - Appointment reminder notifications via SMS
  - Waiting time estimation
  - Queue management for walk-in patients
  - Automated billing and invoicing
  - Electronic health record (EHR) integration
  - Clinical decision support systems
  - Medical imaging storage and viewing
  - Genetic data analysis
  - Wearable device integration
  - Real-time GPS location tracking for ambulance
  - Automatic emergency contact notification
  - Voice-activated SOS trigger
  - Integration with local emergency services dispatch systems
  - Doctor-to-doctor messaging within Doctor Portal
  - Prescription writing functionality within Doctor Portal
  - Medical notes creation within Doctor Portal
  - Patient medical history viewing within Doctor Portal
  - Real-time ambulance tracking on map
  - Integration with hospital inventory management
  - Staff-to-staff messaging within Staff Portal
  - Automated OP schedule generation
  - Integration with third-party diet tracking apps
  - Calorie counting and nutrition tracking
  - Personalized exercise video library
  - Integration with fitness wearables for diet recommendations
  - Real-time pill identification database updates
  - Barcode scanning for pill identification
  - Integration with pharmacy inventory for pill availability
  - Advanced medical report analysis using medical imaging AI
  - Integration with lab systems for automatic report upload
  - Comparative analysis of multiple medical reports over time
  - Camera access for pill scanning
  - Blood donation scheduling and management
  - Blood donor database management
  - Blood transfusion tracking and history
  - Integration with external blood banks
  - Automated blood expiry tracking and alerts
  - Blood compatibility testing and matching
  - Blood request and approval workflow
  - Blood usage analytics and reporting
  - Integration with national blood bank networks