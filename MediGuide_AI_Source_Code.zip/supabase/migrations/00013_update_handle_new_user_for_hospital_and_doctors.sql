-- Make hospitals columns nullable
ALTER TABLE public.hospitals ALTER COLUMN city DROP NOT NULL;
ALTER TABLE public.hospitals ALTER COLUMN address DROP NOT NULL;

-- Update trigger function
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_role user_role;
  v_hospital_id uuid;
BEGIN
  v_role := COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'patient');

  IF v_role = 'hospital_member' THEN
    -- Insert into hospitals table
    INSERT INTO public.hospitals (name)
    VALUES (COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)))
    RETURNING id INTO v_hospital_id;
  END IF;

  INSERT INTO public.profiles (id, name, email, role, hospital_id)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.email, ''),
    v_role,
    v_hospital_id
  )
  ON CONFLICT (id) DO NOTHING;

  IF v_role = 'doctor' THEN
    -- Insert into doctors table
    INSERT INTO public.doctors (user_id, name, specialization, department)
    VALUES (
      NEW.id,
      COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
      'General',
      'General Medicine'
    )
    ON CONFLICT DO NOTHING;
  END IF;

  RETURN NEW;
END;
$function$;