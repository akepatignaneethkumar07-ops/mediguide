-- Add hospital_name column to doctors
ALTER TABLE doctors ADD COLUMN IF NOT EXISTS hospital_name text;

-- Create emergency_contacts table for multiple contacts per user
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text NOT NULL,
  relationship text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- RLS
ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ec_select_own" ON emergency_contacts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "ec_insert_own" ON emergency_contacts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "ec_update_own" ON emergency_contacts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "ec_delete_own" ON emergency_contacts FOR DELETE USING (auth.uid() = user_id);