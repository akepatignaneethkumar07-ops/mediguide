
ALTER TABLE video_consultations
  ADD COLUMN IF NOT EXISTS meeting_platform text NOT NULL DEFAULT 'zoom',
  ADD COLUMN IF NOT EXISTS rescheduled_at timestamptz;
