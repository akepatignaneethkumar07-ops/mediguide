
ALTER TABLE video_consultations
  ADD COLUMN IF NOT EXISTS zoom_link text,
  ADD COLUMN IF NOT EXISTS zoom_meeting_id text,
  ADD COLUMN IF NOT EXISTS notified_at timestamptz;
