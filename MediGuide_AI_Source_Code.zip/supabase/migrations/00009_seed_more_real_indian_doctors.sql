INSERT INTO doctors (name, specialization, department, experience, rating, reviews, availability, fee, bio, hospital_name, next_slot, avatar_url) VALUES
-- General Medicine (new department - no existing doctors)
('Dr. K. K. Aggarwal', 'Internal Medicine & Cardiology', 'General Medicine', 38, 4.9, 621, 'available', 1200, 'Former President of IMA and MTNL Mumbai Heart Club. Expert in preventive cardiology and internal medicine with 38 years of experience.', 'Moolchand Medcity, New Delhi', 'Tomorrow 9:00 AM', NULL),
('Dr. Sunil Prakash', 'Internal Medicine', 'General Medicine', 22, 4.7, 389, 'available', 900, 'Specialist in adult medicine, metabolic disorders, and preventive healthcare. Trained at AIIMS Delhi with fellowships in UK.', 'BLK Super Speciality Hospital, New Delhi', 'Today 4:00 PM', NULL),
('Dr. Anand Kumar', 'General Medicine & Diabetes', 'General Medicine', 26, 4.8, 512, 'busy', 700, 'Expertise in diabetes management, hypertension, thyroid disorders and lifestyle diseases. Over 26 years of clinical practice.', 'Medanta - The Medicity, Gurugram', 'Tomorrow 11:00 AM', NULL),

-- Dermatology (only 1 existing)
('Dr. Uday Khopkar', 'Dermatology & Leprosy', 'Dermatology', 34, 4.9, 478, 'available', 1200, 'Head of Dermatology at KEM Hospital Mumbai. Renowned for clinical dermatology, dermoscopy and leprosy management.', 'KEM Hospital, Mumbai', 'Today 3:30 PM', NULL),
('Dr. Niti Khunger', 'Dermatosurgery & Cosmetic Dermatology', 'Dermatology', 22, 4.8, 391, 'available', 1500, 'Expert in aesthetic dermatology, hair transplantation and laser procedures. Head of Dermatosurgery at VMMC.', 'Safdarjung Hospital (VMMC), New Delhi', 'Tomorrow 10:00 AM', NULL),

-- Gynaecology (only 1 existing)
('Dr. Nandita Palshetkar', 'Reproductive Medicine & IVF', 'Gynaecology', 30, 4.9, 567, 'available', 1800, 'Pioneer in IVF treatments in India. Director of Bloom IVF Group. Has helped thousands of couples achieve parenthood.', 'Lilavati Hospital & Bloom IVF, Mumbai', 'Tomorrow 9:00 AM', NULL),
('Dr. Shubha Rani', 'High-Risk Obstetrics', 'Gynaecology', 25, 4.7, 334, 'available', 1100, 'Specialist in high-risk pregnancy, fetal medicine and maternal medicine. Trained at AIIMS and CMCH Vellore.', 'Apollo Hospitals, Hyderabad', 'Today 2:30 PM', NULL),
('Dr. Rishma Pai', 'Gynaecology & Laparoscopic Surgery', 'Gynaecology', 29, 4.9, 498, 'busy', 1600, 'Former President of FOGSI. Expert in minimally invasive gynaecological surgeries and reproductive endoscopy.', 'Jaslok Hospital & Bhatia Hospital, Mumbai', 'Tomorrow 2:00 PM', NULL),

-- Psychiatry (only 1 existing)
('Dr. Nimesh Desai', 'Psychiatry & De-addiction', 'Psychiatry', 32, 4.8, 412, 'available', 1300, 'Director of Institute of Human Behaviour and Allied Sciences. Expert in de-addiction, forensic psychiatry and community mental health.', 'IHBAS, New Delhi', 'Tomorrow 10:30 AM', NULL),
('Dr. Soumitra Pathare', 'Community Psychiatry', 'Psychiatry', 28, 4.7, 287, 'available', 1100, 'Internationally recognised mental health policy expert. Runs the Centre for Mental Health Law & Policy at ILS, Pune.', 'Pune Institute of Medical Sciences, Pune', 'Today 5:00 PM', NULL),

-- Orthopedics (add more)
('Dr. Raju Vaishya', 'Orthopaedics & Sports Medicine', 'Orthopedics', 35, 4.9, 591, 'available', 1700, 'Senior Consultant at Indraprastha Apollo. Specialist in complex knee replacement, sports injuries and orthopedic oncology.', 'Indraprastha Apollo Hospitals, New Delhi', 'Tomorrow 11:00 AM', NULL),
('Dr. K. H. Sancheti', 'Joint Replacement & Arthroscopy', 'Orthopedics', 40, 4.9, 712, 'available', 2000, 'Padma Shri awardee and leading orthopedic surgeon in India. Performed over 20,000 knee replacements at Sancheti Hospital.', 'Sancheti Institute for Orthopaedics, Pune', 'Tomorrow 9:30 AM', NULL),

-- Cardiology (add 1 more)
('Dr. K. Srinath Reddy', 'Preventive Cardiology', 'Cardiology', 42, 5.0, 834, 'available', 2000, 'President of Public Health Foundation of India. Ex-Head of Cardiology AIIMS. Pioneer in preventive cardiology and cardiovascular epidemiology.', 'AIIMS New Delhi & PHFI', 'Tomorrow 10:00 AM', NULL),

-- Nephrology (add 1 more)
('Dr. Vivek Gupta', 'Clinical Nephrology', 'Nephrology', 18, 4.7, 265, 'available', 1000, 'Specialist in chronic kidney disease, dialysis, and glomerulonephritis. Trained at PGIMER Chandigarh with international fellowships.', 'Fortis Hospital, Noida', 'Today 4:30 PM', NULL),

-- Endocrinology (add 1 more)
('Dr. Ambrish Mithal', 'Endocrinology & Bone Disease', 'Endocrinology', 35, 4.9, 598, 'available', 1800, 'Chairman Endocrinology at Max Healthcare. World-renowned expert in osteoporosis, thyroid disorders and diabetes. Former VP of Endocrine Society USA.', 'Max Super Speciality Hospital, New Delhi', 'Tomorrow 9:00 AM', NULL),

-- Gastroenterology (add 1 more)  
('Dr. Nageshwar Reddy', 'Advanced Endoscopy', 'Gastroenterology', 38, 5.0, 872, 'available', 2000, 'Padma Shri awardee and world-leading gastroenterologist. Pioneered advanced endoscopy techniques in India. Chairman AIG Hospitals.', 'AIG Hospitals, Hyderabad', 'Tomorrow 11:00 AM', NULL)
ON CONFLICT (id) DO NOTHING;