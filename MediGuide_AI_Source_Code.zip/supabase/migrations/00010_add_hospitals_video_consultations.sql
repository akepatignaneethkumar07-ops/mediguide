
-- Hospitals table (for staff portal filtering)
create table if not exists hospitals (
  id           uuid primary key default gen_random_uuid(),
  name         text not null,
  city         text not null,
  address      text not null,
  email_domain text unique,           -- e.g. "apollo.com" — staff filtered by this
  maps_query   text,                  -- Google Maps search string
  lat          numeric(10,6),
  lng          numeric(10,6),
  created_at   timestamptz default now()
);

-- Staff portal: link a profile to a hospital
alter table profiles add column if not exists hospital_id uuid references hospitals(id);

-- Video consultation requests
create table if not exists video_consultations (
  id             uuid primary key default gen_random_uuid(),
  patient_id     uuid references profiles(id) on delete cascade,
  doctor_id      uuid references profiles(id) on delete cascade,
  doctor_name    text not null,
  patient_name   text,
  requested_date date not null,
  requested_time text not null,
  status         text not null default 'pending' check (status in ('pending','approved','rejected','completed')),
  notes          text,
  room_id        text default gen_random_uuid()::text,
  created_at     timestamptz default now()
);

-- Diet plans (saved AI-generated plans)
create table if not exists diet_plans (
  id            uuid primary key default gen_random_uuid(),
  patient_id    uuid references profiles(id) on delete cascade,
  condition     text not null,
  plan_json     jsonb not null default '{}',
  created_at    timestamptz default now()
);

-- RLS
alter table hospitals            enable row level security;
alter table video_consultations  enable row level security;
alter table diet_plans           enable row level security;

-- Hospitals: public read
create policy "hospitals_read_all" on hospitals for select using (true);

-- Video consultations: patient sees own, doctor sees assigned
create policy "vc_patient_select"  on video_consultations for select using (auth.uid() = patient_id);
create policy "vc_doctor_select"   on video_consultations for select using (auth.uid() = doctor_id);
create policy "vc_patient_insert"  on video_consultations for insert with check (auth.uid() = patient_id);
create policy "vc_doctor_update"   on video_consultations for update using (auth.uid() = doctor_id);
create policy "vc_patient_update"  on video_consultations for update using (auth.uid() = patient_id);

-- Diet plans: own only
create policy "diet_own_all" on diet_plans for all using (auth.uid() = patient_id) with check (auth.uid() = patient_id);

-- Seed hospitals
insert into hospitals (name, city, address, email_domain, maps_query) values
  ('Apollo Hospitals Hyderabad',        'Hyderabad',   'Jubilee Hills Road No.2, Hyderabad – 500033',       'apollo-hyd.com',     'Apollo Hospitals Jubilee Hills Hyderabad'),
  ('Manipal Hospitals Bangalore',       'Bangalore',   'HAL Airport Road, Bangalore – 560017',              'manipal-blr.com',    'Manipal Hospitals HAL Airport Road Bangalore'),
  ('Narayana Health City Bangalore',    'Bangalore',   'Bommasandra Industrial Area, Bangalore – 560099',   'narayana-blr.com',   'Narayana Health City Bommasandra Bangalore'),
  ('Fortis Hospital Bannerghatta',      'Bangalore',   'Bannerghatta Road, Bangalore – 560076',             'fortis-blr.com',     'Fortis Hospital Bannerghatta Road Bangalore'),
  ('AIIMS New Delhi',                   'New Delhi',   'Ansari Nagar East, New Delhi – 110029',             'aiims.edu',          'AIIMS New Delhi Ansari Nagar'),
  ('Max Super Speciality Saket',        'New Delhi',   'Press Enclave Road, Saket, New Delhi – 110017',     'maxhealthcare.in',   'Max Super Speciality Hospital Saket Delhi'),
  ('Kokilaben Hospital Mumbai',         'Mumbai',      'Andheri West, Mumbai – 400053',                     'kokilabenhospital.com', 'Kokilaben Dhirubhai Ambani Hospital Andheri'),
  ('Apollo Hospitals Chennai',          'Chennai',     'Greams Road, Chennai – 600006',                     'apollo-chn.com',     'Apollo Hospitals Greams Road Chennai'),
  ('MIOT International Chennai',        'Chennai',     'Mount Poonamallee Road, Chennai – 600089',          'miotinternational.com', 'MIOT International Chennai'),
  ('Ruby Hall Clinic Pune',             'Pune',        'Sassoon Road, Pune – 411001',                       'rubyhall.com',       'Ruby Hall Clinic Sassoon Road Pune')
on conflict (email_domain) do nothing;
