
INSERT INTO storage.buckets (id, name, public)
VALUES ('generated-media', 'generated-media', true)
ON CONFLICT (id) DO NOTHING;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'generated_media_public_read' AND tablename = 'objects'
  ) THEN
    CREATE POLICY "generated_media_public_read"
      ON storage.objects FOR SELECT
      USING (bucket_id = 'generated-media');
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'generated_media_service_insert' AND tablename = 'objects'
  ) THEN
    CREATE POLICY "generated_media_service_insert"
      ON storage.objects FOR INSERT
      WITH CHECK (bucket_id = 'generated-media');
  END IF;
END $$;
