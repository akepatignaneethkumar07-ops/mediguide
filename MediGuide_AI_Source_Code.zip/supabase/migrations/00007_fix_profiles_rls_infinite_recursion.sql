-- Drop the recursive admin policy
DROP POLICY IF EXISTS "profiles_admin_all" ON profiles;

-- Create a SECURITY DEFINER helper that reads the role directly from the table
-- bypassing RLS entirely, so no recursive policy evaluation occurs
CREATE OR REPLACE FUNCTION public.get_my_role()
RETURNS user_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$;

-- Recreate the admin policy using the helper function (no recursive self-reference)
CREATE POLICY "profiles_admin_all"
  ON profiles
  FOR ALL
  USING (public.get_my_role() = 'admin'::user_role)
  WITH CHECK (public.get_my_role() = 'admin'::user_role);