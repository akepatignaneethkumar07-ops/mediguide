
-- ═══════════════════════════════════════════════════════════════════
-- MediGuide AI — Full Database Schema
-- ═══════════════════════════════════════════════════════════════════

-- ── 1. ENUMS ────────────────────────────────────────────────────────
CREATE TYPE user_role         AS ENUM ('patient','doctor','staff','admin');
CREATE TYPE availability_status AS ENUM ('available','busy','offline');
CREATE TYPE appt_status       AS ENUM ('pending','confirmed','in-progress','completed','cancelled');
CREATE TYPE appt_type         AS ENUM ('Consultation','Follow-up','Emergency');
CREATE TYPE report_status     AS ENUM ('normal','review','abnormal');
CREATE TYPE reminder_frequency AS ENUM ('once-daily','twice-daily','three-daily','as-needed');
CREATE TYPE notif_type        AS ENUM ('appointment','medicine','report','alert','announcement');
CREATE TYPE chat_role         AS ENUM ('user','assistant');

-- ── 2. PROFILES ─────────────────────────────────────────────────────
CREATE TABLE profiles (
  id                      uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name                    text NOT NULL DEFAULT '',
  email                   text NOT NULL DEFAULT '',
  role                    user_role NOT NULL DEFAULT 'patient',
  avatar_url              text,
  phone                   text,
  blood_group             text,
  address                 text,
  date_of_birth           date,
  emergency_contact_name  text,
  emergency_contact_phone text,
  allergies               text,
  medical_conditions      text,
  created_at              timestamptz NOT NULL DEFAULT now(),
  updated_at              timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "profiles_select_own"   ON profiles FOR SELECT  USING (auth.uid() = id);
CREATE POLICY "profiles_insert_own"   ON profiles FOR INSERT  WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own"   ON profiles FOR UPDATE  USING (auth.uid() = id);
CREATE POLICY "profiles_admin_all"    ON profiles FOR ALL     USING (
  EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);

-- Trigger: auto-create profile on signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO profiles (id, name, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)),
    COALESCE(NEW.email, ''),
    COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'patient')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Helper: get current user role (SECURITY DEFINER to avoid RLS self-loop)
CREATE OR REPLACE FUNCTION get_my_role()
RETURNS user_role LANGUAGE sql SECURITY DEFINER AS $$
  SELECT role FROM profiles WHERE id = auth.uid()
$$;

-- ── 3. DOCTORS ──────────────────────────────────────────────────────
CREATE TABLE doctors (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name           text NOT NULL,
  specialization text NOT NULL,
  department     text NOT NULL,
  experience     int  NOT NULL DEFAULT 0,
  rating         numeric(3,1) NOT NULL DEFAULT 5.0,
  reviews        int NOT NULL DEFAULT 0,
  availability   availability_status NOT NULL DEFAULT 'available',
  fee            numeric(10,2) NOT NULL DEFAULT 0,
  bio            text,
  next_slot      text,
  avatar_url     text,
  user_id        uuid REFERENCES profiles(id),
  created_at     timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "doctors_select_all"  ON doctors FOR SELECT  USING (true);
CREATE POLICY "doctors_admin_write" ON doctors FOR ALL     USING (get_my_role() = 'admin');

-- ── 4. APPOINTMENTS ─────────────────────────────────────────────────
CREATE TABLE appointments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id   uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  doctor_id    uuid REFERENCES doctors(id),
  doctor_name  text NOT NULL DEFAULT '',
  department   text NOT NULL DEFAULT '',
  date         date NOT NULL,
  time         text NOT NULL,
  symptoms     text,
  status       appt_status NOT NULL DEFAULT 'pending',
  type         appt_type NOT NULL DEFAULT 'Consultation',
  notes        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "appt_patient_select" ON appointments FOR SELECT  USING (patient_id = auth.uid());
CREATE POLICY "appt_patient_insert" ON appointments FOR INSERT  WITH CHECK (patient_id = auth.uid());
CREATE POLICY "appt_patient_update" ON appointments FOR UPDATE  USING (patient_id = auth.uid());
CREATE POLICY "appt_patient_delete" ON appointments FOR DELETE  USING (patient_id = auth.uid());
CREATE POLICY "appt_staff_select"   ON appointments FOR SELECT  USING (get_my_role() IN ('doctor','staff','admin'));
CREATE POLICY "appt_staff_update"   ON appointments FOR UPDATE  USING (get_my_role() IN ('doctor','staff','admin'));

-- ── 5. MEDICAL REPORTS ──────────────────────────────────────────────
CREATE TABLE medical_reports (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id   uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  doctor_name  text NOT NULL DEFAULT '',
  title        text NOT NULL,
  report_type  text NOT NULL DEFAULT 'Laboratory',
  date         date NOT NULL DEFAULT CURRENT_DATE,
  status       report_status NOT NULL DEFAULT 'normal',
  summary      text,
  file_url     text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE medical_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "reports_patient_select" ON medical_reports FOR SELECT  USING (patient_id = auth.uid());
CREATE POLICY "reports_patient_insert" ON medical_reports FOR INSERT  WITH CHECK (patient_id = auth.uid());
CREATE POLICY "reports_patient_update" ON medical_reports FOR UPDATE  USING (patient_id = auth.uid());
CREATE POLICY "reports_patient_delete" ON medical_reports FOR DELETE  USING (patient_id = auth.uid());
CREATE POLICY "reports_staff_select"   ON medical_reports FOR SELECT  USING (get_my_role() IN ('doctor','staff','admin'));

-- ── 6. MEDICINE REMINDERS ───────────────────────────────────────────
CREATE TABLE medicine_reminders (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id  uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  name        text NOT NULL,
  dosage      text NOT NULL,
  frequency   reminder_frequency NOT NULL DEFAULT 'once-daily',
  times       text[] NOT NULL DEFAULT '{}',
  taken_today boolean[] NOT NULL DEFAULT '{}',
  color       text NOT NULL DEFAULT 'bg-primary/10 text-primary',
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE medicine_reminders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "reminders_patient_select" ON medicine_reminders FOR SELECT  USING (patient_id = auth.uid());
CREATE POLICY "reminders_patient_insert" ON medicine_reminders FOR INSERT  WITH CHECK (patient_id = auth.uid());
CREATE POLICY "reminders_patient_update" ON medicine_reminders FOR UPDATE  USING (patient_id = auth.uid());
CREATE POLICY "reminders_patient_delete" ON medicine_reminders FOR DELETE  USING (patient_id = auth.uid());

-- ── 7. NOTIFICATIONS ────────────────────────────────────────────────
CREATE TABLE notifications (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  type       notif_type NOT NULL DEFAULT 'alert',
  title      text NOT NULL,
  message    text NOT NULL,
  read       boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "notif_user_select" ON notifications FOR SELECT  USING (user_id = auth.uid());
CREATE POLICY "notif_user_insert" ON notifications FOR INSERT  WITH CHECK (user_id = auth.uid());
CREATE POLICY "notif_user_update" ON notifications FOR UPDATE  USING (user_id = auth.uid());
CREATE POLICY "notif_user_delete" ON notifications FOR DELETE  USING (user_id = auth.uid());
CREATE POLICY "notif_admin_insert" ON notifications FOR INSERT WITH CHECK (get_my_role() IN ('admin','staff'));

-- ── 8. CHAT MESSAGES ────────────────────────────────────────────────
CREATE TABLE chat_messages (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  role       chat_role NOT NULL,
  content    text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "chat_user_select" ON chat_messages FOR SELECT  USING (user_id = auth.uid());
CREATE POLICY "chat_user_insert" ON chat_messages FOR INSERT  WITH CHECK (user_id = auth.uid());
CREATE POLICY "chat_user_delete" ON chat_messages FOR DELETE  USING (user_id = auth.uid());
