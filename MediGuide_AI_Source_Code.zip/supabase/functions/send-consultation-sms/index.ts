import { serve } from "https://deno.land/std/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405, headers: corsHeaders });
  }

  const ACCOUNT_SID  = Deno.env.get("TWILIO_ACCOUNT_SID");
  const AUTH_TOKEN   = Deno.env.get("TWILIO_AUTH_TOKEN");
  const FROM_NUMBER  = Deno.env.get("TWILIO_FROM_NUMBER");

  if (!ACCOUNT_SID || !AUTH_TOKEN || !FROM_NUMBER) {
    return new Response(JSON.stringify({ error: "Twilio credentials not configured" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let to: string;
  let message: string;
  try {
    const body = await req.json();
    to      = body.to;
    message = body.message;
    if (!to || !message) throw new Error("Missing to or message");
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Twilio Messages API
  const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${ACCOUNT_SID}/Messages.json`;
  const params = new URLSearchParams({ To: to, From: FROM_NUMBER, Body: message });

  const twilioRes = await fetch(twilioUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Authorization: "Basic " + btoa(`${ACCOUNT_SID}:${AUTH_TOKEN}`),
    },
    body: params.toString(),
  });

  const data = await twilioRes.json();
  if (!twilioRes.ok) {
    return new Response(JSON.stringify({ error: data.message ?? "Twilio error" }), {
      status: twilioRes.status,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ sid: data.sid, status: data.status }), {
    status: 200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
