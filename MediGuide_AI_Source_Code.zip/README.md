# MediGuide AI 🏥

> An AI-powered hospital assistant that makes healthcare accessible, efficient, and intelligent.

**Live Demo:** [🔗 Add your live app URL here]  
**Built for:** [Your Hackathon Name] · 2026  
**Team:** [Your Team Name]

---

## Overview

MediGuide AI is a full-stack healthcare web application that combines AI-driven assistance with a complete hospital management workflow — giving patients, doctors, and admins a unified, smart platform.

| Portal | Who it's for | What it does |
|---|---|---|
| 🧑‍⚕️ **Patient Portal** | Patients | Book appointments, AI health chat, medical records, medicine reminders |
| 👨‍⚕️ **Doctor Portal** | Verified doctors | Manage OP timings, view patient list, confirm/complete appointments |
| 🛠️ **Admin Dashboard** | Hospital staff | Oversee all appointments, manage doctors and users |

---

## Features

### For Patients
- **AI Health Chat** — Conversational AI for medical queries, symptom checks, and hospital info
- **Smart Appointment Booking** — Browse 40+ real specialist doctors, pick a time slot, book instantly
- **Doctor Directory** — Filter by specialty, view OP fees in ₹ (Indian Rupees), and Pay at Hospital
- **Medical Records** — Upload and manage personal health documents
- **Medicine Reminders** — Never miss a dose with scheduled notifications
- **Voice Assistant** — Hands-free interaction powered by speech-to-text and text-to-speech

### For Doctors
- **Doctor Dashboard** — Today's appointments, upcoming schedule, total patients at a glance
- **Appointment Management** — Confirm, complete, or cancel appointments with one click
- **Patient Directory** — Full list of unique patients with visit history and contact info

### For Admins
- **Hospital-wide Overview** — Real-time stats across all departments
- **User Management** — Role-based access control (patient / doctor / staff / admin)

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + TypeScript + Vite |
| UI Components | shadcn/ui + Tailwind CSS |
| Animations | Framer Motion (motion/react) |
| Backend / DB | Supabase (PostgreSQL + RLS) |
| Auth | Supabase Auth (email/password) |
| AI Chat | Edge Functions + LLM integration |
| Voice | Web Speech API (STT) + Text-to-Speech |
| Icons | Lucide React |

---

## Getting Started

### Prerequisites
- Node.js ≥ 18
- pnpm (`npm install -g pnpm`)
- A [Supabase](https://supabase.com) project

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/mediguide-ai.git
cd mediguide-ai

# Install dependencies
pnpm install

# Set up environment variables
cp .env.example .env
# Fill in your Supabase URL and anon key in .env

# Start the development server
pnpm dev
```

### Environment Variables

Create a `.env` file in the project root:

```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

---

## Project Structure

```
src/
├── components/
│   ├── layouts/          # AppLayout, DoctorLayout, AdminLayout
│   └── ui/               # shadcn/ui components
├── contexts/             # AuthContext, ThemeContext
├── pages/
│   ├── doctor/           # Doctor portal pages
│   ├── LandingPage.tsx   # Public landing page
│   ├── AuthPage.tsx      # Role-picker login (Patient / Doctor)
│   ├── PatientDashboard.tsx
│   ├── DoctorDirectoryPage.tsx
│   ├── AppointmentBooking.tsx
│   ├── AIChatPage.tsx
│   └── ...
├── routes.tsx            # Centralized route definitions
└── types/                # TypeScript type definitions
```

---

## Database Schema (Supabase)

Key tables:
- `profiles` — User profiles with role (`patient` | `doctor` | `staff` | `admin`)
- `doctors` — 40+ specialist profiles with specialties, fees, and OP timings
- `appointments` — Bookings with status workflow (`pending` → `confirmed` → `completed`)
- `medical_reports` — Patient-uploaded health documents
- `medicine_reminders` — Scheduled medication notifications

Row Level Security (RLS) is enabled on all tables with role-based policies.

---

## Screenshots

> _(Add screenshots of your app here)_

| Landing Page | Patient Dashboard | Doctor Portal |
|---|---|---|
| ![landing](docs/landing.png) | ![dashboard](docs/dashboard.png) | ![doctor](docs/doctor.png) |

---

## Roadmap

- [ ] Real-time appointment notifications (Supabase Realtime)
- [ ] Telemedicine / video consultation integration
- [ ] Prescription management system
- [ ] Lab report AI analysis
- [ ] Multi-language support (Hindi, Tamil, Telugu)
- [ ] Mobile app (React Native / Expo)

---

## License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

## Acknowledgements

- [Supabase](https://supabase.com) — Backend infrastructure
- [shadcn/ui](https://ui.shadcn.com) — UI component library
- [Lucide](https://lucide.dev) — Icon library
- [Framer Motion](https://www.framer.com/motion/) — Animations

---

<p align="center">Built with ❤️ for better healthcare access</p>
