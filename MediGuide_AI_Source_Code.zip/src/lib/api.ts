import { supabase } from '@/db/supabase';
import type {
  Profile, Doctor, Appointment, MedicalReport,
  MedicineReminder, Notification, ChatMessage,
  ApptStatus, ReportStatus,
} from '@/types/types';

// ── PROFILES ──────────────────────────────────────────────────────────────────
export const getProfile = async (userId: string): Promise<Profile | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  if (error) { console.error('getProfile error:', error.message); return null; }
  return data;
};

export const updateProfile = async (userId: string, updates: Partial<Profile>): Promise<boolean> => {
  const { error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', userId);
  if (error) { console.error('updateProfile error:', error.message); return false; }
  return true;
};

// ── DOCTORS ───────────────────────────────────────────────────────────────────
export const getDoctors = async (department?: string, search?: string): Promise<Doctor[]> => {
  let query = supabase.from('doctors').select('*').order('rating', { ascending: false }).limit(50);
  if (department && department !== 'All Departments') query = query.eq('department', department);
  if (search) query = query.ilike('name', `%${search}%`);
  const { data, error } = await query;
  if (error) { console.error('getDoctors error:', error.message); return []; }
  return Array.isArray(data) ? data : [];
};

export const getDoctorById = async (id: string): Promise<Doctor | null> => {
  const { data, error } = await supabase.from('doctors').select('*').eq('id', id).maybeSingle();
  if (error) { console.error('getDoctorById error:', error.message); return null; }
  return data;
};

// ── APPOINTMENTS ──────────────────────────────────────────────────────────────
export const getAppointments = async (patientId: string): Promise<Appointment[]> => {
  const { data, error } = await supabase
    .from('appointments')
    .select('*')
    .eq('patient_id', patientId)
    .order('date', { ascending: false })
    .order('time', { ascending: true })
    .limit(50);
  if (error) { console.error('getAppointments error:', error.message); return []; }
  return Array.isArray(data) ? data : [];
};

export const getUpcomingAppointments = async (patientId: string): Promise<Appointment[]> => {
  const today = new Date().toISOString().split('T')[0];
  const { data, error } = await supabase
    .from('appointments')
    .select('*')
    .eq('patient_id', patientId)
    .gte('date', today)
    .not('status', 'eq', 'cancelled')
    .order('date', { ascending: true })
    .limit(10);
  if (error) { console.error('getUpcomingAppointments error:', error.message); return []; }
  return Array.isArray(data) ? data : [];
};

export const createAppointment = async (
  appt: Pick<Appointment, 'doctor_id' | 'doctor_name' | 'department' | 'date' | 'time' | 'type' | 'symptoms' | 'notes'>
): Promise<Appointment | null> => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase
    .from('appointments')
    .insert({ ...appt, patient_id: user.id, status: 'pending' })
    .select()
    .maybeSingle();
  if (error) { console.error('createAppointment error:', error.message); return null; }
  return data;
};

export const updateAppointmentStatus = async (id: string, status: ApptStatus): Promise<boolean> => {
  const { error } = await supabase.from('appointments').update({ status }).eq('id', id);
  if (error) { console.error('updateAppointmentStatus error:', error.message); return false; }
  return true;
};

export const cancelAppointment = async (id: string): Promise<boolean> =>
  updateAppointmentStatus(id, 'cancelled');

// ── MEDICAL REPORTS ───────────────────────────────────────────────────────────
export const getMedicalReports = async (patientId: string): Promise<MedicalReport[]> => {
  const { data, error } = await supabase
    .from('medical_reports')
    .select('*')
    .eq('patient_id', patientId)
    .order('date', { ascending: false })
    .limit(50);
  if (error) { console.error('getMedicalReports error:', error.message); return []; }
  return Array.isArray(data) ? data : [];
};

export const createMedicalReport = async (
  report: Omit<MedicalReport, 'id' | 'created_at'>
): Promise<MedicalReport | null> => {
  const { data, error } = await supabase
    .from('medical_reports')
    .insert(report)
    .select()
    .maybeSingle();
  if (error) { console.error('createMedicalReport error:', error.message); return null; }
  return data;
};

export const updateReportStatus = async (id: string, status: ReportStatus): Promise<boolean> => {
  const { error } = await supabase.from('medical_reports').update({ status }).eq('id', id);
  if (error) { console.error('updateReportStatus error:', error.message); return false; }
  return true;
};

// ── MEDICINE REMINDERS ────────────────────────────────────────────────────────
export const getMedicineReminders = async (patientId: string): Promise<MedicineReminder[]> => {
  const { data, error } = await supabase
    .from('medicine_reminders')
    .select('*')
    .eq('patient_id', patientId)
    .order('created_at', { ascending: true })
    .limit(50);
  if (error) { console.error('getMedicineReminders error:', error.message); return []; }
  return Array.isArray(data) ? data : [];
};

export const createMedicineReminder = async (
  reminder: Pick<MedicineReminder, 'name' | 'dosage' | 'frequency' | 'times'>
): Promise<MedicineReminder | null> => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase
    .from('medicine_reminders')
    .insert({
      patient_id: user.id,
      name: reminder.name,
      dosage: reminder.dosage,
      frequency: reminder.frequency,
      times: reminder.times,
      taken_today: reminder.times.map(() => false),
      color: 'bg-primary/10 text-primary',
    })
    .select()
    .maybeSingle();
  if (error) { console.error('createMedicineReminder error:', error.message); return null; }
  return data;
};

export const updateReminderTaken = async (
  id: string, taken_today: boolean[]
): Promise<boolean> => {
  const { error } = await supabase
    .from('medicine_reminders')
    .update({ taken_today })
    .eq('id', id);
  if (error) { console.error('updateReminderTaken error:', error.message); return false; }
  return true;
};

export const markMedicineTaken = async (id: string, taken: boolean): Promise<boolean> => {
  // taken_today is a boolean[] in the schema; we simplify to a single boolean flag
  const { error } = await supabase
    .from('medicine_reminders')
    .update({ taken_today: [taken] })
    .eq('id', id);
  if (error) { console.error('markMedicineTaken error:', error.message); return false; }
  return true;
};

export const deleteMedicineReminder = async (id: string): Promise<boolean> => {
  const { error } = await supabase.from('medicine_reminders').delete().eq('id', id);
  if (error) { console.error('deleteMedicineReminder error:', error.message); return false; }
  return true;
};

// ── NOTIFICATIONS ─────────────────────────────────────────────────────────────
export const getNotifications = async (userId: string): Promise<Notification[]> => {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) { console.error('getNotifications error:', error.message); return []; }
  return Array.isArray(data) ? data : [];
};

export const markNotificationRead = async (id: string): Promise<boolean> => {
  const { error } = await supabase.from('notifications').update({ read: true }).eq('id', id);
  if (error) { console.error('markNotificationRead error:', error.message); return false; }
  return true;
};

export const markAllNotificationsRead = async (userId: string): Promise<boolean> => {
  const { error } = await supabase
    .from('notifications')
    .update({ read: true })
    .eq('user_id', userId);
  if (error) { console.error('markAllNotificationsRead error:', error.message); return false; }
  return true;
};

export const deleteNotification = async (id: string): Promise<boolean> => {
  const { error } = await supabase.from('notifications').delete().eq('id', id);
  if (error) { console.error('deleteNotification error:', error.message); return false; }
  return true;
};

export const createNotification = async (
  notif: Omit<Notification, 'id' | 'user_id' | 'read' | 'created_at'>
): Promise<boolean> => {
  const { error } = await supabase.from('notifications').insert(notif);
  if (error) { console.error('createNotification error:', error.message); return false; }
  return true;
};

// ── CHAT MESSAGES ──────────────────────────────────────────────────────────────
export const getChatMessages = async (userId: string): Promise<ChatMessage[]> => {
  const { data, error } = await supabase
    .from('chat_messages')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: true })
    .limit(100);
  if (error) { console.error('getChatMessages error:', error.message); return []; }
  return Array.isArray(data) ? data : [];
};

export const saveChatMessage = async (
  msg: { role: 'user' | 'assistant'; content: string }
): Promise<ChatMessage | null> => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data, error } = await supabase
    .from('chat_messages')
    .insert({ user_id: user.id, role: msg.role, content: msg.content })
    .select()
    .maybeSingle();
  if (error) { console.error('saveChatMessage error:', error.message); return null; }
  return data;
};

export const clearChatHistory = async (userId: string): Promise<boolean> => {
  const { error } = await supabase.from('chat_messages').delete().eq('user_id', userId);
  if (error) { console.error('clearChatHistory error:', error.message); return false; }
  return true;
};
