import React, { useEffect, useState, useCallback } from 'react';
import { motion } from 'motion/react';
import { CheckCircle, XCircle, Clock, Calendar, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import DoctorLayout from '@/components/layouts/DoctorLayout';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { Appointment, ApptStatus } from '@/types/types';

const FILTERS: { label: string; value: string }[] = [
  { label: 'All',       value: 'all' },
  { label: 'Pending',   value: 'pending' },
  { label: 'Confirmed', value: 'confirmed' },
  { label: 'Completed', value: 'completed' },
  { label: 'Cancelled', value: 'cancelled' },
];

const statusConfig: Record<string, { label: string; class: string }> = {
  pending:       { label: 'Pending',     class: 'bg-warning/10 text-warning border-warning/20' },
  confirmed:     { label: 'Confirmed',   class: 'bg-primary/10 text-primary border-primary/20' },
  'in-progress': { label: 'In Progress', class: 'bg-accent/10 text-accent border-accent/20' },
  completed:     { label: 'Completed',   class: 'bg-green-500/10 text-green-600 border-green-200' },
  cancelled:     { label: 'Cancelled',   class: 'bg-muted text-muted-foreground border-border' },
};

const DoctorAppointmentsPage: React.FC = () => {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [updating, setUpdating] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('appointments')
      .select('*')
      .order('date', { ascending: false })
      .order('time', { ascending: true })
      .limit(200);
    setAppointments(data || []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateStatus = async (id: string, status: ApptStatus) => {
    setUpdating(id);
    const { error } = await supabase.from('appointments').update({ status }).eq('id', id);
    if (error) { toast.error('Update failed.'); } else {
      toast.success(`Appointment ${status}.`);
      setAppointments(prev => prev.map(a => a.id === id ? { ...a, status } : a));
    }
    setUpdating(null);
  };

  const filtered = appointments.filter(a => {
    const matchStatus = filter === 'all' || a.status === filter;
    const matchSearch = !search || a.doctor_name?.toLowerCase().includes(search.toLowerCase()) ||
      a.department?.toLowerCase().includes(search.toLowerCase()) ||
      a.symptoms?.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  return (
    <DoctorLayout title="Appointments" subtitle="Manage all patient appointments">
      <div className="space-y-5 max-w-5xl">
        {/* Search + filter */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search by patient, department, or symptoms…"
              value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Badge variant="secondary" className="self-center text-sm px-3 py-1.5 shrink-0">
            {filtered.length} result{filtered.length !== 1 ? 's' : ''}
          </Badge>
        </div>

        {/* Status filter pills */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {FILTERS.map(f => (
            <button key={f.value} onClick={() => setFilter(f.value)}
              className={cn('shrink-0 px-3 py-1.5 rounded-full text-sm font-medium transition-colors border whitespace-nowrap',
                filter === f.value
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'border-border hover:border-primary/40 hover:bg-primary/5 text-muted-foreground')}>
              {f.label}
              {f.value !== 'all' && (
                <span className="ml-1.5 opacity-60 text-xs">
                  ({appointments.filter(a => a.status === f.value).length})
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Appointment cards */}
        {loading ? (
          <div className="space-y-3">
            {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-24 w-full" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <Calendar className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="text-sm text-muted-foreground">No appointments found</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((appt, i) => {
              const conf = statusConfig[appt.status] || statusConfig.pending;
              const isUpdating = updating === appt.id;
              return (
                <motion.div key={appt.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i * 0.04, 0.3) }}>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                        {/* Info */}
                        <div className="flex-1 min-w-0 space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-sm font-semibold">{appt.doctor_name || 'Patient'}</span>
                            <Badge className={cn('text-[11px]', conf.class)}>{conf.label}</Badge>
                            <span className="text-xs text-muted-foreground">{appt.type}</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                            <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{appt.date}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{appt.time}</span>
                            <span>{appt.department}</span>
                          </div>
                          {appt.symptoms && (
                            <p className="text-xs text-muted-foreground italic line-clamp-1">"{appt.symptoms}"</p>
                          )}
                        </div>

                        {/* Actions */}
                        {appt.status !== 'completed' && appt.status !== 'cancelled' && (
                          <div className="flex gap-2 shrink-0">
                            {appt.status === 'pending' && (
                              <Button variant="outline" size="sm" className="h-8 text-xs text-primary border-primary/30"
                                disabled={isUpdating} onClick={() => updateStatus(appt.id, 'confirmed')}>
                                <CheckCircle className="w-3 h-3 mr-1" />Confirm
                              </Button>
                            )}
                            <Button variant="outline" size="sm" className="h-8 text-xs text-green-600 border-green-200"
                              disabled={isUpdating} onClick={() => updateStatus(appt.id, 'completed')}>
                              <CheckCircle className="w-3 h-3 mr-1" />Complete
                            </Button>
                            <Button variant="outline" size="sm" className="h-8 text-xs text-destructive border-destructive/20"
                              disabled={isUpdating} onClick={() => updateStatus(appt.id, 'cancelled')}>
                              <XCircle className="w-3 h-3 mr-1" />Cancel
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </DoctorLayout>
  );
};

export default DoctorAppointmentsPage;
