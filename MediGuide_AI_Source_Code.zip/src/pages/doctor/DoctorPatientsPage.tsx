import React, { useEffect, useState, useCallback } from 'react';
import { motion } from 'motion/react';
import { Search, User, Phone, Mail, Calendar } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import DoctorLayout from '@/components/layouts/DoctorLayout';
import { supabase } from '@/db/supabase';

interface PatientSummary {
  id: string;
  name: string;
  email: string;
  phone: string;
  lastDate: string;
  totalAppts: number;
}

const DoctorPatientsPage: React.FC = () => {
  const [patients, setPatients] = useState<PatientSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);

    // Fetch all appointments to get unique patient_ids
    const { data: appts } = await supabase
      .from('appointments')
      .select('patient_id, date')
      .order('date', { ascending: false });

    if (!appts || appts.length === 0) { setPatients([]); setLoading(false); return; }

    // Aggregate per patient
    const map = new Map<string, { lastDate: string; count: number }>();
    for (const a of appts) {
      const existing = map.get(a.patient_id);
      if (!existing) {
        map.set(a.patient_id, { lastDate: a.date, count: 1 });
      } else {
        existing.count += 1;
        if (a.date > existing.lastDate) existing.lastDate = a.date;
      }
    }

    const patientIds = Array.from(map.keys());
    if (patientIds.length === 0) { setPatients([]); setLoading(false); return; }

    // Fetch profiles
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, name, email, phone')
      .in('id', patientIds);

    const result: PatientSummary[] = (profiles || []).map(p => ({
      id: p.id,
      name: p.name || 'Unknown Patient',
      email: p.email || '',
      phone: p.phone || '',
      lastDate: map.get(p.id)?.lastDate || '',
      totalAppts: map.get(p.id)?.count || 0,
    }));

    result.sort((a, b) => b.lastDate.localeCompare(a.lastDate));
    setPatients(result);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = patients.filter(p =>
    !search ||
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <DoctorLayout title="My Patients" subtitle="Patients who have booked appointments">
      <div className="space-y-5 max-w-4xl">
        {/* Search */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search by patient name or email…"
              value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Badge variant="secondary" className="self-center text-sm px-3 py-1.5 shrink-0">
            {filtered.length} patient{filtered.length !== 1 ? 's' : ''}
          </Badge>
        </div>

        {/* Patient cards */}
        {loading ? (
          <div className="space-y-3">
            {[1,2,3,4].map(i => <Skeleton key={i} className="h-20 w-full" />)}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <User className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="text-sm text-muted-foreground">
              {search ? 'No patients match your search' : 'No patients yet'}
            </p>
            {!search && (
              <p className="text-xs text-muted-foreground/60 mt-1">
                Patients will appear here once they book appointments
              </p>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((patient, i) => (
              <motion.div key={patient.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i * 0.05, 0.4) }}>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <Avatar className="w-11 h-11 shrink-0">
                        <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                          {patient.name[0]?.toUpperCase()}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{patient.name}</p>
                        <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1">
                          {patient.email && (
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Mail className="w-3 h-3 shrink-0" />
                              <span className="truncate max-w-[180px]">{patient.email}</span>
                            </span>
                          )}
                          {patient.phone && (
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Phone className="w-3 h-3 shrink-0" />{patient.phone}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="shrink-0 text-right space-y-1">
                        <div className="flex items-center gap-1.5 justify-end">
                          <Badge variant="secondary" className="text-xs">
                            {patient.totalAppts} appt{patient.totalAppts !== 1 ? 's' : ''}
                          </Badge>
                        </div>
                        {patient.lastDate && (
                          <p className="text-[11px] text-muted-foreground flex items-center gap-1 justify-end">
                            <Calendar className="w-3 h-3" />
                            Last: {new Date(patient.lastDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </DoctorLayout>
  );
};

export default DoctorPatientsPage;
