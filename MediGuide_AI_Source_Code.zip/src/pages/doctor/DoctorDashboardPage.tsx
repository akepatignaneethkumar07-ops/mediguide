import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Calendar, Users, Clock, CheckCircle, ChevronRight, Stethoscope } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import DoctorLayout from '@/components/layouts/DoctorLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import type { Appointment } from '@/types/types';

const statusConfig: Record<string, { label: string; class: string }> = {
  pending:     { label: 'Pending',    class: 'bg-warning/10 text-warning border-warning/20' },
  confirmed:   { label: 'Confirmed',  class: 'bg-primary/10 text-primary border-primary/20' },
  'in-progress': { label: 'In Progress', class: 'bg-accent/10 text-accent border-accent/20' },
  completed:   { label: 'Completed',  class: 'bg-green-500/10 text-green-600 border-green-200' },
  cancelled:   { label: 'Cancelled',  class: 'bg-muted text-muted-foreground border-border' },
};

const DoctorDashboardPage: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [patientCount, setPatientCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const { data } = await supabase
        .from('appointments')
        .select('*')
        .order('date', { ascending: false })
        .order('time', { ascending: true })
        .limit(100);
      const appts: Appointment[] = data || [];
      setAppointments(appts);
      const uniquePatients = new Set(appts.map(a => a.patient_id));
      setPatientCount(uniquePatients.size);
      setLoading(false);
    };
    load();
  }, []);

  const todayAppts = appointments.filter(a => a.date === today);
  const upcomingAppts = appointments.filter(a => a.date > today && a.status !== 'cancelled');

  const stats = [
    { label: "Today's Appointments", value: loading ? '…' : todayAppts.length, icon: Calendar, color: 'text-primary' },
    { label: 'Upcoming',             value: loading ? '…' : upcomingAppts.length, icon: Clock,    color: 'text-warning' },
    { label: 'Total Patients',       value: loading ? '…' : patientCount,         icon: Users,    color: 'text-green-600' },
    { label: 'Completed',            value: loading ? '…' : appointments.filter(a => a.status === 'completed').length, icon: CheckCircle, color: 'text-accent' },
  ];

  return (
    <DoctorLayout title="Dashboard" subtitle={`Welcome back, ${profile?.name || 'Doctor'}`}>
      <div className="space-y-6 max-w-5xl">
        {/* Welcome banner */}
        <motion.div
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-xl border border-border bg-muted/30"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
              <Stethoscope className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-semibold">{profile?.name || 'Doctor'}</p>
              <p className="text-sm text-muted-foreground">
                {todayAppts.length} appointment{todayAppts.length !== 1 ? 's' : ''} scheduled for today
              </p>
            </div>
          </div>
          <div className="flex gap-2 shrink-0">
            <Button size="sm" onClick={() => navigate('/doctor-appointments')}>
              <Calendar className="w-3.5 h-3.5 mr-1.5" /> View All
            </Button>
            <Button size="sm" variant="outline" onClick={() => navigate('/doctor-patients')}>
              <Users className="w-3.5 h-3.5 mr-1.5" /> Patients
            </Button>
          </div>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs text-muted-foreground leading-tight">{s.label}</p>
                      <Icon className={cn('w-4 h-4 shrink-0', s.color)} />
                    </div>
                    {loading ? <Skeleton className="h-7 w-10" /> : <p className="text-2xl font-bold">{s.value}</p>}
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Today's appointments */}
        <Card>
          <CardHeader className="pb-3 flex flex-row items-center justify-between">
            <CardTitle className="text-base">Today's Appointments</CardTitle>
            <Badge variant="secondary" className="text-xs">
              {new Date().toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })}
            </Badge>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="space-y-3">
                {[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
              </div>
            ) : todayAppts.length === 0 ? (
              <div className="text-center py-10">
                <Calendar className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-40" />
                <p className="text-sm text-muted-foreground">No appointments today</p>
              </div>
            ) : (
              <div className="space-y-2">
                {todayAppts.slice(0, 8).map((appt, i) => {
                  const conf = statusConfig[appt.status] || statusConfig.pending;
                  return (
                    <motion.div key={appt.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-3 p-3 rounded-xl border border-border hover:bg-muted/30 transition-colors">
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0 text-sm font-semibold text-primary">
                        {(appt.doctor_name || 'P')[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{appt.doctor_name || 'Patient'}</p>
                        <p className="text-xs text-muted-foreground">{appt.department} · {appt.time}</p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <Badge className={cn('text-xs', conf.class)}>{conf.label}</Badge>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => navigate('/doctor-appointments')}>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </motion.div>
                  );
                })}
                {todayAppts.length > 8 && (
                  <button onClick={() => navigate('/doctor-appointments')}
                    className="w-full py-2 text-xs text-primary hover:underline text-center">
                    View {todayAppts.length - 8} more →
                  </button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DoctorLayout>
  );
};

export default DoctorDashboardPage;
