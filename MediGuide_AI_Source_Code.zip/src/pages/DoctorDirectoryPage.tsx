import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Search, MapPin, Award, IndianRupee, Building2, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import AppLayout from '@/components/layouts/AppLayout';
import { getDoctors } from '@/lib/api';
import type { Doctor } from '@/types/types';
import { useNavigate } from 'react-router-dom';
import { cn, formatINR } from '@/lib/utils';

const DEPARTMENTS = [
  'All Departments', 'Cardiology', 'Neurology', 'Oncology', 'Orthopedics',
  'Gastroenterology', 'Endocrinology', 'Pulmonology', 'Nephrology',
  'Psychiatry', 'Pediatrics', 'Dermatology', 'Gynaecology',
];

const availabilityConfig: Record<string, { label: string; class: string }> = {
  available: { label: 'Available', class: 'bg-green-500/10 text-green-600 border-green-200' },
  busy: { label: 'Busy', class: 'bg-warning/10 text-warning border-warning/20' },
  offline: { label: 'Offline', class: 'bg-muted text-muted-foreground border-border' },
};

const DoctorDirectoryPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [activeDept, setActiveDept] = useState('All Departments');
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    getDoctors(activeDept, search)
      .then(setDoctors)
      .finally(() => setLoading(false));
  }, [activeDept, search]);

  return (
    <AppLayout title="Doctor Directory">
      <div className="space-y-6 max-w-7xl">
        {/* Pay-at-hospital notice */}
        <div className="flex items-start gap-3 px-4 py-3 rounded-xl border border-border bg-muted/40">
          <Building2 className="w-4 h-4 text-primary mt-0.5 shrink-0" />
          <p className="text-sm text-muted-foreground leading-relaxed">
            <span className="font-medium text-foreground">All consultation fees are paid directly at the hospital.</span>
            {' '}No online payment is required. The OP fee shown is the outpatient consultation charge payable at the hospital counter.
          </p>
        </div>

        {/* Search */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search by doctor name or specialization..."
              value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Badge variant="secondary" className="self-center text-sm px-3 py-1.5">
            {doctors.length} doctors found
          </Badge>
        </div>

        {/* Department Filters */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {DEPARTMENTS.map(dept => (
            <button key={dept} onClick={() => setActiveDept(dept)}
              className={cn('shrink-0 px-3 py-1.5 rounded-full text-sm font-medium transition-colors border',
                activeDept === dept ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:border-primary/40 hover:bg-primary/5')}>
              {dept}
            </button>
          ))}
        </div>

        {/* Doctor Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
            {[1,2,3,4,5,6].map(i => (
              <Card key={i}><CardContent className="p-5 space-y-3">
                <div className="flex gap-4"><Skeleton className="w-16 h-16 rounded-xl" /><div className="flex-1 space-y-2"><Skeleton className="h-4 w-3/4" /><Skeleton className="h-3 w-1/2" /></div></div>
                <Skeleton className="h-20 w-full" /><Skeleton className="h-9 w-full" />
              </CardContent></Card>
            ))}
          </div>
        ) : doctors.length === 0 ? (
          <div className="text-center py-16">
            <Search className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="font-medium text-muted-foreground">No doctors found</p>
            <p className="text-sm text-muted-foreground/60 mt-1">Try adjusting your search or filters</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
            {doctors.map((doc, i) => {
              const avail = availabilityConfig[doc.availability] || availabilityConfig.offline;
              return (
                <motion.div key={doc.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                  <Card className="h-full hover:shadow-hover transition-shadow">
                    <CardContent className="p-5 flex flex-col h-full">
                      <div className="flex items-start gap-4 mb-4">
                        <img src={doc.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(doc.name)}&background=2563EB&color=fff`}
                          alt={doc.name} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <h3 className="font-semibold text-sm truncate">{doc.name}</h3>
                              <p className="text-xs text-muted-foreground">{doc.specialization}</p>
                            </div>
                            <Badge className={cn('text-xs shrink-0', avail.class)}>{avail.label}</Badge>
                          </div>
                          <div className="mt-1.5 space-y-0.5">
                            <span className="text-xs text-muted-foreground">{doc.experience} yrs experience</span>
                            {(doc as any).hospital_name && (
                              <p className="text-[11px] text-muted-foreground/70 flex items-center gap-1 truncate">
                                <MapPin className="w-2.5 h-2.5 shrink-0" />{(doc as any).hospital_name}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed mb-4 flex-1">{doc.bio}</p>
                      <div className="grid grid-cols-3 gap-2 mb-3">
                        <div className="text-center p-2 bg-muted/50 rounded-lg">
                          <Award className="w-3 h-3 text-primary mx-auto mb-0.5" />
                          <p className="text-xs font-semibold">{doc.experience}yr</p>
                          <p className="text-[10px] text-muted-foreground">Experience</p>
                        </div>
                        <div className="text-center p-2 bg-muted/50 rounded-lg">
                          <IndianRupee className="w-3 h-3 text-primary mx-auto mb-0.5" />
                          <p className="text-xs font-semibold">{formatINR(doc.fee)}</p>
                          <p className="text-[10px] text-muted-foreground">OP Fee</p>
                        </div>
                        <div className="text-center p-2 bg-muted/50 rounded-lg">
                          <MapPin className="w-3 h-3 text-muted-foreground mx-auto mb-0.5" />
                          <p className="text-[10px] font-medium truncate">{doc.next_slot || 'TBD'}</p>
                          <p className="text-[10px] text-muted-foreground">Next Slot</p>
                        </div>
                      </div>
                      {/* Pay-at-hospital tag */}
                      <div className="flex items-center gap-1.5 mb-3 px-2 py-1.5 rounded-lg bg-muted/60">
                        <Building2 className="w-3 h-3 text-muted-foreground shrink-0" />
                        <p className="text-[11px] text-muted-foreground">Pay {formatINR(doc.fee)} at hospital · No online payment</p>
                      </div>
                      <Button className="w-full" size="sm" disabled={doc.availability === 'offline'}
                        onClick={() => navigate('/appointments')}>
                        {doc.availability === 'offline' ? 'Currently Unavailable' : 'Book Appointment'}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </AppLayout>
  );
};



export default DoctorDirectoryPage;
