import React, { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle2, Activity, HeartPulse, BrainCircuit, ListChecks, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import AppLayout from '@/components/layouts/AppLayout';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

const REPORT_TRANSLATIONS: Record<string, any> = {
  en: {
    summary: 'Your Complete Blood Count (CBC) and Lipid Profile show mostly normal ranges. However, your LDL cholesterol is slightly elevated, and your Vitamin D levels are below the optimal range.',
    metrics: [
      { name: 'Hemoglobin', value: '14.2 g/dL', status: 'normal' },
      { name: 'Total Cholesterol', value: '210 mg/dL', status: 'borderline' },
      { name: 'LDL (Bad) Cholesterol', value: '135 mg/dL', status: 'elevated' },
      { name: 'Vitamin D (25-OH)', value: '18 ng/mL', status: 'low' },
      { name: 'Fasting Blood Sugar', value: '92 mg/dL', status: 'normal' }
    ],
    suggestions: [
      'Increase intake of Omega-3 rich foods (e.g., salmon, walnuts) to help manage cholesterol.',
      'Consider a daily Vitamin D supplement after consulting with your doctor.',
      'Engage in 30 minutes of moderate aerobic exercise 5 days a week.',
      'Reduce saturated fats and trans fats in your diet.'
    ],
    followUp: 'Schedule a routine follow-up with your primary care physician in 3-6 months to monitor your lipid profile and Vitamin D levels.'
  },
  hi: {
    summary: 'आपकी पूर्ण रक्त गणना (CBC) और लिपिड प्रोफ़ाइल ज्यादातर सामान्य सीमा दिखाते हैं। हालांकि, आपका LDL कोलेस्ट्रॉल थोड़ा बढ़ा हुआ है, और आपका विटामिन डी का स्तर इष्टतम सीमा से नीचे है।',
    metrics: [
      { name: 'हीमोग्लोबिन', value: '14.2 g/dL', status: 'normal' },
      { name: 'कुल कोलेस्ट्रॉल', value: '210 mg/dL', status: 'borderline' },
      { name: 'LDL (खराब) कोलेस्ट्रॉल', value: '135 mg/dL', status: 'elevated' },
      { name: 'विटामिन डी (25-OH)', value: '18 ng/mL', status: 'low' },
      { name: 'उपवास रक्त शर्करा', value: '92 mg/dL', status: 'normal' }
    ],
    suggestions: [
      'कोलेस्ट्रॉल को प्रबंधित करने में मदद के लिए ओमेगा-3 युक्त खाद्य पदार्थों (जैसे, सामन, अखरोट) का सेवन बढ़ाएं।',
      'अपने डॉक्टर से परामर्श के बाद दैनिक विटामिन डी सप्लीमेंट पर विचार करें।',
      'सप्ताह में 5 दिन 30 मिनट का मध्यम एरोबिक व्यायाम करें।',
      'अपने आहार में संतृप्त वसा और ट्रांस वसा कम करें।'
    ],
    followUp: 'अपने लिपिड प्रोफ़ाइल और विटामिन डी के स्तर की निगरानी के लिए 3-6 महीनों में अपने प्राथमिक देखभाल चिकित्सक के साथ नियमित अनुवर्ती कार्रवाई निर्धारित करें।'
  },
  te: {
    summary: 'మీ కంప్లీట్ బ్లడ్ కౌంట్ (CBC) మరియు లిపిడ్ ప్రొఫైల్ సాధారణంగా సాధారణ పరిధులను చూపుతున్నాయి. అయితే, మీ LDL కొలెస్ట్రాల్ కొద్దిగా పెరిగింది మరియు మీ విటమిన్ D స్థాయిలు వాంఛనీయ పరిధి కంటే తక్కువగా ఉన్నాయి.',
    metrics: [
      { name: 'హీమోగ్లోబిన్', value: '14.2 g/dL', status: 'normal' },
      { name: 'మొత్తం కొలెస్ట్రాల్', value: '210 mg/dL', status: 'borderline' },
      { name: 'LDL (చెడు) కొలెస్ట్రాల్', value: '135 mg/dL', status: 'elevated' },
      { name: 'విటమిన్ D (25-OH)', value: '18 ng/mL', status: 'low' },
      { name: 'ఫాస్టింగ్ బ్లడ్ షుగర్', value: '92 mg/dL', status: 'normal' }
    ],
    suggestions: [
      'కొలెస్ట్రాల్‌ను నిర్వహించడంలో సహాయపడటానికి ఒమేగా-3 అధికంగా ఉండే ఆహారాలు (ఉదా., సాల్మన్, వాల్‌నట్స్) తీసుకోవడం పెంచండి.',
      'మీ వైద్యుడిని సంప్రదించిన తర్వాత రోజువారీ విటమిన్ D సప్లిమెంట్‌ను పరిగణించండి.',
      'వారానికి 5 రోజులు 30 నిమిషాల మోడరేట్ ఏరోబిక్ వ్యాయామం చేయండి.',
      'మీ ఆహారంలో సంతృప్త కొవ్వులు మరియు ట్రాన్స్ ఫ్యాట్స్ తగ్గించండి.'
    ],
    followUp: 'మీ లిపిడ్ ప్రొఫైల్ మరియు విటమిన్ D స్థాయిలను పర్యవేక్షించడానికి 3-6 నెలల్లో మీ ప్రాథమిక సంరక్షణ వైద్యునితో సాధారణ ఫాలో-అప్‌ను షెడ్యూల్ చేయండి.'
  },
  ta: {
    summary: 'உங்கள் முழுமையான இரத்த எண்ணிக்கை (CBC) மற்றும் லிப்பிட் சுயவிவரம் பெரும்பாலும் சாதாரண வரம்புகளைக் காட்டுகின்றன. இருப்பினும், உங்கள் LDL கொலஸ்ட்ரால் சற்று அதிகரித்துள்ளது, மேலும் உங்கள் வைட்டமின் டி அளவுகள் உகந்த வரம்பிற்கு கீழே உள்ளன.',
    metrics: [
      { name: 'ஹீமோகுளோபின்', value: '14.2 g/dL', status: 'normal' },
      { name: 'மொத்த கொலஸ்ட்ரால்', value: '210 mg/dL', status: 'borderline' },
      { name: 'LDL (கெட்ட) கொலஸ்ட்ரால்', value: '135 mg/dL', status: 'elevated' },
      { name: 'வைட்டமின் டி (25-OH)', value: '18 ng/mL', status: 'low' },
      { name: 'உண்ணாவிரத இரத்த சர்க்கரை', value: '92 mg/dL', status: 'normal' }
    ],
    suggestions: [
      'கொலஸ்ட்ராலைக் கட்டுப்படுத்த ஒமேகா-3 நிறைந்த உணவுகளை (உதாரணமாக, சால்மன், அக்ரூட் பருப்புகள்) உட்கொள்வதை அதிகரிக்கவும்.',
      'உங்கள் மருத்துவரை அணுகிய பிறகு தினசரி வைட்டமின் டி சப்ளிமெண்ட்டைக் கவனியுங்கள்.',
      'வாரத்தில் 5 நாட்கள் 30 நிமிட மிதமான ஏரோபிக் பயிற்சியில் ஈடுபடுங்கள்.',
      'உங்கள் உணவில் நிறைவுற்ற கொழுப்புகள் மற்றும் டிரான்ஸ் கொழுப்புகளை குறைக்கவும்.'
    ],
    followUp: 'உங்கள் லிப்பிட் சுயவிவரம் மற்றும் வைட்டமின் டி அளவைக் கண்காணிக்க 3-6 மாதங்களில் உங்கள் முதன்மை சிகிச்சை மருத்துவரிடம் வழக்கமான பின்தொடர்தலை திட்டமிடுங்கள்.'
  }
};

const ReportMakerPage: React.FC = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isRequesting, setIsRequesting] = useState(false);
  const [language, setLanguage] = useState('en');
  const [analysisResult, setAnalysisResult] = useState<any | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const simulateAnalysis = () => {
    setIsAnalyzing(true);
    setAnalysisResult(null);
    setTimeout(() => {
      setAnalysisResult(REPORT_TRANSLATIONS[language] || REPORT_TRANSLATIONS['en']);
      setIsAnalyzing(false);
    }, 3000);
  };

  const handleSendToDoctor = () => {
    setIsRequesting(true);
    setTimeout(() => {
      toast.success('Report analysis sent to doctor for confirmation successfully!');
      setIsRequesting(false);
    }, 1500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    simulateAnalysis();
  };

  return (
    <AppLayout title="AI Medical Report Maker">
      <div className="max-w-5xl space-y-6">
        <Card className="border-primary/20 shadow-sm overflow-hidden">
          <div className="bg-primary/5 p-8 border-b border-border text-center space-y-3">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-2">
              <BrainCircuit className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold text-primary">Understand Your Lab Results</h2>
            <p className="text-sm text-muted-foreground max-w-xl mx-auto">
              Upload your medical reports, lab results, or health documents. Our AI will analyze the data, translate complex medical jargon into plain English, and provide actionable health suggestions.
            </p>
            
            <div className="flex justify-center mt-4">
              <div className="flex items-center gap-3">
                <span className="text-sm font-medium text-foreground">Analysis Language:</span>
                <Select value={language} onValueChange={(val) => {
                  setLanguage(val);
                  if (analysisResult) {
                    setAnalysisResult(REPORT_TRANSLATIONS[val] || REPORT_TRANSLATIONS['en']);
                  }
                }}>
                  <SelectTrigger className="w-40 bg-background">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="hi">Hindi (हिंदी)</SelectItem>
                    <SelectItem value="te">Telugu (తెలుగు)</SelectItem>
                    <SelectItem value="ta">Tamil (தமிழ்)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <CardContent className="p-8">
            <div className="flex justify-center">
              <Button 
                size="lg" 
                className="h-32 w-full max-w-md flex flex-col items-center justify-center gap-3 border-dashed border-2 text-lg"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                disabled={isAnalyzing}
              >
                <Upload className="w-8 h-8 text-primary" />
                <span>Upload Report PDF / Image</span>
                <span className="text-xs font-normal text-muted-foreground">Supports PDF, JPG, PNG</span>
              </Button>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="application/pdf,image/*"
                onChange={handleFileUpload}
              />
            </div>
          </CardContent>
        </Card>

        {isAnalyzing && (
          <Card>
            <CardContent className="p-10 text-center space-y-5">
              <div className="flex justify-center space-x-2 mb-4">
                <div className="w-3 h-3 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-3 h-3 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-3 h-3 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
              <h3 className="text-lg font-semibold text-primary">AI is analyzing your report...</h3>
              <p className="text-sm text-muted-foreground">Extracting biomarkers, comparing with standard ranges, and generating health suggestions.</p>
            </CardContent>
          </Card>
        )}

        <AnimatePresence>
          {analysisResult && !isAnalyzing && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid lg:grid-cols-3 gap-6"
            >
              <div className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader className="bg-primary/5 pb-4 border-b border-border">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <FileText className="w-5 h-5 text-primary" /> Executive Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-sm leading-relaxed text-foreground">
                      {analysisResult.summary}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="bg-primary/5 pb-4 border-b border-border">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ListChecks className="w-5 h-5 text-primary" /> Actionable Suggestions
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ul className="space-y-3">
                      {analysisResult.suggestions.map((suggestion: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-3">
                          <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                          <span className="text-sm text-muted-foreground leading-relaxed">{suggestion}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <div className="mt-6 flex justify-end">
                  <Button onClick={handleSendToDoctor} disabled={isRequesting} className="w-full sm:w-auto">
                    <Send className="w-4 h-4 mr-2" />
                    {isRequesting ? 'Sending Request...' : 'Send to Doctor for Confirmation'}
                  </Button>
                </div>
              </div>

              <div className="space-y-6">
                <Card>
                  <CardHeader className="bg-primary/5 pb-4 border-b border-border">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Activity className="w-5 h-5 text-primary" /> Key Metrics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="divide-y divide-border">
                      {analysisResult.metrics.map((metric: any, idx: number) => (
                        <div key={idx} className="p-4 flex items-center justify-between">
                          <div>
                            <p className="text-sm font-medium">{metric.name}</p>
                            <p className="text-xs text-muted-foreground mt-1">{metric.value}</p>
                          </div>
                          <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-1 rounded-full ${
                            metric.status === 'normal' ? 'bg-green-500/10 text-green-600' :
                            metric.status === 'borderline' ? 'bg-warning/10 text-warning' :
                            'bg-destructive/10 text-destructive'
                          }`}>
                            {metric.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Alert className="bg-blue-500/5 text-blue-700 border-blue-500/20">
                  <HeartPulse className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="text-xs ml-2 mt-1 font-medium">
                    {analysisResult.followUp}
                  </AlertDescription>
                </Alert>
              </div>

              <div className="lg:col-span-3">
                <Alert className="bg-muted text-muted-foreground border-border">
                  <AlertDescription className="text-xs text-center">
                    <strong>Disclaimer:</strong> This AI-generated report summary is intended for informational and educational purposes only. It is not a substitute for professional medical advice, diagnosis, or treatment.
                  </AlertDescription>
                </Alert>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </AppLayout>
  );
};

export default ReportMakerPage;
