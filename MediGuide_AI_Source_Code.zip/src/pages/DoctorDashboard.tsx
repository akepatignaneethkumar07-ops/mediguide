import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Calendar, Users, FileText, Clock, CheckCircle, XCircle,
  RotateCcw, Bot, ChevronRight, Stethoscope, Plus,
  TrendingUp, Star, Edit,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import AppLayout from '@/components/layouts/AppLayout';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const patientList: any[] = [];
const prescriptions: any[] = [];

const apptStatusConfig = {
  completed: { icon: CheckCircle, class: 'text-green-600 bg-green-500/10', label: 'Completed' },
  'in-progress': { icon: Clock, class: 'text-primary bg-primary/10', label: 'In Progress' },
  waiting: { icon: RotateCcw, class: 'text-warning bg-warning/10', label: 'Waiting' },
  confirmed: { icon: CheckCircle, class: 'text-accent bg-accent/10', label: 'Confirmed' },
};

type ApptStatus = 'completed' | 'in-progress' | 'waiting' | 'confirmed' | 'cancelled';

interface Appointment {
  id: string;
  patient: string;
  age: number;
  time: string;
  doctor: string;
  dept: string;
  status: ApptStatus;
}

const DoctorDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [apptList, setApptList] = useState<Appointment[]>([]);

  const todayStats = [
    { label: "Today's Appointments", value: apptList.length, icon: Calendar, color: 'text-primary' },
    { label: 'Patients Seen', value: apptList.filter(a => a.status === 'completed').length, icon: CheckCircle, color: 'text-green-600' },
    { label: 'Pending', value: apptList.filter(a => a.status === 'waiting' || a.status === 'confirmed').length, icon: Clock, color: 'text-warning' },
    { label: 'Avg. Rating', value: '4.9', icon: Star, color: 'text-yellow-500' },
  ];

  const handleAction = (id: string, action: 'complete' | 'cancel') => {
    setApptList(prev => prev.map(a => a.id === id
      ? { ...a, status: action === 'complete' ? 'completed' as const : 'cancelled' as const }
      : a
    ));
    toast.success(action === 'complete' ? 'Appointment marked complete' : 'Appointment cancelled');
  };

  return (
    <AppLayout title="Doctor Dashboard" subtitle="Dr. Emily Chen · Cardiology">
      <div className="space-y-6 max-w-7xl">
        {/* Welcome */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-primary rounded-xl text-primary-foreground"
        >
          <div className="flex items-center gap-4">
            <img
              src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=100&h=100&fit=crop"
              alt="Doctor"
              className="w-14 h-14 rounded-full object-cover border-2 border-white/30"
            />
            <div>
              <p className="text-sm text-primary-foreground/70">Good morning,</p>
              <h2 className="text-xl font-bold">Dr. Emily Chen</h2>
              <p className="text-sm text-primary-foreground/70">Cardiology · {apptList.length} appointments today</p>
            </div>
          </div>
          <Button variant="secondary" size="sm" onClick={() => navigate('/chat')}>
            <Bot className="w-4 h-4 mr-1.5" /> AI Clinical Assistant
          </Button>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {todayStats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <motion.div key={stat.label} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs text-muted-foreground">{stat.label}</p>
                      <Icon className={cn('w-4 h-4', stat.color)} />
                    </div>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <Tabs defaultValue="appointments" className="space-y-4">
          <TabsList>
            <TabsTrigger value="appointments"><Calendar className="w-3.5 h-3.5 mr-1.5" />Appointments</TabsTrigger>
            <TabsTrigger value="patients"><Users className="w-3.5 h-3.5 mr-1.5" />Patients</TabsTrigger>
            <TabsTrigger value="prescriptions"><FileText className="w-3.5 h-3.5 mr-1.5" />Prescriptions</TabsTrigger>
            <TabsTrigger value="analytics"><TrendingUp className="w-3.5 h-3.5 mr-1.5" />Analytics</TabsTrigger>
          </TabsList>

          {/* Appointments Tab */}
          <TabsContent value="appointments">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-base">Today's Appointments</CardTitle>
                <Badge variant="secondary">{new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}</Badge>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        {['Patient', 'Age', 'Time', 'Status', 'Actions'].map(h => (
                          <th key={h} className="text-left py-3 px-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {apptList.map((appt) => {
                        const statusConf = apptStatusConfig[appt.status as keyof typeof apptStatusConfig];
                        const StatusIcon = statusConf?.icon || Clock;
                        return (
                          <tr key={appt.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                            <td className="py-3 px-2 font-medium whitespace-nowrap">{appt.patient}</td>
                            <td className="py-3 px-2 text-muted-foreground whitespace-nowrap">{appt.age}</td>
                            <td className="py-3 px-2 whitespace-nowrap">{appt.time}</td>
                            <td className="py-3 px-2 whitespace-nowrap">
                              <Badge className={cn('text-xs', statusConf?.class || '')}>
                                <StatusIcon className="w-3 h-3 mr-1" />
                                {appt.status}
                              </Badge>
                            </td>
                            <td className="py-3 px-2 whitespace-nowrap">
                              <div className="flex gap-1">
                                {appt.status !== 'completed' && (
                                  <Button variant="ghost" size="sm" className="h-7 text-xs text-green-600"
                                    onClick={() => handleAction(appt.id, 'complete')}>
                                    <CheckCircle className="w-3 h-3 mr-1" />Done
                                  </Button>
                                )}
                                {appt.status !== 'completed' && (
                                  <Button variant="ghost" size="sm" className="h-7 text-xs text-destructive"
                                    onClick={() => handleAction(appt.id, 'cancel')}>
                                    <XCircle className="w-3 h-3 mr-1" />Cancel
                                  </Button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Patients Tab */}
          <TabsContent value="patients">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-base">Patient List</CardTitle>
                <Button size="sm" variant="outline" onClick={() => toast.info('Add note feature coming soon')}>
                  <Plus className="w-3.5 h-3.5 mr-1.5" />Add Note
                </Button>
              </CardHeader>
              <CardContent className="space-y-3">
                {patientList.map((patient) => (
                  <div key={patient.id} className="flex items-center gap-3 p-3 rounded-xl border border-border hover:bg-muted/30 transition-colors">
                    <Avatar className="w-10 h-10 shrink-0">
                      <AvatarImage src={patient.avatar} alt={patient.name} />
                      <AvatarFallback>{patient.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{patient.name}</p>
                      <p className="text-xs text-muted-foreground">{patient.condition} · Age {patient.age}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs text-muted-foreground">Last visit</p>
                      <p className="text-xs font-medium">{patient.lastVisit}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={() => toast.info('View patient details')}>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Prescriptions Tab */}
          <TabsContent value="prescriptions">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-base">Prescriptions</CardTitle>
                <Button size="sm" onClick={() => toast.info('New prescription feature coming soon')}>
                  <Plus className="w-3.5 h-3.5 mr-1.5" />New Prescription
                </Button>
              </CardHeader>
              <CardContent className="space-y-3">
                {prescriptions.map(rx => (
                  <div key={rx.id} className="flex items-center gap-3 p-3 rounded-xl border border-border">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Stethoscope className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{rx.patient}</p>
                      <p className="text-xs text-muted-foreground">{rx.medicine} · {rx.duration}</p>
                    </div>
                    <Badge variant={rx.status === 'active' ? 'default' : 'secondary'} className="shrink-0 text-xs">
                      {rx.status}
                    </Badge>
                    <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" onClick={() => toast.info('Edit prescription')}>
                      <Edit className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">This Week</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { day: 'Monday', count: 8, max: 12 },
                    { day: 'Tuesday', count: 12, max: 12 },
                    { day: 'Wednesday', count: 10, max: 12 },
                    { day: 'Thursday', count: 6, max: 12 },
                    { day: 'Friday', count: 9, max: 12 },
                  ].map(d => (
                    <div key={d.day} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>{d.day}</span>
                        <span className="font-medium">{d.count} patients</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all"
                          style={{ width: `${(d.count / d.max) * 100}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Patient Satisfaction</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-4">
                    <div className="text-5xl font-bold text-primary mb-1">4.9</div>
                    <div className="flex justify-center gap-1 mb-2">
                      {[1, 2, 3, 4, 5].map(i => (
                        <Star key={i} className="w-5 h-5 fill-warning text-warning" />
                      ))}
                    </div>
                    <p className="text-sm text-muted-foreground">Based on 284 reviews</p>
                  </div>
                  <div className="space-y-2 mt-4">
                    {[['5 stars', 78], ['4 stars', 16], ['3 stars', 5], ['2 stars', 1]].map(([label, pct]) => (
                      <div key={label as string} className="flex items-center gap-2 text-xs">
                        <span className="w-12 text-muted-foreground">{label}</span>
                        <div className="flex-1 bg-muted rounded-full h-1.5">
                          <div className="bg-warning h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="w-8 text-right font-medium">{pct}%</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default DoctorDashboard;
