import React, { useState } from 'react';
import { Bell, Globe, Moon, Sun, Shield, User, Lock, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AppLayout from '@/components/layouts/AppLayout';
import { useTheme } from '@/contexts/ThemeContext';
import { toast } from 'sonner';

const SettingsPage: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const [notifSettings, setNotifSettings] = useState({
    appointment: true, medicine: true, report: true, ai: false, announcements: true,
  });
  const [privacySettings, setPrivacySettings] = useState({
    shareDataWithDoctors: true,
    analyticsTracking: false,
    twoFactor: false,
    publicProfile: false,
  });
  const [lang, setLang] = useState('en');

  const toggleNotif = (key: keyof typeof notifSettings) => {
    setNotifSettings(p => ({ ...p, [key]: !p[key] }));
    toast.success('Notification preference updated');
  };

  const togglePrivacy = (key: keyof typeof privacySettings) => {
    setPrivacySettings(p => ({ ...p, [key]: !p[key] }));
    toast.success('Privacy setting updated');
  };

  return (
    <AppLayout title="Settings">
      <div className="max-w-2xl space-y-6">
        <Tabs defaultValue="notifications" className="space-y-4">
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="notifications"><Bell className="w-3.5 h-3.5 mr-1.5" />Notifications</TabsTrigger>
            <TabsTrigger value="appearance"><Sun className="w-3.5 h-3.5 mr-1.5" />Appearance</TabsTrigger>
            <TabsTrigger value="privacy"><Shield className="w-3.5 h-3.5 mr-1.5" />Privacy</TabsTrigger>
            <TabsTrigger value="account"><User className="w-3.5 h-3.5 mr-1.5" />Account</TabsTrigger>
          </TabsList>

          {/* Notifications */}
          <TabsContent value="notifications">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Notification Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                {[
                  { key: 'appointment' as const, label: 'Appointment Reminders', desc: 'Get reminders before upcoming appointments' },
                  { key: 'medicine' as const, label: 'Medicine Reminders', desc: 'Receive alerts at your medication times' },
                  { key: 'report' as const, label: 'Report Updates', desc: 'Notify when new reports are available' },
                  { key: 'ai' as const, label: 'AI Health Alerts', desc: 'Receive AI-generated health insights' },
                  { key: 'announcements' as const, label: 'Hospital Announcements', desc: 'News and updates from the hospital' },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between gap-4">
                    <div>
                      <Label className="text-sm font-medium cursor-pointer">{item.label}</Label>
                      <p className="text-xs text-muted-foreground">{item.desc}</p>
                    </div>
                    <Switch
                      checked={notifSettings[item.key]}
                      onCheckedChange={() => toggleNotif(item.key)}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Appearance */}
          <TabsContent value="appearance">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Appearance & Language</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Theme</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => theme === 'dark' && toggleTheme()}
                      className={`p-4 rounded-xl border-2 text-sm font-medium flex items-center gap-2 transition-all ${theme === 'light' ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/40'}`}
                    >
                      <Sun className="w-4 h-4" />Light Mode
                    </button>
                    <button
                      onClick={() => theme === 'light' && toggleTheme()}
                      className={`p-4 rounded-xl border-2 text-sm font-medium flex items-center gap-2 transition-all ${theme === 'dark' ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/40'}`}
                    >
                      <Moon className="w-4 h-4" />Dark Mode
                    </button>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label className="text-sm font-medium">Language</Label>
                  <Select value={lang} onValueChange={v => { setLang(v); toast.success('Language updated'); }}>
                    <SelectTrigger className="w-full">
                      <Globe className="w-4 h-4 mr-2 text-muted-foreground" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="ar">Arabic</SelectItem>
                      <SelectItem value="zh">Chinese (Simplified)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Privacy */}
          <TabsContent value="privacy">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Privacy & Security</CardTitle>
              </CardHeader>
              <CardContent className="space-y-5">
                {[
                  { key: 'shareDataWithDoctors' as const, label: 'Share Health Data with Doctors', desc: 'Allow your assigned doctors to view your health records' },
                  { key: 'analyticsTracking' as const, label: 'Analytics & Usage Data', desc: 'Help improve MediGuide AI with anonymous usage data' },
                  { key: 'twoFactor' as const, label: 'Two-Factor Authentication', desc: 'Add extra security to your account' },
                  { key: 'publicProfile' as const, label: 'Public Profile', desc: 'Make your profile visible to other users' },
                ].map((item) => (
                  <div key={item.key} className="flex items-center justify-between gap-4">
                    <div>
                      <Label className="text-sm font-medium">{item.label}</Label>
                      <p className="text-xs text-muted-foreground">{item.desc}</p>
                    </div>
                    <Switch
                      checked={privacySettings[item.key]}
                      onCheckedChange={() => togglePrivacy(item.key)}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Account */}
          <TabsContent value="account">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Account Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-muted/50 rounded-xl space-y-2">
                  <p className="text-sm font-medium">Account Status</p>
                  <p className="text-xs text-muted-foreground">Your account is active and in good standing.</p>
                  <div className="flex gap-2 flex-wrap">
                    <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-600">Verified Email</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">Patient Role</span>
                  </div>
                </div>

                <Separator />

                <div className="space-y-3">
                  <p className="text-sm font-medium text-muted-foreground">Danger Zone</p>
                  <Button variant="outline" size="sm" className="w-full border-warning/40 text-warning hover:bg-warning/10" onClick={() => toast.warning('Account deactivation requires admin approval.')}>
                    Deactivate Account
                  </Button>
                  <Button variant="outline" size="sm" className="w-full border-destructive/40 text-destructive hover:bg-destructive/10" onClick={() => toast.error('Account deletion is permanent. Contact support.')}>
                    Delete Account
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default SettingsPage;
