import React, { useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, ChevronRight, Calendar, Clock, User, Stethoscope, FileText, CheckCircle, MapPin, Search, IndianRupee, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Card, CardContent } from '@/components/ui/card';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import { getDoctors, createAppointment, updateProfile } from '@/lib/api';
import type { Doctor, ApptType } from '@/types/types';
import { cn, formatINR } from '@/lib/utils';
import { toast } from 'sonner';
import { LOCATIONS } from '@/data/locations';
import type { Location } from '@/data/locations';

const STEPS = ['Patient Info', 'Location', 'Department', 'Doctor', 'Date & Time', 'Symptoms', 'Confirm'];
const DEPARTMENTS = ['Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics', 'Dermatology', 'Psychiatry', 'General Medicine', 'Gastroenterology'];
const timeSlots = ['9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM', '4:00 PM', '4:30 PM'];




interface FormData {
  name: string; age: string; gender: string; mobile: string;
  locationId: string;
  department: string; doctorId: string;
  date: string; time: string; symptoms: string;
}

// ── LocationPicker: city-grouped search + list ────────────────────────────────
const LocationPicker: React.FC<{ value: string; onChange: (id: string) => void }> = ({ value, onChange }) => {
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return q ? LOCATIONS.filter(l =>
      l.name.toLowerCase().includes(q) ||
      l.city.toLowerCase().includes(q) ||
      l.type.toLowerCase().includes(q)
    ) : LOCATIONS;
  }, [search]);

  // Group by city
  const grouped = useMemo(() => {
    const map = new Map<string, Location[]>();
    filtered.forEach(loc => {
      if (!map.has(loc.city)) map.set(loc.city, []);
      map.get(loc.city)!.push(loc);
    });
    return map;
  }, [filtered]);

  return (
    <div className="space-y-3">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search city or hospital…"
          className="w-full pl-9 pr-3 py-2.5 text-sm rounded-xl border border-border bg-background focus:outline-none focus:ring-1 focus:ring-primary/40" />
      </div>

      {/* City-grouped list */}
      <div className="max-h-80 overflow-y-auto space-y-4 pr-1">
        {grouped.size === 0 && (
          <p className="text-sm text-muted-foreground text-center py-6">No locations found for "{search}"</p>
        )}
        {Array.from(grouped.entries()).map(([city, locs]) => (
          <div key={city}>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2 px-1">{city}</p>
            <div className="space-y-2">
              {locs.map(loc => (
                <button key={loc.id} onClick={() => onChange(loc.id)}
                  className={cn('w-full flex items-start gap-3 p-3 rounded-xl border text-left transition-all',
                    value === loc.id ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/40')}>
                  <div className={cn('w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5',
                    value === loc.id ? 'bg-primary text-primary-foreground' : 'bg-muted')}>
                    <MapPin className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{loc.name}</p>
                    <p className="text-xs text-primary/80 font-medium">{loc.type}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{loc.address}</p>
                  </div>
                  {value === loc.id && <Check className="w-4 h-4 text-primary shrink-0 mt-1" />}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const AppointmentBooking: React.FC = () => {
  const { user: authUser, profile } = useAuth();
  const [step, setStep] = useState(0);
  const [confirmed, setConfirmed] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loadingDoctors, setLoadingDoctors] = useState(false);
  const [form, setForm] = useState<FormData>({
    name: profile?.name || '', age: '', gender: '', mobile: profile?.phone || '',
    locationId: '', department: '', doctorId: '', date: '', time: '', symptoms: '',
  });

  // Update form name when profile loads
  useEffect(() => {
    if (profile) setForm(p => ({ ...p, name: p.name || profile.name, mobile: p.mobile || profile.phone || '' }));
  }, [profile]);

  // Load doctors when department changes (step 3 — after location + department chosen)
  useEffect(() => {
    if (step === 3 && form.department) {
      setLoadingDoctors(true);
      getDoctors(form.department).then(setDoctors).finally(() => setLoadingDoctors(false));
    }
  }, [step, form.department]);

  const selectedDoctor = doctors.find(d => d.id === form.doctorId);
  const selectedLocation = LOCATIONS.find(l => l.id === form.locationId);

  const canProceed = () => {
    if (step === 0) return !!(form.name && form.age && form.gender && form.mobile);
    if (step === 1) return !!form.locationId;
    if (step === 2) return !!form.department;
    if (step === 3) return !!form.doctorId;
    if (step === 4) return !!(form.date && form.time);
    return true;
  };

  const handleSubmit = async () => {
    if (!authUser?.id) { toast.error('Please sign in to book an appointment.'); return; }
    setSubmitting(true);

    // Save patient details back to their profile (name, phone, gender, address)
    const profileUpdates: Record<string, string> = {};
    if (form.name && !profile?.name) profileUpdates.name = form.name;
    if (form.mobile && !profile?.phone) profileUpdates.phone = form.mobile;
    if (form.gender && !(profile as any)?.gender) profileUpdates.gender = form.gender;
    if (Object.keys(profileUpdates).length > 0) {
      await updateProfile(authUser.id, profileUpdates as any);
    }

    const result = await createAppointment({
      doctor_id: form.doctorId || undefined,
      doctor_name: selectedDoctor?.name || 'TBD',
      department: form.department,
      date: form.date,
      time: form.time,
      symptoms: form.symptoms || undefined,
      type: 'Consultation' as ApptType,
      notes: selectedLocation ? `Location: ${selectedLocation.name}, ${selectedLocation.city}` : undefined,
    });
    setSubmitting(false);
    if (!result) { toast.error('Failed to book appointment. Please try again.'); return; }
    toast.success('Appointment booked successfully!');
    setConfirmed(true);
  };

  if (confirmed) {
    return (
      <AppLayout title="Appointment Booking">
        <div className="max-w-md mx-auto mt-8">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center">
            <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-green-500" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Appointment Confirmed!</h2>
            <p className="text-muted-foreground mb-8">Your appointment has been successfully booked. You&apos;ll receive a confirmation shortly.</p>
            <Card className="text-left mb-6">
              <CardContent className="p-6 space-y-4">
                {selectedDoctor && (
                  <div className="flex items-center gap-3">
                    <img src={selectedDoctor.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedDoctor.name)}&background=2563EB&color=fff`}
                      alt={selectedDoctor.name} className="w-12 h-12 rounded-full object-cover" />
                    <div>
                      <p className="font-semibold">{selectedDoctor.name}</p>
                      <p className="text-sm text-muted-foreground">{selectedDoctor.specialization}</p>
                    </div>
                  </div>
                )}
                {[['Patient', form.name], ['Location', selectedLocation ? `${selectedLocation.name}, ${selectedLocation.city}` : '—'], ['Date', form.date], ['Time', form.time], ['Department', form.department]].map(([label, val]) => (
                  <div key={label} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{label}</span>
                    <span className="font-medium">{val}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Button onClick={() => { setConfirmed(false); setStep(0); setForm(p => ({ ...p, locationId: '', department: '', doctorId: '', date: '', time: '', symptoms: '' })); }} className="w-full">
              Book Another Appointment
            </Button>
          </motion.div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Book Appointment">
      <div className="max-w-2xl mx-auto">
        {/* Step Progress */}
        <div className="flex items-center mb-8 overflow-x-auto pb-2">
          {STEPS.map((s, i) => (
            <React.Fragment key={s}>
              <div className="flex flex-col items-center shrink-0">
                <div className={cn('w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-colors',
                  i < step ? 'bg-primary text-primary-foreground' : i === step ? 'bg-primary text-primary-foreground ring-4 ring-primary/20' : 'bg-muted text-muted-foreground')}>
                  {i < step ? <Check className="w-4 h-4" /> : i + 1}
                </div>
                <span className={cn('text-xs mt-1 whitespace-nowrap', i === step ? 'text-primary font-medium' : 'text-muted-foreground')}>{s}</span>
              </div>
              {i < STEPS.length - 1 && <div className={cn('flex-1 h-0.5 mx-2 mt-[-12px]', i < step ? 'bg-primary' : 'bg-muted')} />}
            </React.Fragment>
          ))}
        </div>

        <Card>
          <CardContent className="p-6">
            <AnimatePresence mode="wait">
              <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.25 }}>
                {/* Step 0 — Patient Info */}
                {step === 0 && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 mb-4"><User className="w-5 h-5 text-primary" /><h3 className="font-semibold">Patient Information</h3></div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2 space-y-1.5">
                        <Label>Full Name</Label>
                        <Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
                      </div>
                      <div className="space-y-1.5">
                        <Label>Age</Label>
                        <Input type="number" value={form.age} onChange={e => setForm(p => ({ ...p, age: e.target.value }))} />
                      </div>
                      <div className="space-y-1.5">
                        <Label>Mobile Number</Label>
                        <Input value={form.mobile} onChange={e => setForm(p => ({ ...p, mobile: e.target.value }))} />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Gender</Label>
                      <RadioGroup value={form.gender} onValueChange={v => setForm(p => ({ ...p, gender: v }))} className="flex gap-4">
                        {['male', 'female', 'other'].map(g => (
                          <div key={g} className="flex items-center gap-2">
                            <RadioGroupItem value={g} id={g} />
                            <Label htmlFor={g} className="font-normal capitalize cursor-pointer">{g}</Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>
                  </div>
                )}

                {/* Step 1 — Location */}
                {step === 1 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4"><MapPin className="w-5 h-5 text-primary" /><h3 className="font-semibold">Select Location</h3></div>
                    <LocationPicker value={form.locationId} onChange={id => setForm(p => ({ ...p, locationId: id }))} />
                  </div>
                )}

                {/* Step 2 — Department */}
                {step === 2 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4"><Stethoscope className="w-5 h-5 text-primary" /><h3 className="font-semibold">Select Department</h3></div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {DEPARTMENTS.map(dept => (
                        <button key={dept} onClick={() => setForm(p => ({ ...p, department: dept, doctorId: '' }))}
                          className={cn('p-3 rounded-xl border text-sm font-medium text-left transition-all',
                            form.department === dept ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/40')}>
                          {dept}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 3 — Doctor */}
                {step === 3 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4"><Stethoscope className="w-5 h-5 text-primary" /><h3 className="font-semibold">Select Doctor</h3></div>
                    {/* Pay-at-hospital notice */}
                    <div className="flex items-start gap-2 mb-3 px-3 py-2.5 rounded-xl border border-border bg-muted/40">
                      <Building2 className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
                      <p className="text-xs text-muted-foreground">
                        <span className="font-medium text-foreground">OP consultation fee is paid at the hospital.</span>
                        {' '}No payment is collected on this website.
                      </p>
                    </div>
                    <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                      {loadingDoctors ? (
                        <p className="text-sm text-muted-foreground text-center py-4">Loading doctors...</p>
                      ) : doctors.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-4">No doctors available for this department.</p>
                      ) : doctors.map(doc => (
                        <button key={doc.id} onClick={() => setForm(p => ({ ...p, doctorId: doc.id }))}
                          className={cn('w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all',
                            form.doctorId === doc.id ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/40')}>
                          <img src={doc.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(doc.name)}&background=2563EB&color=fff`}
                            alt={doc.name} className="w-10 h-10 rounded-full object-cover shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold truncate">{doc.name}</p>
                            <p className="text-xs text-muted-foreground truncate">{doc.specialization}</p>
                            <div className="flex items-center gap-1 mt-0.5">
                              <IndianRupee className="w-3 h-3 text-primary" />
                              <span className="text-xs font-medium text-primary">{formatINR(doc.fee)}</span>
                              <span className="text-[10px] text-muted-foreground">OP fee · pay at hospital</span>
                            </div>
                          </div>
                          <span className={cn('text-xs px-2 py-0.5 rounded-full shrink-0',
                            doc.availability === 'available' ? 'bg-green-500/10 text-green-600' : 'bg-muted text-muted-foreground')}>
                            {doc.availability}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Step 4 — Date & Time */}
                {step === 4 && (
                  <div className="space-y-5">
                    <div className="flex items-center gap-2 mb-1"><Calendar className="w-5 h-5 text-primary" /><h3 className="font-semibold">Date & Time</h3></div>
                    <div className="space-y-1.5">
                      <Label>Select Date</Label>
                      <Input type="date" value={form.date} min={new Date().toISOString().split('T')[0]}
                        onChange={e => setForm(p => ({ ...p, date: e.target.value }))} />
                    </div>
                    <div className="space-y-2">
                      <Label>Available Time Slots</Label>
                      <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                        {timeSlots.map(slot => (
                          <button key={slot} onClick={() => setForm(p => ({ ...p, time: slot }))}
                            className={cn('py-2 px-3 rounded-lg border text-xs font-medium transition-all',
                              form.time === slot ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/40')}>
                            {slot}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Step 5 — Symptoms */}
                {step === 5 && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2 mb-1"><FileText className="w-5 h-5 text-primary" /><h3 className="font-semibold">Describe Symptoms</h3></div>
                    <div className="space-y-1.5">
                      <Label>Symptoms / Reason for Visit</Label>
                      <Textarea placeholder="Describe your symptoms, concerns, or reason for this appointment..." rows={6}
                        value={form.symptoms} onChange={e => setForm(p => ({ ...p, symptoms: e.target.value }))} />
                    </div>
                  </div>
                )}

                {/* Step 6 — Confirm */}
                {step === 6 && (
                  <div>
                    <div className="flex items-center gap-2 mb-4"><Clock className="w-5 h-5 text-primary" /><h3 className="font-semibold">Review & Confirm</h3></div>
                    {selectedDoctor && (
                      <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-xl mb-4">
                        <img src={selectedDoctor.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedDoctor.name)}&background=2563EB&color=fff`}
                          alt={selectedDoctor.name} className="w-12 h-12 rounded-full object-cover" />
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold">{selectedDoctor.name}</p>
                          <p className="text-sm text-muted-foreground">{selectedDoctor.specialization}</p>
                        </div>
                      </div>
                    )}
                    <div className="space-y-3">
                      {[['Patient Name', form.name], ['Age', form.age], ['Gender', form.gender], ['Mobile', form.mobile],
                        ['Location', selectedLocation ? `${selectedLocation.name}, ${selectedLocation.city}` : '—'],
                        ['Department', form.department], ['Date', form.date], ['Time', form.time], ['Symptoms', form.symptoms || 'Not specified']
                      ].map(([label, val]) => (
                        <div key={label} className="flex justify-between text-sm py-2 border-b border-border last:border-0">
                          <span className="text-muted-foreground">{label}</span>
                          <span className="font-medium max-w-48 text-right">{val}</span>
                        </div>
                      ))}
                      {selectedDoctor && (
                        <div className="flex justify-between text-sm py-2 border-b border-border">
                          <span className="text-muted-foreground">OP Consultation Fee</span>
                          <span className="font-semibold text-primary">{formatINR(selectedDoctor.fee)}</span>
                        </div>
                      )}
                    </div>
                    {/* Pay-at-hospital notice on confirm */}
                    <div className="flex items-start gap-2 mt-4 px-3 py-3 rounded-xl border border-border bg-muted/40">
                      <Building2 className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        <span className="font-medium text-foreground">Payment is collected only at the hospital.</span>
                        {' '}Please pay the OP fee of{' '}
                        <span className="font-semibold text-foreground">{selectedDoctor ? formatINR(selectedDoctor.fee) : '—'}</span>
                        {' '}at the hospital billing counter on the day of your visit.
                      </p>
                    </div>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>

            <div className="flex justify-between mt-8 pt-4 border-t border-border">
              <Button variant="outline" onClick={() => setStep(s => Math.max(0, s - 1))} disabled={step === 0}>Back</Button>
              {step < STEPS.length - 1 ? (
                <Button onClick={() => setStep(s => s + 1)} disabled={!canProceed()}>Continue <ChevronRight className="w-4 h-4 ml-1" /></Button>
              ) : (
                <Button onClick={handleSubmit} disabled={submitting}>
                  {submitting ? 'Booking...' : <><Check className="w-4 h-4 mr-1" />Confirm Booking</>}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default AppointmentBooking;
