import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText, Download, Eye, Bot, Upload, Filter,
  Calendar, User, CheckCircle, AlertTriangle, XCircle,
  Search, Plus, ClipboardList, Activity, TriangleAlert,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import { getMedicalReports, createMedicalReport } from '@/lib/api';
import type { MedicalReport, ReportStatus } from '@/types/types';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const statusConfig: Record<ReportStatus, { icon: React.ElementType; class: string; label: string }> = {
  normal:   { icon: CheckCircle,   class: 'bg-green-500/10 text-green-600 border-green-200',       label: 'Normal'       },
  review:   { icon: AlertTriangle, class: 'bg-warning/10 text-warning border-warning/20',          label: 'Review Needed'},
  abnormal: { icon: XCircle,       class: 'bg-destructive/10 text-destructive border-destructive/20', label: 'Abnormal' },
};

const typeColors: Record<string, string> = {
  Laboratory: 'bg-primary/10 text-primary',
  Radiology:  'bg-purple-500/10 text-purple-600',
  Cardiology: 'bg-red-500/10 text-red-600',
  Neurology:  'bg-orange-500/10 text-orange-600',
  General:    'bg-muted text-muted-foreground',
};

const REPORT_TYPES = ['Laboratory', 'Radiology', 'Cardiology', 'Neurology', 'General', 'Other'];

interface UploadForm {
  title: string;
  report_type: string;
  date: string;
  doctor_name: string;
  status: ReportStatus;
  summary: string;
}

const defaultForm: UploadForm = {
  title: '',
  report_type: 'Laboratory',
  date: new Date().toISOString().split('T')[0],
  doctor_name: '',
  status: 'normal',
  summary: '',
};

const MedicalReportsPage: React.FC = () => {
  const { user: authUser } = useAuth();
  const [filter, setFilter]           = useState('all');
  const [search, setSearch]           = useState('');
  const [reports, setReports]         = useState<MedicalReport[]>([]);
  const [loading, setLoading]         = useState(true);
  const [selectedReport, setSelectedReport] = useState<MedicalReport | null>(null);
  const [uploadOpen, setUploadOpen]   = useState(false);
  const [viewOpen, setViewOpen]       = useState(false);
  const [uploading, setUploading]     = useState(false);
  const [form, setForm]               = useState<UploadForm>(defaultForm);
  const navigate = useNavigate();

  useEffect(() => {
    if (!authUser?.id) return;
    getMedicalReports(authUser.id)
      .then(setReports)
      .finally(() => setLoading(false));
  }, [authUser?.id]);

  const filtered = reports.filter(r => {
    const matchFilter = filter === 'all' || r.status === filter;
    const matchSearch = !search
      || r.title.toLowerCase().includes(search.toLowerCase())
      || r.doctor_name.toLowerCase().includes(search.toLowerCase())
      || r.report_type.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authUser?.id) return;
    setUploading(true);
    const result = await createMedicalReport({ ...form, patient_id: authUser.id } as Omit<MedicalReport, 'id' | 'created_at'>);
    setUploading(false);
    if (!result) { toast.error('Failed to save report. Please try again.'); return; }
    setReports(prev => [result, ...prev]);
    setForm(defaultForm);
    setUploadOpen(false);
    toast.success('Report added successfully!');
  };

  const handleExplainAI = (report: MedicalReport) => {
    navigate('/chat');
    toast.success(`Opening AI explanation for: ${report.title}`);
  };

  const stats = [
    { label: 'Total Reports', value: reports.length,                                          icon: ClipboardList, color: 'text-primary',     bg: 'bg-primary/8'     },
    { label: 'Normal',        value: reports.filter(r => r.status === 'normal').length,        icon: Activity,      color: 'text-green-600',   bg: 'bg-green-500/8'   },
    { label: 'Need Review',   value: reports.filter(r => r.status !== 'normal').length,        icon: TriangleAlert, color: 'text-warning',     bg: 'bg-warning/8'     },
  ];

  return (
    <AppLayout title="Medical Reports">
      <div className="space-y-6 max-w-5xl">

        {/* Toolbar */}
        <div className="flex flex-col md:flex-row gap-3 justify-between">
          <div className="flex gap-2 flex-1">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                placeholder="Search reports…"
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-44">
                <Filter className="w-4 h-4 mr-2 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Reports</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="review">Review Needed</SelectItem>
                <SelectItem value="abnormal">Abnormal</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Upload Dialog */}
          <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Upload className="w-4 h-4 mr-1.5" /> Upload Report
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Plus className="w-4 h-4" /> Add Medical Report
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleUpload} className="space-y-4 py-2">
                <div className="space-y-1.5">
                  <Label htmlFor="title">Report Title</Label>
                  <Input id="title" placeholder="e.g. Complete Blood Count"
                    value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} required />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Report Type</Label>
                    <Select value={form.report_type} onValueChange={v => setForm(p => ({ ...p, report_type: v }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {REPORT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Status</Label>
                    <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v as ReportStatus }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="review">Review Needed</SelectItem>
                        <SelectItem value="abnormal">Abnormal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="doctor">Doctor Name</Label>
                    <Input id="doctor" placeholder="Dr. Name"
                      value={form.doctor_name} onChange={e => setForm(p => ({ ...p, doctor_name: e.target.value }))} required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="date">Date</Label>
                    <Input id="date" type="date"
                      value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} required />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="summary">Summary / Notes <span className="text-muted-foreground font-normal">(optional)</span></Label>
                  <Textarea id="summary" placeholder="Key findings or notes…" rows={3}
                    value={form.summary} onChange={e => setForm(p => ({ ...p, summary: e.target.value }))} />
                </div>
                <div className="flex gap-2 pt-1">
                  <Button type="button" variant="outline" className="flex-1" onClick={() => setUploadOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" className="flex-1" disabled={uploading}>
                    {uploading ? 'Saving…' : 'Save Report'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          {stats.map(stat => {
            const Icon = stat.icon;
            return (
              <Card key={stat.label}>
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center shrink-0', stat.bg)}>
                    <Icon className={cn('w-4 h-4', stat.color)} />
                  </div>
                  <div>
                    <p className={cn('text-xl font-bold leading-none', stat.color)}>{stat.value}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Report list */}
        {loading ? (
          <div className="grid md:grid-cols-2 gap-4">
            {[1,2,3,4].map(i => (
              <Card key={i}><CardContent className="p-5 space-y-3">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-9 w-full" />
              </CardContent></Card>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mx-auto">
              <FileText className="w-6 h-6 text-muted-foreground" />
            </div>
            <p className="font-medium">No reports found</p>
            <p className="text-sm text-muted-foreground max-w-xs mx-auto">
              {search || filter !== 'all'
                ? 'Try adjusting your search or filter.'
                : 'Add your first report using the Upload Report button above.'}
            </p>
            {!search && filter === 'all' && (
              <Button size="sm" variant="outline" onClick={() => setUploadOpen(true)} className="mt-2">
                <Plus className="w-4 h-4 mr-1.5" /> Add Report
              </Button>
            )}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            <AnimatePresence>
              {filtered.map((report, i) => {
                const status = statusConfig[report.status] || statusConfig.normal;
                const StatusIcon = status.icon;
                return (
                  <motion.div key={report.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.97 }}
                    transition={{ delay: i * 0.05 }}>
                    <Card className="hover:shadow-hover transition-shadow h-full">
                      <CardContent className="p-5 flex flex-col h-full">
                        <div className="flex items-start gap-3 mb-4">
                          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                            <FileText className="w-5 h-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-sm truncate">{report.title}</h3>
                            <Badge className={cn('text-[10px] mt-1', typeColors[report.report_type] || 'bg-muted text-muted-foreground')}>
                              {report.report_type}
                            </Badge>
                          </div>
                          <Badge className={cn('text-xs shrink-0', status.class)}>
                            <StatusIcon className="w-3 h-3 mr-1" />{status.label}
                          </Badge>
                        </div>
                        <div className="space-y-1.5 mb-4 flex-1">
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Calendar className="w-3.5 h-3.5" />{report.date}
                          </div>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <User className="w-3.5 h-3.5" />{report.doctor_name}
                          </div>
                          {report.summary && (
                            <p className="text-xs text-muted-foreground leading-relaxed mt-2 line-clamp-2">{report.summary}</p>
                          )}
                        </div>
                        <div className="flex gap-2 pt-3 border-t border-border">
                          {/* View Dialog */}
                          <Dialog open={viewOpen && selectedReport?.id === report.id}
                            onOpenChange={open => { setViewOpen(open); if (!open) setSelectedReport(null); }}>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="flex-1"
                                onClick={() => { setSelectedReport(report); setViewOpen(true); }}>
                                <Eye className="w-3.5 h-3.5 mr-1" />View
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
                              <DialogHeader>
                                <DialogTitle>{selectedReport?.title}</DialogTitle>
                              </DialogHeader>
                              {selectedReport && (
                                <div className="space-y-4 py-2">
                                  <div className="grid grid-cols-2 gap-3 text-sm">
                                    <div><span className="text-muted-foreground text-xs">Date</span><p className="font-medium mt-0.5">{selectedReport.date}</p></div>
                                    <div><span className="text-muted-foreground text-xs">Doctor</span><p className="font-medium mt-0.5">{selectedReport.doctor_name}</p></div>
                                    <div><span className="text-muted-foreground text-xs">Type</span><p className="font-medium mt-0.5">{selectedReport.report_type}</p></div>
                                    <div><span className="text-muted-foreground text-xs">Status</span>
                                      <Badge className={cn('text-xs mt-1 inline-flex', statusConfig[selectedReport.status]?.class)}>
                                        {statusConfig[selectedReport.status]?.label}
                                      </Badge>
                                    </div>
                                  </div>
                                  {selectedReport.summary && (
                                    <div className="p-4 bg-muted rounded-lg">
                                      <p className="text-sm leading-relaxed">{selectedReport.summary}</p>
                                    </div>
                                  )}
                                  <Button className="w-full" onClick={() => handleExplainAI(selectedReport)}>
                                    <Bot className="w-4 h-4 mr-2" />Explain with AI
                                  </Button>
                                </div>
                              )}
                            </DialogContent>
                          </Dialog>

                          <Button variant="outline" size="sm" className="flex-1"
                            onClick={() => toast.success('Report downloaded!')}>
                            <Download className="w-3.5 h-3.5 mr-1" />Download
                          </Button>
                          <Button size="sm" variant="secondary" onClick={() => handleExplainAI(report)}>
                            <Bot className="w-3.5 h-3.5 mr-1" />AI
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default MedicalReportsPage;
