import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import {
  Eye, EyeOff, Activity, ArrowLeft, AlertCircle,
  User, Stethoscope, ChevronRight, Droplet,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import type { UserRole } from '@/types/types';

type AuthMode = 'pick' | 'login' | 'signup' | 'forgot';
type PortalRole = 'patient' | 'doctor' | 'hospital_member';

const dashMap: Record<UserRole, string> = {
  patient: '/dashboard',
  doctor: '/doctor-dashboard',
  staff: '/staff-dashboard',
  hospital_member: '/hospital-member-dashboard',
  admin: '/admin-dashboard',
};

const portalMeta: Record<PortalRole, {
  icon: React.ElementType;
  title: string;
  description: string;
  accentClass: string;
  loginTitle: string;
  loginSub: string;
}> = {
  patient: {
    icon: User,
    title: 'Patient',
    description: 'Book appointments, chat with AI, manage your health records',
    accentClass: 'border-primary/20 hover:border-primary/40 hover:bg-primary/5',
    loginTitle: 'Patient Login',
    loginSub: 'Access your health dashboard and appointments',
  },
  doctor: {
    icon: Stethoscope,
    title: 'Doctor',
    description: 'View your patients, manage OP timings and appointment schedules',
    accentClass: 'border-border hover:border-muted-foreground/30 hover:bg-muted/40',
    loginTitle: 'Doctor Login',
    loginSub: 'Access your Doctor Portal — appointments & patient records',
  },
  hospital_member: {
    icon: Droplet,
    title: 'Hospital Member',
    description: 'Manage blood bank inventory, track and update patient and guardian blood groups',
    accentClass: 'border-destructive/20 hover:border-destructive/40 hover:bg-destructive/5',
    loginTitle: 'Hospital Member Login',
    loginSub: 'Access Blood Bank Management Portal',
  },
};

const AuthPage: React.FC = () => {
  const [mode, setMode] = useState<AuthMode>('pick');
  const [portal, setPortal] = useState<PortalRole>('patient');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ email: '', password: '', confirmPassword: '', name: '' });
  const { signIn, signUp, resetPassword, profile } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (profile) navigate(dashMap[profile.role], { replace: true });
  }, [profile, navigate]);

  const handlePortalSelect = (p: PortalRole) => {
    setPortal(p);
    setMode('login');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await signIn(form.email, form.password);
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success('Welcome back!');
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) { toast.error('Passwords do not match.'); return; }
    if (form.password.length < 6) { toast.error('Password must be at least 6 characters.'); return; }
    setLoading(true);
    const { error } = await signUp(form.email, form.password, form.name, portal);
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success('Account created! Please check your email or sign in.');
    setMode('login');
  };

  const handleForgot = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await resetPassword(form.email);
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success('Password reset link sent to your email.');
    setMode('login');
  };

  const meta = portalMeta[portal];
  const PortalIcon = meta.icon;

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left panel */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-primary">
        <img
          src="https://images.unsplash.com/photo-1504813184591-01572f98c85f?w=800&h=900&fit=crop"
          alt="Healthcare"
          className="absolute inset-0 w-full h-full object-cover opacity-20"
        />
        <div className="relative z-10 flex flex-col justify-between p-12 w-full">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Activity className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-white text-lg">MediGuide AI</span>
          </Link>
          <div>
            <h2 className="text-3xl font-bold text-white mb-4 text-balance">
              Your intelligent partner in healthcare
            </h2>
            <p className="text-white/70 text-sm leading-relaxed mb-8">
              Separate, secure portals for patients and doctors — each designed for your unique workflow.
            </p>
            <div className="space-y-3">
              {[
                { icon: User,        label: 'Patient Portal', desc: 'Book appointments, AI chat, medical records' },
                { icon: Stethoscope, label: 'Doctor Portal',  desc: 'Patient list, OP timings, appointment management' },
              ].map(({ icon: Icon, label, desc }) => (
                <div key={label} className="flex items-center gap-3 bg-white/10 rounded-xl px-4 py-3">
                  <div className="w-8 h-8 rounded-lg bg-white/15 flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{label}</p>
                    <p className="text-xs text-white/60">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right — Form */}
      <div className="flex-1 flex items-center justify-center p-6 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={mode}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="w-full max-w-md"
          >
            <Link to="/" className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors">
              <ArrowLeft className="w-4 h-4" /> Back to Home
            </Link>

            {/* ── PICK PORTAL ── */}
            {mode === 'pick' && (
              <div>
                <div className="mb-8">
                  <h1 className="text-2xl font-bold mb-1">Welcome to MediGuide AI</h1>
                  <p className="text-sm text-muted-foreground">Choose your portal to get started</p>
                </div>

                <div className="space-y-3">
                  {(['patient', 'doctor', 'hospital_member'] as PortalRole[]).map(p => {
                    const m = portalMeta[p];
                    const Icon = m.icon;
                    return (
                      <button
                        key={p}
                        onClick={() => handlePortalSelect(p)}
                        className={cn(
                          'w-full flex items-center gap-4 p-5 rounded-2xl border text-left transition-all group',
                          m.accentClass
                        )}
                      >
                        <div className={cn(
                          'w-11 h-11 rounded-xl flex items-center justify-center shrink-0 transition-colors',
                          p === 'patient' ? 'bg-primary/10 text-primary' : (p === 'hospital_member' ? 'bg-destructive/10 text-destructive' : 'bg-muted text-foreground')
                        )}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm">{m.title}</p>
                          <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{m.description}</p>
                        </div>
                        <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:translate-x-0.5 transition-transform shrink-0" />
                      </button>
                    );
                  })}
                </div>

                <div className="mt-8 pt-6 border-t border-border text-center">
                  <p className="text-xs text-muted-foreground">
                    New here?{' '}
                    <button
                      onClick={() => { setPortal('patient'); setMode('signup'); }}
                      className="text-primary hover:underline font-medium"
                    >
                      Create a free account
                    </button>
                  </p>
                </div>
              </div>
            )}

            {/* ── LOGIN ── */}
            {mode === 'login' && (
              <div>
                <button
                  onClick={() => setMode('pick')}
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground mb-6 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> All portals
                </button>

                {/* Portal badge */}
                <div className={cn(
                  'inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium mb-5',
                  portal === 'patient'
                    ? 'border-primary/20 bg-primary/10 text-primary'
                    : 'border-border bg-muted text-foreground'
                )}>
                  <PortalIcon className="w-3 h-3" />
                  {meta.title} Portal
                </div>

                <div className="mb-7">
                  <h1 className="text-2xl font-bold mb-1">{meta.loginTitle}</h1>
                  <p className="text-sm text-muted-foreground">{meta.loginSub}</p>
                </div>

                {portal === 'doctor' && (
                  <div className="flex items-start gap-3 px-4 py-3 rounded-xl border border-border bg-muted/40 mb-5">
                    <Stethoscope className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      This portal is for{' '}
                      <span className="font-medium text-foreground">verified doctors only</span>.
                      After sign-in you will be redirected to your Doctor Dashboard to view OP timings and patient appointments.
                    </p>
                  </div>
                )}

                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="email">{portal === 'hospital_member' ? 'Hospital Email ID' : 'Email address'}</Label>
                    <Input id="email" type="email" placeholder={portal === 'hospital_member' ? "hospital@example.com" : "name@example.com"}
                      value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                      required autoComplete="email" />
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Password</Label>
                      <button type="button" onClick={() => setMode('forgot')} className="text-xs text-primary hover:underline">
                        Forgot password?
                      </button>
                    </div>
                    <div className="relative">
                      <Input id="password" type={showPassword ? 'text' : 'password'} placeholder="Enter your password"
                        value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                        required className="pr-10" autoComplete="current-password" />
                      <button type="button" onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="remember" checked={rememberMe} onCheckedChange={v => setRememberMe(!!v)} />
                    <Label htmlFor="remember" className="text-sm font-normal cursor-pointer">Remember me</Label>
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? 'Signing in…' : `Sign in as ${meta.title}`}
                  </Button>
                </form>

                <p className="text-center text-sm text-muted-foreground mt-6">
                  Don&apos;t have an account?{' '}
                  <button onClick={() => setMode('signup')} className="text-primary hover:underline font-medium">
                    Sign up
                  </button>
                </p>
              </div>
            )}

            {/* ── SIGN UP ── */}
            {mode === 'signup' && (
              <div>
                <button
                  onClick={() => setMode('pick')}
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground mb-6 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> All portals
                </button>

                {/* Portal badge */}
                <div className={cn(
                  'inline-flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium mb-5',
                  portal === 'patient'
                    ? 'border-primary/20 bg-primary/10 text-primary'
                    : portal === 'hospital_member'
                      ? 'border-destructive/20 bg-destructive/10 text-destructive'
                      : 'border-border bg-muted text-foreground'
                )}>
                  <PortalIcon className="w-3 h-3" />
                  {meta.title} Portal
                </div>

                <div className="mb-8">
                  <h1 className="text-2xl font-bold mb-1">Create a {meta.title.toLowerCase()} account</h1>
                  <p className="text-sm text-muted-foreground">Join MediGuide AI today</p>
                </div>
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="name">{portal === 'hospital_member' ? 'Hospital Name' : 'Full Name'}</Label>
                    <Input id="name" placeholder={portal === 'hospital_member' ? 'Enter hospital name' : 'Your full name'}
                      value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="signup-email">{portal === 'hospital_member' ? 'Hospital Email ID' : 'Email'}</Label>
                    <Input id="signup-email" type="email" placeholder={portal === 'hospital_member' ? "hospital@example.com" : "name@example.com"}
                      value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="signup-password">Password</Label>
                    <div className="relative">
                      <Input id="signup-password" type={showPassword ? 'text' : 'password'} placeholder="Min. 6 characters"
                        value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                        required className="pr-10" />
                      <button type="button" onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="confirm-password">Confirm Password</Label>
                    <Input id="confirm-password" type="password" placeholder="Confirm your password"
                      value={form.confirmPassword} onChange={e => setForm(p => ({ ...p, confirmPassword: e.target.value }))} required />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? 'Creating account…' : `Create ${meta.title} Account`}
                  </Button>
                </form>
                <p className="text-center text-sm text-muted-foreground mt-6">
                  Already have an account?{' '}
                  <button onClick={() => { setPortal('patient'); setMode('login'); }} className="text-primary hover:underline font-medium">
                    Sign in
                  </button>
                </p>
              </div>
            )}

            {/* ── FORGOT PASSWORD ── */}
            {mode === 'forgot' && (
              <div>
                <div className="mb-8">
                  <h1 className="text-2xl font-bold mb-1">Reset password</h1>
                  <p className="text-sm text-muted-foreground">We&apos;ll send a reset link to your email</p>
                </div>
                <div className="flex gap-3 p-4 bg-muted rounded-xl mb-6">
                  <AlertCircle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
                  <p className="text-sm text-muted-foreground">
                    Enter the email associated with your account and we&apos;ll send you a link to reset your password.
                  </p>
                </div>
                <form onSubmit={handleForgot} className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="reset-email">Email Address</Label>
                    <Input id="reset-email" type="email" placeholder="name@example.com"
                      value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} required />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? 'Sending…' : 'Send Reset Link'}
                  </Button>
                </form>
                <button onClick={() => setMode('login')}
                  className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mt-6 mx-auto transition-colors">
                  <ArrowLeft className="w-4 h-4" /> Back to sign in
                </button>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default AuthPage;
