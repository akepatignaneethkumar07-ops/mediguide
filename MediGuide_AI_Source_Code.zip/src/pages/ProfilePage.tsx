import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Camera, Edit, X, Phone, Mail, MapPin, Heart, Shield, Eye, EyeOff, User, Plus, Trash2, AlertTriangle, Pencil } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import { updateProfile } from '@/lib/api';
import { supabase } from '@/db/supabase';
import { toast } from 'sonner';

interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
}

const BLANK_EC = { name: '', phone: '', relationship: '' };

const ProfilePage: React.FC = () => {
  const { user: authUser, profile, refreshProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [form, setForm] = useState({
    name: profile?.name || '',
    email: profile?.email || authUser?.email || '',
    phone: profile?.phone || '',
    gender: (profile as any)?.gender || '',
    address: profile?.address || '',
    date_of_birth: profile?.date_of_birth || '',
    blood_group: profile?.blood_group || '',
    bio: profile?.bio || '',
  });
  const [pwForm, setPwForm] = useState({ newPw: '', confirm: '' });

  // Emergency contacts state
  const [ecList, setEcList] = useState<EmergencyContact[]>([]);
  const [ecLoading, setEcLoading] = useState(false);
  const [ecForm, setEcForm] = useState(BLANK_EC);
  const [ecEditing, setEcEditing] = useState<string | null>(null); // id being edited
  const [ecAdding, setEcAdding] = useState(false);
  const [ecSaving, setEcSaving] = useState(false);

  // Fetch emergency contacts
  const fetchEC = async () => {
    if (!authUser?.id) return;
    setEcLoading(true);
    const { data } = await supabase
      .from('emergency_contacts')
      .select('id, name, phone, relationship')
      .eq('user_id', authUser.id)
      .order('created_at');
    setEcList(data || []);
    setEcLoading(false);
  };

  // Sync form when profile loads
  useEffect(() => {
    if (profile) {
      setForm({
        name: profile.name || '',
        email: profile.email || authUser?.email || '',
        phone: profile.phone || '',
        gender: (profile as any)?.gender || '',
        address: profile.address || '',
        date_of_birth: profile.date_of_birth || '',
        blood_group: profile.blood_group || '',
        bio: profile.bio || '',
      });
    }
  }, [profile, authUser]);

  useEffect(() => { fetchEC(); }, [authUser?.id]);

  const handleSave = async () => {
    if (!authUser?.id) return;
    setSaving(true);
    const ok = await updateProfile(authUser.id, {
      name: form.name,
      phone: form.phone,
      address: form.address,
      date_of_birth: form.date_of_birth || undefined,
      blood_group: form.blood_group || undefined,
      bio: form.bio || undefined,
      gender: form.gender || undefined,
    } as any);
    setSaving(false);
    if (!ok) { toast.error('Failed to update profile.'); return; }
    await refreshProfile();
    setEditing(false);
    toast.success('Profile updated successfully!');
  };

  const handlePasswordChange = async () => {
    if (pwForm.newPw !== pwForm.confirm) { toast.error('Passwords do not match.'); return; }
    if (pwForm.newPw.length < 6) { toast.error('Password must be at least 6 characters.'); return; }
    const { error } = await supabase.auth.updateUser({ password: pwForm.newPw });
    if (error) { toast.error(error.message); return; }
    toast.success('Password changed successfully!');
    setPwForm({ newPw: '', confirm: '' });
  };

  const startAddEC = () => { setEcForm(BLANK_EC); setEcEditing(null); setEcAdding(true); };
  const startEditEC = (c: EmergencyContact) => { setEcForm({ name: c.name, phone: c.phone, relationship: c.relationship }); setEcEditing(c.id); setEcAdding(true); };
  const cancelEC = () => { setEcAdding(false); setEcEditing(null); setEcForm(BLANK_EC); };

  const saveEC = async () => {
    if (!authUser?.id) return;
    if (!ecForm.name.trim() || !ecForm.phone.trim()) { toast.error('Name and phone are required.'); return; }
    setEcSaving(true);
    if (ecEditing) {
      const { error } = await supabase.from('emergency_contacts')
        .update({ name: ecForm.name.trim(), phone: ecForm.phone.trim(), relationship: ecForm.relationship.trim() })
        .eq('id', ecEditing);
      if (error) { toast.error('Failed to update contact.'); setEcSaving(false); return; }
      toast.success('Contact updated.');
    } else {
      const { error } = await supabase.from('emergency_contacts')
        .insert({ user_id: authUser.id, name: ecForm.name.trim(), phone: ecForm.phone.trim(), relationship: ecForm.relationship.trim() });
      if (error) { toast.error('Failed to add contact.'); setEcSaving(false); return; }
      toast.success('Contact added.');
    }
    setEcSaving(false);
    cancelEC();
    fetchEC();
  };

  const deleteEC = async (id: string) => {
    const { error } = await supabase.from('emergency_contacts').delete().eq('id', id);
    if (error) { toast.error('Failed to delete contact.'); return; }
    toast.success('Contact removed.');
    fetchEC();
  };

  const medHistory = profile?.medical_history || [];

  return (
    <AppLayout title="Profile">
      <div className="max-w-4xl space-y-6">
        {/* Profile header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
              <div className="relative">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={profile?.avatar_url || ''} alt={form.name} />
                  <AvatarFallback className="text-xl">{form.name?.[0] || '?'}</AvatarFallback>
                </Avatar>
                <button className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-md">
                  <Camera className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-xl font-bold">{form.name || 'Your Profile'}</h2>
                <p className="text-sm text-muted-foreground">{form.email}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  <Badge variant="secondary" className="text-xs capitalize">{profile?.role || 'Patient'}</Badge>
                  {form.blood_group && <Badge className="bg-green-500/10 text-green-600 text-xs">Blood: {form.blood_group}</Badge>}
                </div>
              </div>
              <Button variant={editing ? 'outline' : 'default'} size="sm" onClick={() => editing ? setEditing(false) : setEditing(true)}>
                {editing ? <><X className="w-3.5 h-3.5 mr-1.5" />Cancel</> : <><Edit className="w-3.5 h-3.5 mr-1.5" />Edit Profile</>}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="personal" className="space-y-4">
          <TabsList>
            <TabsTrigger value="personal">Personal Info</TabsTrigger>
            <TabsTrigger value="medical">Medical History</TabsTrigger>
            <TabsTrigger value="emergency">Emergency Contacts</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          {/* Personal Info */}
          <TabsContent value="personal">
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Personal Information</CardTitle></CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {[
                    { label: 'Full Name', field: 'name' as const, icon: null },
                    { label: 'Email Address', field: 'email' as const, icon: Mail, disabled: true },
                    { label: 'Phone Number', field: 'phone' as const, icon: Phone },
                    { label: 'Date of Birth', field: 'date_of_birth' as const, type: 'date' },
                    { label: 'Blood Group', field: 'blood_group' as const },
                  ].map(({ label, field, icon: Icon, type, disabled }) => (
                    <div key={field} className="space-y-1.5">
                      <Label>{label}</Label>
                      {editing && !disabled ? (
                        <Input type={type || 'text'} value={form[field] ?? ''} onChange={e => setForm(p => ({ ...p, [field]: e.target.value }))} />
                      ) : (
                        <div className="flex items-center gap-2 text-sm py-2 px-3 bg-muted/50 rounded-lg">
                          {Icon && <Icon className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
                          <span className={!form[field] ? 'text-muted-foreground italic' : ''}>{form[field] || 'Not provided'}</span>
                        </div>
                      )}
                    </div>
                  ))}

                  {/* Gender */}
                  <div className="space-y-1.5">
                    <Label>Gender</Label>
                    {editing ? (
                      <Select value={form.gender} onValueChange={v => setForm(p => ({ ...p, gender: v }))}>
                        <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Male">Male</SelectItem>
                          <SelectItem value="Female">Female</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                          <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <div className="flex items-center gap-2 text-sm py-2 px-3 bg-muted/50 rounded-lg">
                        <User className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                        <span className={!form.gender ? 'text-muted-foreground italic' : ''}>{form.gender || 'Not provided'}</span>
                      </div>
                    )}
                  </div>

                  {/* Address — full width */}
                  <div className="md:col-span-2 space-y-1.5">
                    <Label>Address</Label>
                    {editing ? (
                      <Textarea value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} rows={2} placeholder="House / flat no., street, city, state, PIN" />
                    ) : (
                      <div className="flex items-start gap-2 text-sm py-2 px-3 bg-muted/50 rounded-lg">
                        <MapPin className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" />
                        <span className={!form.address ? 'text-muted-foreground italic' : ''}>{form.address || 'Not provided'}</span>
                      </div>
                    )}
                  </div>

                  {/* Bio — full width */}
                  <div className="md:col-span-2 space-y-1.5">
                    <Label>Bio</Label>
                    {editing ? (
                      <Textarea value={form.bio} onChange={e => setForm(p => ({ ...p, bio: e.target.value }))} rows={3} placeholder="Tell us about yourself..." />
                    ) : (
                      <p className="text-sm py-2 px-3 bg-muted/50 rounded-lg text-muted-foreground">{form.bio || 'No bio added yet.'}</p>
                    )}
                  </div>
                </div>
                {editing && (
                  <div className="mt-6 flex gap-3">
                    <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving...' : 'Save Changes'}</Button>
                    <Button variant="outline" onClick={() => setEditing(false)}>Cancel</Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Medical History */}
          <TabsContent value="medical">
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base flex items-center gap-2"><Heart className="w-4 h-4 text-primary" />Medical History</CardTitle></CardHeader>
              <CardContent>
                {medHistory.length === 0 ? (
                  <div className="text-center py-8">
                    <Heart className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-40" />
                    <p className="text-sm text-muted-foreground">No medical history recorded</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">Your doctor will update this during visits</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {medHistory.map((item: string, i: number) => (
                      <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}
                        className="flex items-center justify-between p-3 rounded-lg border border-border">
                        <span className="text-sm">{item}</span>
                        <Badge variant="secondary" className="text-xs">Recorded</Badge>
                      </motion.div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Emergency Contacts */}
          <TabsContent value="emergency">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                    Emergency Contacts
                  </CardTitle>
                  {!ecAdding && (
                    <Button size="sm" variant="outline" onClick={startAddEC} className="h-8 gap-1.5">
                      <Plus className="w-3.5 h-3.5" /> Add Contact
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add / Edit form */}
                {ecAdding && (
                  <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
                    className="border border-border rounded-xl p-4 bg-muted/30 space-y-3">
                    <p className="text-sm font-medium">{ecEditing ? 'Edit Contact' : 'New Emergency Contact'}</p>
                    <div className="grid md:grid-cols-3 gap-3">
                      <div className="space-y-1">
                        <Label className="text-xs">Full Name *</Label>
                        <Input value={ecForm.name} onChange={e => setEcForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Priya Sharma" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Phone Number *</Label>
                        <Input value={ecForm.phone} onChange={e => setEcForm(p => ({ ...p, phone: e.target.value }))} placeholder="e.g. +91 98765 43210" />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Relationship</Label>
                        <Input value={ecForm.relationship} onChange={e => setEcForm(p => ({ ...p, relationship: e.target.value }))} placeholder="e.g. Spouse, Parent, Friend" />
                      </div>
                    </div>
                    <div className="flex gap-2 pt-1">
                      <Button size="sm" onClick={saveEC} disabled={ecSaving}>{ecSaving ? 'Saving…' : 'Save Contact'}</Button>
                      <Button size="sm" variant="outline" onClick={cancelEC}>Cancel</Button>
                    </div>
                  </motion.div>
                )}

                {/* Contact list */}
                {ecLoading ? (
                  <div className="py-6 text-center text-sm text-muted-foreground">Loading contacts…</div>
                ) : ecList.length === 0 && !ecAdding ? (
                  <div className="text-center py-10 border border-dashed border-border rounded-xl">
                    <AlertTriangle className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-40" />
                    <p className="text-sm text-muted-foreground">No emergency contacts added yet</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">These appear in the SOS panel for quick calling</p>
                    <Button size="sm" variant="outline" onClick={startAddEC} className="mt-4 gap-1.5">
                      <Plus className="w-3.5 h-3.5" /> Add your first contact
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {ecList.map((c, i) => (
                      <motion.div key={c.id} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }}
                        className="flex items-center justify-between p-3 rounded-xl border border-border bg-card">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-9 h-9 rounded-full bg-red-500/10 flex items-center justify-center shrink-0">
                            <User className="w-4 h-4 text-red-500" />
                          </div>
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{c.name}</p>
                            <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Phone className="w-3 h-3" />{c.phone}
                              </span>
                              {c.relationship && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground">{c.relationship}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0 ml-2">
                          <a href={`tel:${c.phone}`}
                            className="w-8 h-8 rounded-full bg-green-600 hover:bg-green-700 flex items-center justify-center text-white transition-colors"
                            aria-label={`Call ${c.name}`}>
                            <Phone className="w-3.5 h-3.5" />
                          </a>
                          <button onClick={() => startEditEC(c)}
                            className="w-8 h-8 rounded-full bg-muted hover:bg-muted/70 flex items-center justify-center transition-colors"
                            aria-label="Edit">
                            <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                          </button>
                          <button onClick={() => deleteEC(c.id)}
                            className="w-8 h-8 rounded-full bg-muted hover:bg-red-500/10 flex items-center justify-center transition-colors"
                            aria-label="Delete">
                            <Trash2 className="w-3.5 h-3.5 text-muted-foreground hover:text-red-500" />
                          </button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}

                <p className="text-xs text-muted-foreground/60 pt-1">
                  These contacts appear in the SOS emergency panel accessible from any page.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security */}
          <TabsContent value="security">
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base flex items-center gap-2"><Shield className="w-4 h-4 text-primary" />Change Password</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-4 max-w-sm">
                  <div className="space-y-1.5">
                    <Label>New Password</Label>
                    <div className="relative">
                      <Input type={showPw ? 'text' : 'password'} value={pwForm.newPw}
                        onChange={e => setPwForm(p => ({ ...p, newPw: e.target.value }))} placeholder="Min. 6 characters" className="pr-10" />
                      <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                        {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Confirm New Password</Label>
                    <Input type="password" value={pwForm.confirm}
                      onChange={e => setPwForm(p => ({ ...p, confirm: e.target.value }))} placeholder="Confirm new password" />
                  </div>
                  <Button onClick={handlePasswordChange} disabled={!pwForm.newPw || !pwForm.confirm}>Update Password</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default ProfilePage;
