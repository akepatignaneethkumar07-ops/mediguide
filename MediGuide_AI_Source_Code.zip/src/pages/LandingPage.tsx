import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  Calendar, Bot, Mic, Stethoscope, FileText, Bell,
  ChevronDown, ArrowRight, CheckCircle, Activity,
  MapPin, Menu, X, Sun, Moon,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useTheme } from '@/contexts/ThemeContext';
import Footer from '@/components/layouts/Footer';
import { supabase } from '@/db/supabase';
import { LOCATIONS, HOSPITAL_COUNT, CITY_COUNT } from '@/data/locations';
import { features, faqs } from '@/data/sampleData';
import { cn } from '@/lib/utils';

const featureIcons: Record<string, React.ElementType> = {
  Calendar, Bot, Mic, Stethoscope, FileText, Bell,
};

const LandingPage: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [doctorCount, setDoctorCount] = useState<number | null>(null);

  useEffect(() => {
    supabase.from('doctors').select('id', { count: 'exact', head: true })
      .then(({ count }) => { if (count !== null) setDoctorCount(count); });
  }, []);

  const navLinks = ['Features', 'Services', 'Doctors', 'FAQ'];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Activity className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-base">MediGuide AI</span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map(link => (
              <a key={link} href={`#${link.toLowerCase()}`}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                {link}
              </a>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
            <Button variant="ghost" asChild size="sm">
              <Link to="/login">Sign In</Link>
            </Button>
            <Button asChild size="sm">
              <Link to="/signup">Get Started</Link>
            </Button>
          </div>

          <button className="md:hidden p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden border-t border-border bg-background px-6 py-4 space-y-3"
          >
            {navLinks.map(link => (
              <a key={link} href={`#${link.toLowerCase()}`}
                className="block text-sm text-muted-foreground hover:text-foreground py-1.5"
                onClick={() => setMobileMenuOpen(false)}>
                {link}
              </a>
            ))}
            <div className="pt-2 flex gap-3 border-t border-border">
              <Button variant="ghost" asChild size="sm" className="flex-1">
                <Link to="/login">Sign In</Link>
              </Button>
              <Button asChild size="sm" className="flex-1">
                <Link to="/signup">Get Started</Link>
              </Button>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-24">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="mb-6 bg-primary/10 text-primary border-0 font-medium">
              AI-Powered Healthcare
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-foreground leading-tight mb-6">
              Your Intelligent{' '}
              <span className="gradient-text">Hospital Assistant</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed mb-8 max-w-prose">
              MediGuide AI transforms your healthcare experience with smart appointment booking,
              AI medical consultation, instant report explanations, and 24/7 voice assistance.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/appointments">
                  <Calendar className="w-4 h-4 mr-2" />
                  Book Appointment
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/chat">
                  <Bot className="w-4 h-4 mr-2" />
                  Talk to AI
                </Link>
              </Button>
            </div>
            {/* Real stats row — derived from actual data */}
            <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3">
              {[
                { value: String(HOSPITAL_COUNT), label: 'Hospitals', icon: <MapPin className="w-3.5 h-3.5" /> },
                { value: String(CITY_COUNT),     label: 'Cities',    icon: <Activity className="w-3.5 h-3.5" /> },
                { value: doctorCount !== null ? String(doctorCount) : '…', label: 'Specialists', icon: <Stethoscope className="w-3.5 h-3.5" /> },
              ].map(({ value, label, icon }) => (
                <div key={label} className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center text-primary">{icon}</div>
                  <div>
                    <p className="text-base font-bold leading-none text-foreground">{value}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="relative"
          >
            <div className="aspect-square md:aspect-[4/3] rounded-2xl overflow-hidden bg-muted">
              <img
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=700&h=560&fit=crop"
                alt="Doctor with AI assistant"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating card — appointment */}
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
              className="absolute -bottom-4 -left-4 bg-card border border-border rounded-xl p-3 shadow-card"
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Calendar className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs font-semibold">Smart Appointment Booking</p>
                  <p className="text-xs text-muted-foreground">Across 42 hospitals in India</p>
                </div>
              </div>
            </motion.div>
            <motion.div
              animate={{ y: [0, 6, 0] }}
              transition={{ repeat: Infinity, duration: 3.5, ease: 'easeInOut', delay: 0.5 }}
              className="absolute -top-4 -right-4 bg-card border border-border rounded-xl p-3 shadow-card"
            >
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-accent" />
                </div>
                <div>
                  <p className="text-xs font-semibold">AI Medical Assistant</p>
                  <p className="text-xs text-muted-foreground">16 Indian languages supported</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* About */}
      <section id="features" className="bg-muted/30 py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-primary/10 text-primary border-0">About MediGuide AI</Badge>
            <h2 className="text-3xl font-bold mb-4">Healthcare Reimagined with AI</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We combine cutting-edge AI technology with compassionate healthcare to deliver faster,
              smarter, and more accessible medical services for everyone.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const Icon = featureIcons[feature.icon] || Activity;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  className="bg-card border border-border rounded-xl p-6 hover:shadow-hover transition-shadow"
                >
                  <div className={cn(
                    'w-10 h-10 rounded-lg flex items-center justify-center mb-4',
                    feature.color === 'primary' ? 'bg-primary/10' : 'bg-accent/10'
                  )}>
                    <Icon className={cn('w-5 h-5', feature.color === 'primary' ? 'text-primary' : 'text-accent')} />
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-accent/10 text-accent border-0">Our Services</Badge>
            <h2 className="text-3xl font-bold mb-4">Comprehensive Healthcare Services</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-4">
              {[
                { title: 'Smart Appointment Booking', desc: 'Book with top specialists instantly with real-time availability.' },
                { title: 'AI Medical Consultation', desc: 'Get evidence-based answers and report explanations powered by Gemini AI.' },
                { title: 'Voice-Enabled Assistance', desc: 'Interact hands-free using advanced speech recognition and synthesis.' },
                { title: 'Secure Medical Records', desc: 'Access and manage all your health documents in one encrypted place.' },
                { title: 'Medicine Reminders', desc: 'Never miss a dose with smart, personalized medication reminders.' },
              ].map((s, i) => (
                <motion.div
                  key={s.title}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                  className="flex gap-4 p-4 rounded-xl hover:bg-muted/50 transition-colors"
                >
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm mb-1">{s.title}</h4>
                    <p className="text-sm text-muted-foreground">{s.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=600&h=480&fit=crop"
                alt="Healthcare services"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20">
        <div className="max-w-3xl mx-auto px-6">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-accent/10 text-accent border-0">FAQ</Badge>
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          </div>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="border border-border rounded-xl px-5 data-[state=open]:shadow-card"
              >
                <AccordionTrigger className="text-sm font-medium hover:no-underline py-4">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground pb-4 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="bg-primary rounded-2xl p-10">
            <h2 className="text-2xl md:text-3xl font-bold text-primary-foreground mb-4">
              Ready to Experience Smarter Healthcare?
            </h2>
            <p className="text-primary-foreground/80 mb-8">
              Book appointments at real hospitals across India and get AI-powered medical guidance — anytime, in your language.
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Button asChild size="lg" variant="secondary">
                <Link to="/signup">Start Free Today</Link>
              </Button>
              <Button asChild size="lg" variant="ghost"
                className="border border-primary-foreground/60 text-primary-foreground hover:bg-primary-foreground/10">
                <Link to="/login">Sign In</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default LandingPage;
