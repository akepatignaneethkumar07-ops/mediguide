import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Users, Stethoscope, Calendar, DollarSign,
  Shield, Upload, Settings, Activity, AlertTriangle,
  TrendingUp, UserCheck, Eye, Trash2, Search, Plus,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import AppLayout from '@/components/layouts/AppLayout';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { supabase } from '@/db/supabase';

const uploadedDocs: any[] = [];
const auditLogs: any[] = [];

const AdminDashboard: React.FC = () => {
  const [userSearch, setUserSearch] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Add User Dialog State
  const [showAddUser, setShowAddUser] = useState(false);
  const [addUserForm, setAddUserForm] = useState({ name: '', email: '', password: '', role: 'patient' });
  const [isAdding, setIsAdding] = useState(false);

  const fetchUsers = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (!error && data) {
      const mapped = data.map((u: any) => ({
        id: u.id,
        name: u.name || 'Unknown',
        email: u.email || 'No email',
        role: u.role || 'patient',
        joined: new Date(u.created_at).toLocaleDateString(),
        status: 'active',
        avatar: u.avatar_url,
      }));
      setUsers(mapped);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const stats = [
    { label: 'Total Users', value: users.length, icon: Users, color: 'text-primary', change: 'Real-time' },
    { label: 'Doctors', value: users.filter(u => u.role === 'doctor').length, icon: Stethoscope, color: 'text-accent', change: 'Real-time' },
    { label: 'Hospitals', value: users.filter(u => u.role === 'hospital_member').length, icon: Activity, color: 'text-destructive', change: 'Real-time' },
    { label: 'Appointments', value: 1852, icon: Calendar, color: 'text-green-600', change: '+8%' },
  ];

  const filteredUsers = users.filter(u =>
    u.name.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.email.toLowerCase().includes(userSearch.toLowerCase()) ||
    u.role.includes(userSearch.toLowerCase())
  );

  const toggleUserStatus = (id: string) => {
    setUsers(prev => prev.map(u => u.id === id
      ? { ...u, status: u.status === 'active' ? 'inactive' : 'active' }
      : u
    ));
    toast.success('User status updated');
  };

  const handleAddUser = async () => {
    if (!addUserForm.name || !addUserForm.email || !addUserForm.password) {
      toast.error('Please fill in all fields');
      return;
    }
    setIsAdding(true);
    
    // We use signUp here to create the auth account. 
    // Since we're logged in as admin, ideally this would use admin API, 
    // but for this demo Supabase auth signUp will work (though it might sign the admin out depending on configuration, 
    // we assume allow custom user creation).
    const { data, error } = await supabase.auth.signUp({
      email: addUserForm.email,
      password: addUserForm.password,
      options: { data: { name: addUserForm.name, role: addUserForm.role } },
    });
    
    setIsAdding(false);
    if (error) {
      toast.error(error.message);
    } else {
      toast.success('User created successfully');
      setShowAddUser(false);
      setAddUserForm({ name: '', email: '', password: '', role: 'patient' });
      fetchUsers(); // Refresh the list
    }
  };

  return (
    <AppLayout title="Admin Dashboard" subtitle="System Administrator">
      <div className="space-y-6 max-w-7xl">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div key={s.label} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
                <Card>
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                        <Icon className={cn('w-5 h-5', s.color)} />
                      </div>
                      <Badge variant="secondary" className="text-xs">{s.change}</Badge>
                    </div>
                    <p className="text-2xl font-bold">{s.value}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <Tabs defaultValue="users" className="space-y-4">
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="users"><Users className="w-3.5 h-3.5 mr-1.5" />Users</TabsTrigger>
            <TabsTrigger value="rag"><Upload className="w-3.5 h-3.5 mr-1.5" />RAG Docs</TabsTrigger>
            <TabsTrigger value="analytics"><TrendingUp className="w-3.5 h-3.5 mr-1.5" />Analytics</TabsTrigger>
            <TabsTrigger value="audit"><Shield className="w-3.5 h-3.5 mr-1.5" />Audit Logs</TabsTrigger>
            <TabsTrigger value="settings"><Settings className="w-3.5 h-3.5 mr-1.5" />Settings</TabsTrigger>
          </TabsList>

          {/* User Management */}
          <TabsContent value="users">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between gap-3">
                <CardTitle className="text-base">User Management</CardTitle>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                    <Input placeholder="Search users..." className="pl-8 h-8 text-xs w-44"
                      value={userSearch} onChange={e => setUserSearch(e.target.value)} />
                  </div>
                  <Button size="sm" className="h-8" onClick={() => setShowAddUser(true)}>
                    <Plus className="w-3.5 h-3.5 mr-1" />Add User
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        {['User', 'Email', 'Role', 'Joined', 'Status', 'Actions'].map(h => (
                          <th key={h} className="text-left py-3 px-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map(user => (
                        <tr key={user.id} className="border-b border-border last:border-0 hover:bg-muted/30">
                          <td className="py-3 px-2 whitespace-nowrap">
                            <div className="flex items-center gap-2">
                              <Avatar className="w-7 h-7 shrink-0">
                                <AvatarImage src={user.avatar} />
                                <AvatarFallback className="text-xs">{user.name[0]}</AvatarFallback>
                              </Avatar>
                              <span className="font-medium">{user.name}</span>
                            </div>
                          </td>
                          <td className="py-3 px-2 text-muted-foreground text-xs whitespace-nowrap">{user.email}</td>
                          <td className="py-3 px-2 whitespace-nowrap">
                            <Badge variant="secondary" className="text-xs capitalize">{user.role}</Badge>
                          </td>
                          <td className="py-3 px-2 text-muted-foreground text-xs whitespace-nowrap">{user.joined}</td>
                          <td className="py-3 px-2 whitespace-nowrap">
                            <Badge className={cn('text-xs',
                              user.status === 'active'
                                ? 'bg-green-500/10 text-green-600'
                                : 'bg-muted text-muted-foreground'
                            )}>
                              {user.status}
                            </Badge>
                          </td>
                          <td className="py-3 px-2 whitespace-nowrap">
                            <div className="flex gap-1">
                              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toast.info(`Viewing ${user.name}`)}>
                                <Eye className="w-3.5 h-3.5" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7"
                                onClick={() => toggleUserStatus(user.id)}>
                                <UserCheck className="w-3.5 h-3.5" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => toast.error(`Delete ${user.name}?`)}>
                                <Trash2 className="w-3.5 h-3.5" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* RAG Document Upload */}
          <TabsContent value="rag">
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Upload Knowledge Documents</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-border rounded-xl p-8 text-center mb-4 hover:border-primary/40 transition-colors cursor-pointer"
                    onClick={() => toast.info('File upload dialog would open here (requires backend)')}>
                    <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
                    <p className="text-sm font-medium mb-1">Drop files here or click to upload</p>
                    <p className="text-xs text-muted-foreground">Supports PDF, DOCX, TXT — up to 50MB each</p>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {['PDF', 'DOCX', 'TXT'].map(t => (
                      <Badge key={t} variant="secondary" className="text-xs">{t}</Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Indexed Documents</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {uploadedDocs.map(doc => (
                    <div key={doc.id} className="flex items-center gap-3 p-3 rounded-xl border border-border">
                      <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <Upload className="w-4 h-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{doc.name}</p>
                        <p className="text-xs text-muted-foreground">{doc.type} · {doc.size} · {doc.uploaded}</p>
                      </div>
                      <Badge className={cn('text-xs shrink-0',
                        doc.status === 'indexed'
                          ? 'bg-green-500/10 text-green-600'
                          : 'bg-warning/10 text-warning'
                      )}>
                        {doc.status}
                      </Badge>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive shrink-0"
                        onClick={() => toast.success(`${doc.name} removed`)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-base">Monthly Appointments</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'].map((m, i) => {
                    const vals = [320, 380, 290, 420, 395, 450];
                    return (
                      <div key={m} className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground w-8">{m}</span>
                        <div className="flex-1 bg-muted rounded-full h-2">
                          <div className="bg-primary h-2 rounded-full" style={{ width: `${(vals[i] / 500) * 100}%` }} />
                        </div>
                        <span className="text-xs font-medium w-10 text-right">{vals[i]}</span>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-base">Revenue Trend</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'].map((m, i) => {
                    const vals = [32, 41, 28, 46, 39, 48];
                    return (
                      <div key={m} className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground w-8">{m}</span>
                        <div className="flex-1 bg-muted rounded-full h-2">
                          <div className="bg-accent h-2 rounded-full" style={{ width: `${(vals[i] / 50) * 100}%` }} />
                        </div>
                        <span className="text-xs font-medium w-12 text-right">${vals[i]}K</span>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-base">Top Departments</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { name: 'General Medicine', patients: 542, pct: 85 },
                    { name: 'Cardiology', patients: 284, pct: 65 },
                    { name: 'Pediatrics', patients: 318, pct: 72 },
                    { name: 'Neurology', patients: 196, pct: 48 },
                    { name: 'Orthopedics', patients: 162, pct: 40 },
                  ].map(d => (
                    <div key={d.name} className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground flex-1 truncate">{d.name}</span>
                      <div className="w-24 bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: `${d.pct}%` }} />
                      </div>
                      <span className="text-xs font-medium w-10 text-right">{d.patients}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-base">System Stats</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { label: 'Total Patients', value: '3,153', icon: Users },
                    { label: 'Active Doctors', value: '87', icon: Stethoscope },
                    { label: 'AI Chat Sessions', value: '12,840', icon: Activity },
                    { label: 'Documents Indexed', value: '47', icon: Upload },
                  ].map(stat => {
                    const Icon = stat.icon;
                    return (
                      <div key={stat.label} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Icon className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm text-muted-foreground">{stat.label}</span>
                        </div>
                        <span className="text-sm font-semibold">{stat.value}</span>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Audit Logs */}
          <TabsContent value="audit">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Shield className="w-4 h-4 text-primary" />Audit Logs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        {['Action', 'User', 'Timestamp', 'IP Address'].map(h => (
                          <th key={h} className="text-left py-3 px-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {auditLogs.map((log, i) => (
                        <tr key={i} className="border-b border-border last:border-0 hover:bg-muted/30">
                          <td className="py-3 px-2 font-medium whitespace-nowrap">{log.action}</td>
                          <td className="py-3 px-2 text-muted-foreground text-xs whitespace-nowrap">{log.user}</td>
                          <td className="py-3 px-2 text-muted-foreground text-xs whitespace-nowrap">{log.time}</td>
                          <td className="py-3 px-2 text-muted-foreground text-xs whitespace-nowrap font-mono">{log.ip}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings">
            <Card className="max-w-xl">
              <CardHeader className="pb-3"><CardTitle className="text-base">System Settings</CardTitle></CardHeader>
              <CardContent className="space-y-5">
                {[
                  { label: 'Allow Patient Self-Registration', desc: 'Patients can sign up without admin approval' },
                  { label: 'Email Notifications', desc: 'Send email alerts for appointments and reports' },
                  { label: 'AI Chat Feature', desc: 'Enable Gemini AI assistant for all users' },
                  { label: 'Voice Assistant', desc: 'Enable voice interaction feature' },
                  { label: 'RAG Knowledge Base', desc: 'Allow AI to answer from uploaded documents' },
                  { label: 'Maintenance Mode', desc: 'Temporarily disable user access to the system' },
                ].map((setting, i) => (
                  <div key={i} className="flex items-center justify-between gap-4">
                    <div>
                      <Label className="text-sm font-medium">{setting.label}</Label>
                      <p className="text-xs text-muted-foreground">{setting.desc}</p>
                    </div>
                    <Switch defaultChecked={i < 4} onCheckedChange={() => toast.success('Setting updated')} />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Dialog open={showAddUser} onOpenChange={setShowAddUser}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input value={addUserForm.name} onChange={e => setAddUserForm({ ...addUserForm, name: e.target.value })} placeholder="John Doe" />
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" value={addUserForm.email} onChange={e => setAddUserForm({ ...addUserForm, email: e.target.value })} placeholder="john@example.com" />
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" value={addUserForm.password} onChange={e => setAddUserForm({ ...addUserForm, password: e.target.value })} placeholder="Minimum 6 characters" />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <select 
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                value={addUserForm.role}
                onChange={e => setAddUserForm({ ...addUserForm, role: e.target.value })}
              >
                <option value="patient">Patient</option>
                <option value="doctor">Doctor</option>
                <option value="staff">Staff</option>
                <option value="hospital_member">Hospital Member</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddUser(false)}>Cancel</Button>
            <Button onClick={handleAddUser} disabled={isAdding}>{isAdding ? 'Saving...' : 'Save User'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default AdminDashboard;
