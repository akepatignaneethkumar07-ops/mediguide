import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Bell, Pill, Plus, Check, Trash2, Clock, CheckCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import {
  getMedicineReminders, createMedicineReminder, deleteMedicineReminder, markMedicineTaken,
} from '@/lib/api';
import type { MedicineReminder } from '@/types/types';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const MedicineReminderPage: React.FC = () => {
  const { user: authUser } = useAuth();
  const [meds, setMeds] = useState<MedicineReminder[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ name: '', dosage: '', frequency: 'once-daily', time1: '', time2: '' });

  useEffect(() => {
    if (!authUser?.id) return;
    getMedicineReminders(authUser.id).then(setMeds).finally(() => setLoading(false));
  }, [authUser?.id]);

  const handleToggleTaken = async (med: MedicineReminder) => {
    const newVal = !(med.taken_today?.[0] ?? false);
    await markMedicineTaken(med.id, newVal);
    setMeds(prev => prev.map(m => m.id === med.id ? { ...m, taken_today: [newVal] } : m));
    toast.success(newVal ? 'Marked as taken!' : 'Marked as not taken');
  };

  const handleDelete = async (id: string) => {
    await deleteMedicineReminder(id);
    setMeds(prev => prev.filter(m => m.id !== id));
    toast.success('Medicine removed');
  };

  const handleAdd = async () => {
    if (!authUser?.id) return;
    if (!form.name || !form.dosage || !form.time1) { toast.error('Name, dosage, and time are required.'); return; }
    setSubmitting(true);
    const times = form.frequency === 'twice-daily' && form.time2
      ? [form.time1, form.time2] : [form.time1];
    const result = await createMedicineReminder({
      name: form.name,
      dosage: form.dosage,
      frequency: form.frequency as import('@/types/types').ReminderFrequency,
      times,
    });
    setSubmitting(false);
    if (!result) { toast.error('Failed to add medicine. Please try again.'); return; }
    setMeds(prev => [...prev, result]);
    setForm({ name: '', dosage: '', frequency: 'once-daily', time1: '', time2: '' });
    setOpen(false);
    toast.success(`${form.name} added to your reminders!`);
  };

  const totalDoses = meds.reduce((acc, m) => acc + (m.times?.length ?? 1), 0);
  const takenDoses = meds.filter(m => m.taken_today?.[0]).length;
  const adherencePct = totalDoses > 0 ? Math.round((takenDoses / totalDoses) * 100) : 0;

  return (
    <AppLayout title="Medicine Reminder">
      <div className="space-y-6 max-w-3xl">
        {/* Summary */}
        <div className="grid grid-cols-3 gap-4">
          <Card><CardContent className="p-4 text-center">
            <Pill className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold">{meds.length}</p>
            <p className="text-xs text-muted-foreground">Active Medicines</p>
          </CardContent></Card>
          <Card><CardContent className="p-4 text-center">
            <CheckCircle className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">{takenDoses}/{totalDoses}</p>
            <p className="text-xs text-muted-foreground">Doses Today</p>
          </CardContent></Card>
          <Card><CardContent className="p-4 text-center">
            <Bell className="w-6 h-6 text-accent mx-auto mb-2" />
            <p className="text-2xl font-bold text-accent">{adherencePct}%</p>
            <p className="text-xs text-muted-foreground">Adherence</p>
          </CardContent></Card>
        </div>

        {/* Adherence bar */}
        <Card><CardContent className="p-4">
          <div className="flex justify-between text-sm mb-2">
            <span className="font-medium">Today's Adherence</span>
            <span className={cn('font-bold', adherencePct >= 80 ? 'text-green-600' : 'text-warning')}>{adherencePct}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2.5">
            <div className={cn('h-2.5 rounded-full transition-all', adherencePct >= 80 ? 'bg-green-500' : 'bg-warning')} style={{ width: `${adherencePct}%` }} />
          </div>
        </CardContent></Card>

        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">My Medicines</h3>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="w-3.5 h-3.5 mr-1.5" />Add Medicine</Button>
            </DialogTrigger>
            <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg">
              <DialogHeader><DialogTitle>Add New Medicine</DialogTitle></DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-1.5">
                  <Label>Medicine Name *</Label>
                  <Input placeholder="e.g. Metformin" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} />
                </div>
                <div className="space-y-1.5">
                  <Label>Dosage *</Label>
                  <Input placeholder="e.g. 500mg" value={form.dosage} onChange={e => setForm(p => ({ ...p, dosage: e.target.value }))} />
                </div>
                <div className="space-y-1.5">
                  <Label>Frequency</Label>
                  <Select value={form.frequency} onValueChange={v => setForm(p => ({ ...p, frequency: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="once-daily">Once Daily</SelectItem>
                      <SelectItem value="twice-daily">Twice Daily</SelectItem>
                      <SelectItem value="three-daily">Three Times Daily</SelectItem>
                      <SelectItem value="as-needed">As Needed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Reminder Time 1 *</Label>
                    <Input type="time" value={form.time1} onChange={e => setForm(p => ({ ...p, time1: e.target.value }))} />
                  </div>
                  {form.frequency === 'twice-daily' && (
                    <div className="space-y-1.5">
                      <Label>Reminder Time 2</Label>
                      <Input type="time" value={form.time2} onChange={e => setForm(p => ({ ...p, time2: e.target.value }))} />
                    </div>
                  )}
                </div>
                <Button className="w-full" onClick={handleAdd} disabled={submitting}>
                  {submitting ? 'Adding...' : 'Add Medicine'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Medicine cards */}
        {loading ? (
          <div className="space-y-4">{[1,2,3].map(i => <Card key={i}><CardContent className="p-5"><Skeleton className="h-20 w-full" /></CardContent></Card>)}</div>
        ) : meds.length === 0 ? (
          <div className="text-center py-16">
            <Pill className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="font-medium text-muted-foreground">No medicines added yet</p>
            <p className="text-sm text-muted-foreground/60 mt-1">Add your medicines to set up reminders</p>
          </div>
        ) : (
          <div className="space-y-4">
            {meds.map((med, i) => (
              <motion.div key={med.id} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}>
                <Card>
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Pill className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">{med.name}</h4>
                          <p className="text-xs text-muted-foreground">{med.dosage} · {med.frequency.replace('-', ' ')}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDelete(med.id)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                    <div className={cn('flex items-center justify-between p-3 rounded-lg border transition-colors',
                      med.taken_today ? 'border-green-200 bg-green-500/5' : 'border-border')}>
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-sm">{med.times?.[0] || 'Scheduled'}</span>
                      </div>
                      <button onClick={() => handleToggleTaken(med)}
                        className={cn('flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg font-medium transition-colors',
                          med.taken_today?.[0] ? 'bg-green-500/10 text-green-600 hover:bg-green-500/20' : 'bg-muted hover:bg-primary/10 hover:text-primary')}>
                        {med.taken_today?.[0] ? <><Check className="w-3 h-3" />Taken</> : <>Mark Taken</>}
                      </button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default MedicineReminderPage;
