import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Volume2, VolumeX, Bot, AlertCircle, Loader2, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import AppLayout from '@/components/layouts/AppLayout';
import { supabase } from '@/db/supabase';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

type AssistantState = 'idle' | 'recording' | 'transcribing' | 'processing' | 'responding';

interface SessionEntry { q: string; a: string; }

// Build a contextual response from the transcript
function buildResponse(transcript: string): string {
  const t = transcript.toLowerCase();
  if (t.includes('appointment') || t.includes('book') || t.includes('schedule')) {
    return "I can help you book an appointment! Please visit the 'Book Appointment' section in your dashboard. You can browse by department, choose a doctor, select your preferred hospital location, and pick an available time slot. Would you like me to guide you through the process?";
  }
  if (t.includes('doctor') || t.includes('specialist') || t.includes('find')) {
    return "Our Doctor Directory lists 200+ verified specialists across all major departments — Cardiology, Neurology, Pediatrics, Orthopedics, Dermatology, Psychiatry, and more. You can filter by department and availability. Shall I help you find the right specialist?";
  }
  if (t.includes('report') || t.includes('result') || t.includes('cbc') || t.includes('blood')) {
    return "Your medical reports are available in the 'Medical Reports' section. Each report includes a summary and your doctor's notes. If you have specific questions about your results, I recommend discussing them with your doctor during your next visit. Is there a particular report you'd like help understanding?";
  }
  if (t.includes('remind') || t.includes('medicine') || t.includes('medication') || t.includes('tablet')) {
    return "You can set medicine reminders in the 'Medicine Reminders' section. Add your medication name, dosage, and preferred times, and the app will send you timely notifications so you never miss a dose.";
  }
  if (t.includes('emergency') || t.includes('urgent') || t.includes('pain')) {
    return "If this is a medical emergency, please call 112 immediately or visit the nearest emergency department. For urgent but non-emergency concerns, you can book a same-day appointment through the 'Book Appointment' section and filter for available slots today.";
  }
  return "Thank you for your question. Based on general medical knowledge, I can provide informational guidance — but please remember this is not a substitute for professional medical advice. For accurate diagnosis and treatment, I strongly recommend consulting one of our qualified specialists. Would you like to book an appointment?";
}

const VoiceAssistantPage: React.FC = () => {
  const [state, setState] = useState<AssistantState>('idle');
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [sessionHistory, setSessionHistory] = useState<SessionEntry[]>([]);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      mediaRecorderRef.current?.stop();
      audioRef.current?.pause();
    };
  }, []);

  const stopSpeaking = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
      audioRef.current = null;
    }
    setIsSpeaking(false);
  }, []);

  // Step 3: TTS — speak the AI response
  const speakResponse = useCallback(async (text: string) => {
    setState('responding');
    setIsSpeaking(true);
    try {
      const { data, error } = await supabase.functions.invoke('text-to-speech', {
        body: { input: text, voice: 'heart', response_format: 'mp3' },
      });
      if (error) throw error;
      const audio = new Audio(data.audioUrl);
      audioRef.current = audio;
      audio.play();
      audio.onended = () => { setIsSpeaking(false); audioRef.current = null; };
      audio.onerror = () => { setIsSpeaking(false); toast.error('Failed to play voice response'); };
    } catch {
      setIsSpeaking(false);
      toast.error('Could not generate voice response.');
    }
  }, []);

  // Step 2: STT — upload audio blob → transcribe → respond
  const transcribeAndRespond = useCallback(async (blob: Blob) => {
    setState('transcribing');
    try {
      const fileName = `voice-${Date.now()}.webm`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('generated-media')
        .upload(`recordings/${fileName}`, blob, { contentType: blob.type || 'audio/webm' });
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('generated-media')
        .getPublicUrl(uploadData.path);

      setState('processing');
      const { data, error } = await supabase.functions.invoke('speech-to-text', {
        body: { fileUrl: urlData.publicUrl },
      });
      if (error) throw error;

      const text: string = data?.text?.trim() ?? '';
      if (!text) { toast.warning('Could not detect speech. Please try again.'); setState('idle'); return; }

      setTranscript(text);
      const aiResponse = buildResponse(text);
      setResponse(aiResponse);
      setSessionHistory(prev => [...prev, { q: text, a: aiResponse }]);
      await speakResponse(aiResponse);
    } catch {
      toast.error('Transcription failed. Please try again.');
      setState('idle');
    }
  }, [speakResponse]);

  // Step 1: Record mic
  const handleMicClick = useCallback(async () => {
    // Stop speaking if active
    if (isSpeaking) { stopSpeaking(); return; }
    // Stop recording if active
    if (state === 'recording') { mediaRecorderRef.current?.stop(); return; }
    if (state !== 'idle' && state !== 'responding') return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4';
      const recorder = new MediaRecorder(stream, { mimeType });
      audioChunksRef.current = [];

      recorder.ondataavailable = e => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      recorder.onstop = () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        transcribeAndRespond(blob);
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setState('recording');
      setTranscript('');
      setResponse('');
    } catch {
      toast.error('Microphone access denied. Please allow microphone permission in your browser settings.');
    }
  }, [state, isSpeaking, stopSpeaking, transcribeAndRespond]);

  const handleReset = () => {
    stopSpeaking();
    mediaRecorderRef.current?.stop();
    setState('idle');
    setTranscript('');
    setResponse('');
  };

  const stateLabel: Record<AssistantState, string> = {
    idle: 'Tap the mic to start speaking',
    recording: 'Listening… tap again to stop',
    transcribing: 'Transcribing your voice…',
    processing: 'Thinking…',
    responding: isSpeaking ? 'Speaking — tap to stop' : 'Done',
  };

  const micBusy = state === 'transcribing' || state === 'processing';

  return (
    <AppLayout title="Voice Assistant">
      <div className="max-w-2xl mx-auto space-y-6">

        {/* Disclaimer */}
        <div className="flex items-start gap-2.5 p-3 bg-warning/10 border border-warning/20 rounded-xl">
          <AlertCircle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">
            Voice AI provides informational guidance only — not a substitute for professional medical advice.
          </p>
        </div>

        {/* Main Voice Interface */}
        <Card>
          <CardContent className="p-8 flex flex-col items-center">

            {/* Mic / control button */}
            <div className="relative mb-8">
              {state === 'recording' && (
                <>
                  <div className="absolute inset-0 rounded-full bg-destructive/20 animate-ping" style={{ animationDuration: '1.2s' }} />
                  <div className="absolute inset-0 rounded-full bg-destructive/10 animate-ping" style={{ animationDuration: '1.8s' }} />
                </>
              )}
              {(state === 'responding' && isSpeaking) && (
                <>
                  <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" style={{ animationDuration: '1.4s' }} />
                </>
              )}
              <motion.button
                onClick={handleMicClick}
                disabled={micBusy}
                whileTap={!micBusy ? { scale: 0.93 } : {}}
                className={cn(
                  'relative z-10 w-24 h-24 rounded-full flex items-center justify-center transition-colors disabled:opacity-50 disabled:cursor-wait',
                  state === 'recording'
                    ? 'bg-destructive text-destructive-foreground'
                    : micBusy
                      ? 'bg-muted text-muted-foreground'
                      : (state === 'responding' && isSpeaking)
                        ? 'bg-accent text-white'
                        : 'bg-primary text-primary-foreground'
                )}
              >
                {micBusy
                  ? <Loader2 className="w-10 h-10 animate-spin" />
                  : state === 'recording'
                    ? <MicOff className="w-10 h-10" />
                    : (state === 'responding' && isSpeaking)
                      ? <VolumeX className="w-10 h-10" />
                      : <Mic className="w-10 h-10" />
                }
              </motion.button>
            </div>

            {/* State label */}
            <p className={cn(
              'text-sm font-medium mb-6 text-center',
              state === 'recording' ? 'text-destructive'
                : micBusy ? 'text-muted-foreground'
                  : (state === 'responding' && isSpeaking) ? 'text-primary'
                    : 'text-muted-foreground'
            )}>
              {stateLabel[state]}
            </p>

            {/* Animated waveform while recording */}
            {state === 'recording' && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="flex items-center gap-1 h-12 mb-6">
                {Array.from({ length: 18 }).map((_, i) => (
                  <motion.div key={i}
                    className="w-1.5 rounded-full bg-destructive"
                    animate={{ height: ['8px', `${16 + Math.random() * 24}px`, '8px'] }}
                    transition={{ duration: 0.6 + Math.random() * 0.4, repeat: Infinity, delay: i * 0.05 }}
                  />
                ))}
              </motion.div>
            )}

            {/* Loader dots while transcribing/processing */}
            {micBusy && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                className="flex items-center gap-2 mb-6">
                {[0, 0.15, 0.3].map((delay, i) => (
                  <motion.div key={i}
                    className="w-2 h-2 rounded-full bg-primary"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 0.9, repeat: Infinity, delay }}
                  />
                ))}
              </motion.div>
            )}

            {/* Transcript */}
            <AnimatePresence>
              {transcript && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                  className="w-full p-4 bg-muted/50 rounded-xl mb-4">
                  <p className="text-xs text-muted-foreground mb-1 font-medium">You said:</p>
                  <p className="text-sm leading-relaxed">{transcript}</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* AI Response */}
            <AnimatePresence>
              {response && (state === 'responding') && (
                <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                  className="w-full">
                  <div className="p-4 bg-primary/5 border border-primary/20 rounded-xl mb-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center">
                        <Bot className="w-3.5 h-3.5 text-primary-foreground" />
                      </div>
                      <span className="text-xs font-semibold text-primary">MediGuide AI</span>
                      {isSpeaking && (
                        <span className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
                          <Volume2 className="w-3.5 h-3.5 text-primary animate-pulse" /> Speaking…
                        </span>
                      )}
                    </div>
                    <p className="text-sm leading-relaxed">{response}</p>
                  </div>

                  <Button variant="outline" size="sm" className="w-full" onClick={handleReset}>
                    <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Ask another question
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>

        {/* Session history */}
        {sessionHistory.length > 0 && (
          <Card>
            <CardContent className="p-4 space-y-3">
              <p className="text-xs font-semibold text-muted-foreground">Session History</p>
              {sessionHistory.map((item, i) => (
                <div key={i} className="space-y-1 py-3 border-b border-border last:border-0">
                  <p className="text-xs text-muted-foreground">You: {item.q}</p>
                  <p className="text-xs text-foreground/80 leading-relaxed">{item.a.slice(0, 120)}…</p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

      </div>
    </AppLayout>
  );
};

export default VoiceAssistantPage;
