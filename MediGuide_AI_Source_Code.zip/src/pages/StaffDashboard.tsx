import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Calendar, Users, DollarSign, Activity, CheckCircle,
  Clock, AlertCircle, Plus, Search, TrendingUp, UserPlus,
  BarChart3,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import AppLayout from '@/components/layouts/AppLayout';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const billingData: any[] = [];
const staffAppointments: any[] = [];

const StaffDashboard: React.FC = () => {
  const [search, setSearch] = useState('');
  const [regForm, setRegForm] = useState({ name: '', age: '', gender: '', phone: '', email: '' });

  const stats = [
    { label: "Today's Appointments", value: staffAppointments.length, icon: Calendar, color: 'text-primary' },
    { label: 'Waiting Patients', value: staffAppointments.filter(a => a.status === 'waiting').length, icon: Clock, color: 'text-warning' },
    { label: 'Completed', value: staffAppointments.filter(a => a.status === 'completed').length, icon: CheckCircle, color: 'text-green-600' },
    { label: "Today's Revenue", value: '$1,820', icon: DollarSign, color: 'text-accent' },
  ];

  const filtered = staffAppointments.filter(a =>
    a.patient.toLowerCase().includes(search.toLowerCase()) ||
    a.doctor.toLowerCase().includes(search.toLowerCase())
  );

  const statusColor = {
    completed: 'bg-green-500/10 text-green-600',
    'in-progress': 'bg-primary/10 text-primary',
    waiting: 'bg-warning/10 text-warning',
    confirmed: 'bg-accent/10 text-accent',
    cancelled: 'bg-destructive/10 text-destructive',
  };

  const handleRegister = () => {
    if (!regForm.name || !regForm.phone) { toast.error('Name and phone are required.'); return; }
    toast.success(`Patient ${regForm.name} registered successfully!`);
    setRegForm({ name: '', age: '', gender: '', phone: '', email: '' });
  };

  return (
    <AppLayout title="Staff Dashboard" subtitle="Hospital Receptionist">
      <div className="space-y-6 max-w-7xl">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div key={s.label} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs text-muted-foreground leading-tight">{s.label}</p>
                      <Icon className={cn('w-4 h-4 shrink-0', s.color)} />
                    </div>
                    <p className="text-2xl font-bold">{s.value}</p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <Tabs defaultValue="appointments" className="space-y-4">
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="appointments"><Calendar className="w-3.5 h-3.5 mr-1.5" />Appointments</TabsTrigger>
            <TabsTrigger value="registration"><UserPlus className="w-3.5 h-3.5 mr-1.5" />Register Patient</TabsTrigger>
            <TabsTrigger value="billing"><DollarSign className="w-3.5 h-3.5 mr-1.5" />Billing</TabsTrigger>
            <TabsTrigger value="analytics"><BarChart3 className="w-3.5 h-3.5 mr-1.5" />Analytics</TabsTrigger>
          </TabsList>

          {/* Appointments */}
          <TabsContent value="appointments">
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between gap-3">
                <CardTitle className="text-base">Appointment Queue</CardTitle>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                    <Input
                      placeholder="Search patient..."
                      className="pl-8 h-8 text-xs w-44"
                      value={search}
                      onChange={e => setSearch(e.target.value)}
                    />
                  </div>
                  <Button size="sm" className="h-8" onClick={() => toast.info('New appointment form coming soon')}>
                    <Plus className="w-3.5 h-3.5 mr-1" />New
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        {['ID', 'Patient', 'Age', 'Time', 'Doctor', 'Dept', 'Status'].map(h => (
                          <th key={h} className="text-left py-3 px-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map(appt => (
                        <tr key={appt.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                          <td className="py-3 px-2 text-xs text-muted-foreground whitespace-nowrap">{appt.id}</td>
                          <td className="py-3 px-2 font-medium whitespace-nowrap">{appt.patient}</td>
                          <td className="py-3 px-2 text-muted-foreground whitespace-nowrap">{appt.age}</td>
                          <td className="py-3 px-2 whitespace-nowrap">{appt.time}</td>
                          <td className="py-3 px-2 text-muted-foreground whitespace-nowrap">{appt.doctor}</td>
                          <td className="py-3 px-2 text-muted-foreground whitespace-nowrap">{appt.dept}</td>
                          <td className="py-3 px-2 whitespace-nowrap">
                            <Badge className={cn('text-xs', statusColor[appt.status as keyof typeof statusColor] || '')}>
                              {appt.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Patient Registration */}
          <TabsContent value="registration">
            <Card className="max-w-xl">
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Register New Patient</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2 space-y-1.5">
                    <Label>Full Name *</Label>
                    <Input value={regForm.name} onChange={e => setRegForm(p => ({ ...p, name: e.target.value }))} placeholder="Patient full name" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Age *</Label>
                    <Input type="number" value={regForm.age} onChange={e => setRegForm(p => ({ ...p, age: e.target.value }))} placeholder="Age" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Gender</Label>
                    <Select value={regForm.gender} onValueChange={v => setRegForm(p => ({ ...p, gender: v }))}>
                      <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Phone Number *</Label>
                    <Input value={regForm.phone} onChange={e => setRegForm(p => ({ ...p, phone: e.target.value }))} placeholder="+1 555 0000" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Email</Label>
                    <Input type="email" value={regForm.email} onChange={e => setRegForm(p => ({ ...p, email: e.target.value }))} placeholder="email@example.com" />
                  </div>
                </div>
                <Button className="w-full" onClick={handleRegister}>
                  <UserPlus className="w-4 h-4 mr-2" />Register Patient
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Billing */}
          <TabsContent value="billing">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Billing Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-3 mb-6">
                  {[
                    { label: 'Collected', value: '$850', color: 'text-green-600' },
                    { label: 'Pending', value: '$100', color: 'text-warning' },
                    { label: 'Overdue', value: '$130', color: 'text-destructive' },
                  ].map(item => (
                    <div key={item.label} className="text-center p-3 bg-muted/50 rounded-xl">
                      <p className={cn('text-xl font-bold', item.color)}>{item.value}</p>
                      <p className="text-xs text-muted-foreground">{item.label}</p>
                    </div>
                  ))}
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        {['Invoice', 'Patient', 'Amount', 'Date', 'Status'].map(h => (
                          <th key={h} className="text-left py-2 px-2 text-xs font-semibold text-muted-foreground whitespace-nowrap">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {billingData.map(inv => (
                        <tr key={inv.id} className="border-b border-border last:border-0 hover:bg-muted/30">
                          <td className="py-3 px-2 text-xs text-muted-foreground whitespace-nowrap">{inv.id}</td>
                          <td className="py-3 px-2 font-medium whitespace-nowrap">{inv.patient}</td>
                          <td className="py-3 px-2 font-medium whitespace-nowrap">${inv.amount}</td>
                          <td className="py-3 px-2 text-muted-foreground whitespace-nowrap">{inv.date}</td>
                          <td className="py-3 px-2 whitespace-nowrap">
                            <Badge className={cn('text-xs',
                              inv.status === 'paid' ? 'bg-green-500/10 text-green-600'
                                : inv.status === 'pending' ? 'bg-warning/10 text-warning'
                                  : 'bg-destructive/10 text-destructive'
                            )}>
                              {inv.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-base">Department Utilization</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { name: 'General Medicine', pct: 85, count: 42 },
                    { name: 'Cardiology', pct: 72, count: 18 },
                    { name: 'Neurology', pct: 60, count: 15 },
                    { name: 'Pediatrics', pct: 90, count: 22 },
                    { name: 'Dermatology', pct: 55, count: 14 },
                  ].map(d => (
                    <div key={d.name} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>{d.name}</span>
                        <span className="font-medium">{d.count} pts</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: `${d.pct}%` }} />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3"><CardTitle className="text-base">Appointment Trends</CardTitle></CardHeader>
                <CardContent className="space-y-3">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, i) => {
                    const vals = [28, 35, 32, 24, 38, 18];
                    return (
                      <div key={day} className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground w-8">{day}</span>
                        <div className="flex-1 bg-muted rounded-full h-2">
                          <div className="bg-accent h-2 rounded-full" style={{ width: `${(vals[i] / 40) * 100}%` }} />
                        </div>
                        <span className="text-xs font-medium w-8">{vals[i]}</span>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* AI Alerts */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="w-4 h-4 text-primary" />
              AI-Generated Alerts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[
              { type: 'warning', msg: 'Cardiology dept at 95% capacity today. Consider redirecting 2 walk-in patients.' },
              { type: 'info', msg: 'Dr. Williams has 3 back-to-back appointments — suggest a 15-min break at 11:30 AM.' },
              { type: 'success', msg: 'Patient queue wait times are on track. Average wait: 8 minutes.' },
            ].map((alert, i) => (
              <div key={i} className={cn('flex gap-3 p-3 rounded-lg text-sm',
                alert.type === 'warning' ? 'bg-warning/10 text-warning'
                  : alert.type === 'info' ? 'bg-primary/10 text-primary'
                    : 'bg-green-500/10 text-green-700'
              )}>
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <p>{alert.msg}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default StaffDashboard;
