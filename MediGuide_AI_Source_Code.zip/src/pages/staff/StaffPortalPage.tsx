import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Calendar, Users, Clock, CheckCircle, Building2,
  Search, Stethoscope, User, RefreshCw, LogOut,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface HospitalInfo {
  id: string;
  name: string;
  city: string;
  address: string;
  maps_query: string;
}

interface PatientAppt {
  id: string;
  patient_name: string;
  doctor_name: string;
  department: string;
  date: string;
  time: string;
  status: string;
  symptoms?: string;
}

interface DoctorSchedule {
  id: string;
  name: string;
  specialization: string;
  availability: string;
  next_slot?: string;
}

const STATUS_COLORS: Record<string, string> = {
  pending:    'bg-warning/10 text-warning border-warning/20',
  confirmed:  'bg-green-500/10 text-green-600 border-green-200',
  completed:  'bg-muted text-muted-foreground border-border',
  cancelled:  'bg-destructive/10 text-destructive border-destructive/20',
  'in-progress': 'bg-primary/10 text-primary border-primary/20',
};

const AVAIL_COLORS: Record<string, string> = {
  available: 'bg-green-500/10 text-green-600',
  busy:      'bg-warning/10 text-warning',
  offline:   'bg-muted text-muted-foreground',
};

const StaffPortalPage: React.FC = () => {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [hospital, setHospital] = useState<HospitalInfo | null>(null);
  const [appointments, setAppointments] = useState<PatientAppt[]>([]);
  const [doctors, setDoctors] = useState<DoctorSchedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState('patients');

  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (!profile) return;
    loadData();
  }, [profile]);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load hospital info from profile's hospital_id
      if (profile?.hospital_id) {
        const { data: hosp } = await supabase
          .from('hospitals')
          .select('id, name, city, address, maps_query')
          .eq('id', profile.hospital_id)
          .maybeSingle();
        if (hosp) setHospital(hosp);
      }

      // Load today's appointments — for staff we show all (no hospital_id filter on appointments yet)
      const { data: appts } = await supabase
        .from('appointments')
        .select(`
          id, doctor_name, department, date, time, status, symptoms,
          profiles!appointments_patient_id_fkey(name)
        `)
        .eq('date', today)
        .order('time', { ascending: true })
        .limit(50);

      if (appts) {
        setAppointments(
          appts.map((a: Record<string, unknown>) => ({
            id: a.id as string,
            patient_name: (a.profiles as { name?: string } | null)?.name ?? 'Unknown',
            doctor_name: a.doctor_name as string,
            department: a.department as string,
            date: a.date as string,
            time: a.time as string,
            status: a.status as string,
            symptoms: a.symptoms as string | undefined,
          }))
        );
      }

      // Load doctors list
      const { data: docs } = await supabase
        .from('doctors')
        .select('id, name, specialization, availability, next_slot')
        .order('name')
        .limit(30);
      if (docs) setDoctors(docs as DoctorSchedule[]);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = async (id: string) => {
    await supabase.from('appointments').update({ status: 'confirmed' }).eq('id', id);
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: 'confirmed' } : a));
    toast.success('Appointment confirmed');
  };

  const handleCancel = async (id: string) => {
    await supabase.from('appointments').update({ status: 'cancelled' }).eq('id', id);
    setAppointments(prev => prev.map(a => a.id === id ? { ...a, status: 'cancelled' } : a));
    toast.success('Appointment cancelled');
  };

  const filteredAppts = appointments.filter(a =>
    !search ||
    a.patient_name.toLowerCase().includes(search.toLowerCase()) ||
    a.doctor_name.toLowerCase().includes(search.toLowerCase()) ||
    a.department.toLowerCase().includes(search.toLowerCase())
  );

  const filteredDocs = doctors.filter(d =>
    !search || d.name.toLowerCase().includes(search.toLowerCase()) ||
    d.specialization.toLowerCase().includes(search.toLowerCase())
  );

  const stats = [
    { label: "Today's Patients", value: appointments.length, icon: Users, color: 'text-primary' },
    { label: 'Pending',          value: appointments.filter(a => a.status === 'pending').length,   icon: Clock,         color: 'text-warning' },
    { label: 'Confirmed',        value: appointments.filter(a => a.status === 'confirmed').length, icon: CheckCircle,   color: 'text-green-600' },
    { label: 'Doctors On Duty',  value: doctors.filter(d => d.availability === 'available').length, icon: Stethoscope,  color: 'text-accent' },
  ];

  return (
    <AppLayout title="Staff Portal" subtitle={hospital?.name ?? 'Hospital Dashboard'}>
      <div className="space-y-6 max-w-6xl">

        {/* Hospital info banner */}
        {hospital && (
          <Card className="border-primary/20 bg-primary/4">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <Building2 className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm">{hospital.name}</p>
                <p className="text-xs text-muted-foreground truncate">{hospital.address}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/hospital-map')}
                className="shrink-0 text-xs"
              >
                View on Map
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                <Card>
                  <CardContent className="p-4 flex items-center gap-3">
                    <Icon className={cn('w-8 h-8 shrink-0', s.color)} />
                    <div>
                      <p className={cn('text-xl font-bold leading-none', s.color)}>
                        {loading ? '—' : s.value}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Toolbar */}
        <div className="flex flex-col md:flex-row gap-3 justify-between">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              placeholder="Search patients, doctors, departments…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Button variant="outline" size="sm" onClick={loadData} className="shrink-0">
            <RefreshCw className="w-4 h-4 mr-1.5" />Refresh
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="patients">
              Today's Patients
              {!loading && appointments.length > 0 && (
                <Badge variant="secondary" className="ml-2 text-[10px] px-1.5 py-0">{appointments.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="doctors">OP Doctor Timings</TabsTrigger>
          </TabsList>

          {/* Patients tab */}
          <TabsContent value="patients" className="mt-4">
            {loading ? (
              <div className="space-y-3">
                {[1,2,3].map(i => (
                  <Card key={i}><CardContent className="p-4 space-y-2">
                    <Skeleton className="h-5 w-40" /><Skeleton className="h-4 w-64" />
                  </CardContent></Card>
                ))}
              </div>
            ) : filteredAppts.length === 0 ? (
              <div className="text-center py-12">
                <Calendar className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-30" />
                <p className="text-muted-foreground">No appointments found for today</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full min-w-max">
                  <thead>
                    <tr className="border-b border-border">
                      {['Patient', 'Doctor', 'Department', 'Time', 'Status', 'Actions'].map(h => (
                        <th key={h} className="text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider px-4 py-3 whitespace-nowrap">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAppts.map((a, i) => (
                      <motion.tr
                        key={a.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: i * 0.04 }}
                        className="border-b border-border/60 hover:bg-muted/30 transition-colors"
                      >
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                              <User className="w-3.5 h-3.5 text-primary" />
                            </div>
                            <span className="text-sm font-medium">{a.patient_name}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm whitespace-nowrap">{a.doctor_name}</td>
                        <td className="px-4 py-3 text-sm whitespace-nowrap">{a.department}</td>
                        <td className="px-4 py-3 text-sm whitespace-nowrap">{a.time}</td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Badge className={cn('text-xs', STATUS_COLORS[a.status] || 'bg-muted text-muted-foreground')}>
                            {a.status}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="flex gap-1.5">
                            {a.status === 'pending' && (
                              <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => handleConfirm(a.id)}>
                                Confirm
                              </Button>
                            )}
                            {(a.status === 'pending' || a.status === 'confirmed') && (
                              <Button size="sm" variant="outline" className="h-7 text-xs text-destructive hover:text-destructive" onClick={() => handleCancel(a.id)}>
                                Cancel
                              </Button>
                            )}
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>

          {/* Doctors OP tab */}
          <TabsContent value="doctors" className="mt-4">
            {loading ? (
              <div className="grid md:grid-cols-2 gap-4">
                {[1,2,3,4].map(i => (
                  <Card key={i}><CardContent className="p-4 space-y-2"><Skeleton className="h-5 w-40" /><Skeleton className="h-4 w-32" /></CardContent></Card>
                ))}
              </div>
            ) : filteredDocs.length === 0 ? (
              <div className="text-center py-12">
                <Stethoscope className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-30" />
                <p className="text-muted-foreground">No doctors found</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDocs.map((doc, i) => (
                  <motion.div key={doc.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                    <Card>
                      <CardContent className="p-4 flex items-start gap-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                          <Stethoscope className="w-5 h-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate">{doc.name}</p>
                          <p className="text-xs text-muted-foreground">{doc.specialization}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge className={cn('text-[10px] px-1.5 py-0', AVAIL_COLORS[doc.availability] || AVAIL_COLORS.offline)}>
                              {doc.availability}
                            </Badge>
                            {doc.next_slot && (
                              <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {doc.next_slot}
                              </span>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default StaffPortalPage;
