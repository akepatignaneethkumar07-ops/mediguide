import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Search, Building2, Navigation, Cross, Pill } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import AppLayout from '@/components/layouts/AppLayout';
import { LOCATIONS } from '@/data/locations';
import { cn } from '@/lib/utils';

const MAPS_KEY = 'AIzaSyB_LJOYJL-84SMuxNB7LtRGhxEQLjswvy0';

const HospitalMapPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(LOCATIONS[0]);
  const [showPharmacies, setShowPharmacies] = useState(false);

  const filtered = LOCATIONS.filter(l =>
    !search ||
    l.name.toLowerCase().includes(search.toLowerCase()) ||
    l.city.toLowerCase().includes(search.toLowerCase())
  );

  const mapsQuery = showPharmacies 
    ? encodeURIComponent('Medical stores and Pharmacies near ' + selected.name + ' ' + selected.city + ' India')
    : encodeURIComponent(selected.name + ' ' + selected.city + ' India');

  return (
    <AppLayout title="Locations" subtitle="Find hospitals and pharmacies across India">
      <div className="space-y-4 max-w-6xl">

        {/* Search */}
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative max-w-sm flex-1 w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            <Input
              placeholder="Search by name or city…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex items-center gap-2 bg-muted/50 p-1 rounded-lg border border-border">
            <Button 
              variant={!showPharmacies ? 'default' : 'ghost'} 
              size="sm" 
              onClick={() => setShowPharmacies(false)}
              className={!showPharmacies ? 'shadow-sm' : ''}
            >
              <Building2 className="w-4 h-4 mr-2" />
              Hospitals
            </Button>
            <Button 
              variant={showPharmacies ? 'default' : 'ghost'} 
              size="sm" 
              onClick={() => setShowPharmacies(true)}
              className={showPharmacies ? 'shadow-sm' : ''}
            >
              <Pill className="w-4 h-4 mr-2" />
              Near Medical Stores
            </Button>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-4">
          {/* Hospital list */}
          <div className="lg:w-80 shrink-0 space-y-2 max-h-[600px] overflow-y-auto pr-1">
            {filtered.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-sm text-muted-foreground">No hospitals found</p>
              </div>
            ) : (
              filtered.map((loc, i) => (
                <motion.div
                  key={loc.id}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <button
                    onClick={() => setSelected(loc)}
                    className={cn(
                      'w-full text-left p-3 rounded-xl border transition-all',
                      selected.id === loc.id
                        ? 'border-primary bg-primary/6 shadow-sm'
                        : 'border-border hover:bg-muted/30'
                    )}
                  >
                    <div className="flex items-start gap-2.5">
                      <div className={cn(
                        'w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5',
                        selected.id === loc.id ? 'bg-primary/15' : 'bg-muted'
                      )}>
                        {loc.type?.toLowerCase().includes('pharmacy') ? (
                          <Pill className={cn('w-4 h-4', selected.id === loc.id ? 'text-primary' : 'text-muted-foreground')} />
                        ) : (
                          <Building2 className={cn('w-4 h-4', selected.id === loc.id ? 'text-primary' : 'text-muted-foreground')} />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium leading-tight">{loc.name}</p>
                        <div className="flex items-center gap-1.5 mt-1">
                          <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{loc.city}</Badge>
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed line-clamp-2">{loc.address}</p>
                      </div>
                    </div>
                  </button>
                </motion.div>
              ))
            )}
          </div>

          {/* Map area */}
          <div className="flex-1 min-w-0 space-y-3">
            {/* Selected location info */}
            <Card className="border-primary/20">
              <CardContent className="p-4 flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  {selected.type?.toLowerCase().includes('pharmacy') ? (
                    <Pill className="w-5 h-5 text-primary" />
                  ) : (
                    <Building2 className="w-5 h-5 text-primary" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{selected.name}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{selected.address}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="secondary" className="text-[10px]">{selected.city}</Badge>
                    <Badge variant="outline" className="text-[10px]">{selected.type}</Badge>
                  </div>
                </div>
                <a
                  href={`https://maps.google.com/?q=${encodeURIComponent(selected.name + ' ' + selected.address)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <Button variant="outline" size="sm" className="shrink-0 text-xs">
                    <Navigation className="w-3.5 h-3.5 mr-1.5" />Directions
                  </Button>
                </a>
              </CardContent>
            </Card>

            {/* Embedded Map */}
            <div className="w-full rounded-2xl overflow-hidden border border-border shadow-sm">
              <iframe
                key={selected.id}
                title={`Map – ${selected.name}`}
                width="100%"
                height="420"
                frameBorder="0"
                style={{ border: 0 }}
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://www.google.com/maps/embed/v1/place?key=${MAPS_KEY}&q=${mapsQuery}&language=en&region=IN`}
                allowFullScreen
              />
            </div>

            {/* Address below map */}
            <div className="flex items-start gap-2 text-sm text-muted-foreground px-1">
              <MapPin className="w-4 h-4 mt-0.5 shrink-0 text-primary" />
              <span>{selected.address}</span>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default HospitalMapPage;
