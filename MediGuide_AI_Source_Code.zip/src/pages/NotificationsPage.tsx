import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Bell, Calendar, FileText, Activity, Megaphone, Trash2, CheckCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import { getNotifications, markNotificationRead, markAllNotificationsRead, deleteNotification } from '@/lib/api';
import type { Notification } from '@/types/types';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const typeConfig: Record<string, { icon: React.ElementType; color: string }> = {
  appointment: { icon: Calendar, color: 'text-primary bg-primary/10' },
  medicine: { icon: Bell, color: 'text-accent bg-accent/10' },
  report: { icon: FileText, color: 'text-green-600 bg-green-500/10' },
  alert: { icon: Activity, color: 'text-warning bg-warning/10' },
  announcement: { icon: Megaphone, color: 'text-purple-600 bg-purple-500/10' },
};

const NotificationsPage: React.FC = () => {
  const { user: authUser } = useAuth();
  const [notifs, setNotifs] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authUser?.id) return;
    getNotifications(authUser.id).then(setNotifs).finally(() => setLoading(false));
  }, [authUser?.id]);

  const handleMarkAllRead = async () => {
    if (!authUser?.id) return;
    await markAllNotificationsRead(authUser.id);
    setNotifs(prev => prev.map(n => ({ ...n, read: true })));
    toast.success('All notifications marked as read');
  };

  const handleDelete = async (id: string) => {
    await deleteNotification(id);
    setNotifs(prev => prev.filter(n => n.id !== id));
  };

  const handleToggleRead = async (notif: Notification) => {
    if (notif.read) return;
    await markNotificationRead(notif.id);
    setNotifs(prev => prev.map(n => n.id === notif.id ? { ...n, read: true } : n));
  };

  const unreadCount = notifs.filter(n => !n.read).length;

  const renderList = (list: Notification[]) => {
    if (loading) return <div className="space-y-2">{[1,2,3].map(i => <Skeleton key={i} className="h-20 w-full rounded-xl" />)}</div>;
    if (list.length === 0) return (
      <div className="text-center py-12">
        <Bell className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-40" />
        <p className="text-sm text-muted-foreground">No notifications here</p>
      </div>
    );
    return (
      <div className="space-y-2">
        {list.map((notif, i) => {
          const typeConf = typeConfig[notif.type] || typeConfig.announcement;
          const Icon = typeConf.icon;
          return (
            <motion.div key={notif.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
              className={cn('flex items-start gap-3 p-4 rounded-xl border transition-colors cursor-pointer',
                notif.read ? 'border-border bg-transparent' : 'border-primary/20 bg-primary/5')}
              onClick={() => handleToggleRead(notif)}>
              <div className={cn('w-9 h-9 rounded-xl flex items-center justify-center shrink-0', typeConf.color)}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className={cn('text-sm', !notif.read && 'font-semibold')}>{notif.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{notif.message}</p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {!notif.read && <span className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-muted-foreground hover:text-destructive"
                      onClick={e => { e.stopPropagation(); handleDelete(notif.id); }}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground/60 mt-1.5">{new Date(notif.created_at).toLocaleDateString()}</p>
              </div>
            </motion.div>
          );
        })}
      </div>
    );
  };

  return (
    <AppLayout title="Notifications">
      <div className="max-w-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold">All Notifications</h3>
            {unreadCount > 0 && <Badge className="bg-primary text-primary-foreground text-xs">{unreadCount} new</Badge>}
          </div>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={handleMarkAllRead} className="text-primary text-xs">
              <CheckCheck className="w-3.5 h-3.5 mr-1" />Mark all read
            </Button>
          )}
        </div>
        <Tabs defaultValue="all">
          <TabsList>
            <TabsTrigger value="all">All ({notifs.length})</TabsTrigger>
            <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
            <TabsTrigger value="appointment">Appointments</TabsTrigger>
            <TabsTrigger value="medicine">Medicine</TabsTrigger>
          </TabsList>
          <TabsContent value="all" className="mt-4">{renderList(notifs)}</TabsContent>
          <TabsContent value="unread" className="mt-4">{renderList(notifs.filter(n => !n.read))}</TabsContent>
          <TabsContent value="appointment" className="mt-4">{renderList(notifs.filter(n => n.type === 'appointment'))}</TabsContent>
          <TabsContent value="medicine" className="mt-4">{renderList(notifs.filter(n => n.type === 'medicine'))}</TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default NotificationsPage;
