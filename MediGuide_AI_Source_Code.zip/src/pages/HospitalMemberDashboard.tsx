import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Droplet, Plus, Users, Settings, Activity, CheckCircle, AlertTriangle, ArrowRight, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import AppLayout from '@/components/layouts/AppLayout';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

type BloodType = 'A+' | 'A-' | 'B+' | 'B-' | 'O+' | 'O-' | 'AB+' | 'AB-';

interface BloodInventory {
  type: BloodType;
  quantity: number; // in units
  status: 'Adequate' | 'Low Stock' | 'Critical';
}

interface PatientBloodData {
  id: string;
  name: string;
  patientId: string;
  bloodGroup: BloodType | 'Unknown';
  guardianName?: string;
  guardianBloodGroup?: BloodType | 'Unknown';
  lastUpdated: string;
}

const initialInventory: BloodInventory[] = [
  { type: 'A+', quantity: 0, status: 'Critical' },
  { type: 'A-', quantity: 0, status: 'Critical' },
  { type: 'B+', quantity: 0, status: 'Critical' },
  { type: 'B-', quantity: 0, status: 'Critical' },
  { type: 'O+', quantity: 0, status: 'Critical' },
  { type: 'O-', quantity: 0, status: 'Critical' },
  { type: 'AB+', quantity: 0, status: 'Critical' },
  { type: 'AB-', quantity: 0, status: 'Critical' },
];

const initialPatients: PatientBloodData[] = [
  { id: '1', name: 'John Doe', patientId: 'PT-1001', bloodGroup: 'O+', guardianName: 'Jane Doe', guardianBloodGroup: 'O-', lastUpdated: '2026-07-01' },
  { id: '2', name: 'Alice Smith', patientId: 'PT-1002', bloodGroup: 'A-', lastUpdated: '2026-07-02' },
  { id: '3', name: 'Robert Johnson', patientId: 'PT-1003', bloodGroup: 'B+', guardianName: 'Mary Johnson', guardianBloodGroup: 'B+', lastUpdated: '2026-07-03' },
];

const HospitalMemberDashboard: React.FC = () => {
  const [inventory, setInventory] = useState<BloodInventory[]>(initialInventory);
  const [patients, setPatients] = useState<PatientBloodData[]>(initialPatients);
  const [search, setSearch] = useState('');
  
  // Dialog state for inventory
  const [isUpdateInvOpen, setIsUpdateInvOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<BloodType | ''>('');
  const [quantityToAdd, setQuantityToAdd] = useState('');
  
  // Dialog state for patient
  const [isUpdatePatientOpen, setIsUpdatePatientOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<PatientBloodData | null>(null);
  const [editPatientBg, setEditPatientBg] = useState<BloodType | 'Unknown'>('Unknown');
  const [editGuardianName, setEditGuardianName] = useState('');
  const [editGuardianBg, setEditGuardianBg] = useState<BloodType | 'Unknown'>('Unknown');

  const [appointments] = useState([
    { id: '1', patientName: 'John Doe', department: 'General Medicine', date: '2026-07-20 09:30 AM', status: 'confirmed' },
    { id: '2', patientName: 'Alice Smith', department: 'Cardiology', date: '2026-07-20 11:00 AM', status: 'pending' },
    { id: '3', patientName: 'Robert Johnson', department: 'Orthopedics', date: '2026-07-21 10:15 AM', status: 'confirmed' },
    { id: '4', patientName: 'Emily Davis', department: 'Pediatrics', date: '2026-07-21 02:00 PM', status: 'completed' },
  ]);

  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.patientId.toLowerCase().includes(search.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'Adequate': return 'bg-green-500/10 text-green-600 border-green-200';
      case 'Low Stock': return 'bg-warning/10 text-warning border-warning/20';
      case 'Critical': return 'bg-destructive/10 text-destructive border-destructive/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const handleUpdateInventory = () => {
    if (!selectedType || !quantityToAdd) {
      toast.error('Please select blood type and enter quantity.');
      return;
    }
    
    const qty = parseInt(quantityToAdd);
    if (isNaN(qty)) {
      toast.error('Invalid quantity.');
      return;
    }

    setInventory(prev => prev.map(inv => {
      if (inv.type === selectedType) {
        const newQty = Math.max(0, inv.quantity + qty);
        let newStatus: 'Adequate' | 'Low Stock' | 'Critical' = 'Adequate';
        if (newQty < 10) newStatus = 'Critical';
        else if (newQty < 25) newStatus = 'Low Stock';
        return { ...inv, quantity: newQty, status: newStatus };
      }
      return inv;
    }));
    
    toast.success(`Updated ${selectedType} inventory by ${qty} units.`);
    setIsUpdateInvOpen(false);
    setSelectedType('');
    setQuantityToAdd('');
  };

  const openEditPatient = (patient: PatientBloodData) => {
    setSelectedPatient(patient);
    setEditPatientBg(patient.bloodGroup);
    setEditGuardianName(patient.guardianName || '');
    setEditGuardianBg(patient.guardianBloodGroup || 'Unknown');
    setIsUpdatePatientOpen(true);
  };

  const handleUpdatePatient = () => {
    if (!selectedPatient) return;
    
    setPatients(prev => prev.map(p => {
      if (p.id === selectedPatient.id) {
        return {
          ...p,
          bloodGroup: editPatientBg,
          guardianName: editGuardianName || undefined,
          guardianBloodGroup: editGuardianBg,
          lastUpdated: new Date().toISOString().split('T')[0]
        };
      }
      return p;
    }));
    
    toast.success(`Updated blood record for ${selectedPatient.name}.`);
    setIsUpdatePatientOpen(false);
  };

  const totalUnits = inventory.reduce((sum, item) => sum + item.quantity, 0);
  const criticalTypes = inventory.filter(i => i.status === 'Critical').length;

  return (
    <AppLayout title="Hospital Member Dashboard" subtitle="Blood Bank Management">
      <div className="space-y-6 max-w-7xl">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-destructive/10 rounded-xl border border-destructive/20"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-destructive/20 flex items-center justify-center text-destructive">
              <Droplet className="w-7 h-7" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-destructive">Blood Bank Overview</h2>
              <p className="text-sm text-muted-foreground">Manage blood inventory and patient blood groups</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button onClick={() => setIsUpdateInvOpen(true)}>
              <Plus className="w-4 h-4 mr-1.5" /> Update Inventory
            </Button>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                <Activity className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Units Available</p>
                <p className="text-2xl font-bold">{totalUnits}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-destructive/10 flex items-center justify-center text-destructive">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Critical Types</p>
                <p className="text-2xl font-bold text-destructive">{criticalTypes}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center text-accent">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Registered Patients</p>
                <p className="text-2xl font-bold">{patients.length}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="appointments" className="space-y-6">
          <TabsList>
            <TabsTrigger value="appointments"><Activity className="w-4 h-4 mr-2" /> Appointments</TabsTrigger>
            <TabsTrigger value="inventory"><Droplet className="w-4 h-4 mr-2" /> Blood Inventory</TabsTrigger>
            <TabsTrigger value="patients"><Users className="w-4 h-4 mr-2" /> Patient Records</TabsTrigger>
          </TabsList>

          <TabsContent value="appointments" className="space-y-4 m-0">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Hospital Appointments</CardTitle>
                <CardDescription>View all patients who booked an appointment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-3 px-2 font-semibold text-muted-foreground whitespace-nowrap">Patient Name</th>
                        <th className="text-left py-3 px-2 font-semibold text-muted-foreground whitespace-nowrap">Department</th>
                        <th className="text-left py-3 px-2 font-semibold text-muted-foreground whitespace-nowrap">Date & Time</th>
                        <th className="text-left py-3 px-2 font-semibold text-muted-foreground whitespace-nowrap">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {appointments.map(apt => (
                        <tr key={apt.id} className="border-b border-border hover:bg-muted/30">
                          <td className="py-3 px-2 whitespace-nowrap font-medium">{apt.patientName}</td>
                          <td className="py-3 px-2 whitespace-nowrap text-muted-foreground">{apt.department}</td>
                          <td className="py-3 px-2 whitespace-nowrap text-muted-foreground">{apt.date}</td>
                          <td className="py-3 px-2 whitespace-nowrap">
                            <Badge variant="outline" className={cn(
                              apt.status === 'confirmed' ? 'bg-green-500/10 text-green-600 border-green-200' :
                              apt.status === 'pending' ? 'bg-warning/10 text-warning border-warning/20' :
                              'bg-muted text-muted-foreground'
                            )}>
                              {apt.status}
                            </Badge>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inventory" className="space-y-4 m-0">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {inventory.map((inv, i) => (
                <motion.div key={inv.type} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.05 }}>
                  <Card className="h-full">
                    <CardHeader className="pb-2 pt-4 px-4 flex flex-row items-center justify-between">
                      <CardTitle className="text-xl text-destructive flex items-center gap-2">
                        <Droplet className="w-5 h-5" /> {inv.type}
                      </CardTitle>
                      <Badge variant="outline" className={cn(getStatusColor(inv.status))}>
                        {inv.status}
                      </Badge>
                    </CardHeader>
                    <CardContent className="px-4 pb-4">
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-bold">{inv.quantity}</span>
                        <span className="text-sm text-muted-foreground">Units</span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="patients" className="m-0 space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <div>
                  <CardTitle className="text-lg">Patient Blood Records</CardTitle>
                  <CardDescription>Track blood groups for patients and their guardians.</CardDescription>
                </div>
                <div className="w-64">
                  <Input 
                    placeholder="Search by name or ID..." 
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border overflow-hidden">
                  <div className="w-full max-w-full overflow-x-auto">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-muted/50 text-muted-foreground font-medium border-b">
                        <tr>
                          <th className="px-4 py-3 whitespace-nowrap">Patient</th>
                          <th className="px-4 py-3 whitespace-nowrap">Patient BG</th>
                          <th className="px-4 py-3 whitespace-nowrap">Guardian</th>
                          <th className="px-4 py-3 whitespace-nowrap">Guardian BG</th>
                          <th className="px-4 py-3 whitespace-nowrap">Last Updated</th>
                          <th className="px-4 py-3 whitespace-nowrap text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {filteredPatients.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                              No records found.
                            </td>
                          </tr>
                        ) : (
                          filteredPatients.map(p => (
                            <tr key={p.id} className="hover:bg-muted/30 transition-colors">
                              <td className="px-4 py-3 whitespace-nowrap">
                                <p className="font-medium text-foreground">{p.name}</p>
                                <p className="text-xs text-muted-foreground">{p.patientId}</p>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <Badge variant={p.bloodGroup === 'Unknown' ? 'outline' : 'default'} className={p.bloodGroup !== 'Unknown' ? 'bg-destructive hover:bg-destructive/90 text-white' : ''}>
                                  {p.bloodGroup}
                                </Badge>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                {p.guardianName || <span className="text-muted-foreground italic">None</span>}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                {p.guardianName ? (
                                  <Badge variant={p.guardianBloodGroup === 'Unknown' ? 'outline' : 'secondary'} className={p.guardianBloodGroup !== 'Unknown' ? 'border-destructive text-destructive bg-destructive/10' : ''}>
                                    {p.guardianBloodGroup}
                                  </Badge>
                                ) : (
                                  <span className="text-muted-foreground">-</span>
                                )}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">
                                {p.lastUpdated}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-right">
                                <Button variant="ghost" size="sm" onClick={() => openEditPatient(p)}>
                                  Update
                                </Button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Update Inventory Dialog */}
        <Dialog open={isUpdateInvOpen} onOpenChange={setIsUpdateInvOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Update Blood Inventory</DialogTitle>
              <DialogDescription>Add or remove blood units for a specific blood type.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label>Blood Type</Label>
                <Select value={selectedType} onValueChange={(v) => setSelectedType(v as BloodType)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {inventory.map(inv => (
                      <SelectItem key={inv.type} value={inv.type}>{inv.type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quantity Adjustment</Label>
                <Input 
                  type="number" 
                  placeholder="e.g. 5 to add, -2 to remove" 
                  value={quantityToAdd}
                  onChange={(e) => setQuantityToAdd(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">Use negative numbers to remove units.</p>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsUpdateInvOpen(false)}>Cancel</Button>
              <Button onClick={handleUpdateInventory} className="bg-destructive text-white hover:bg-destructive/90">Update</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Update Patient Blood Record Dialog */}
        <Dialog open={isUpdatePatientOpen} onOpenChange={setIsUpdatePatientOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Update Blood Record</DialogTitle>
              <DialogDescription>
                Update blood group for {selectedPatient?.name} and their guardian.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label>Patient Blood Group</Label>
                <Select value={editPatientBg} onValueChange={(v) => setEditPatientBg(v as any)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Unknown">Unknown</SelectItem>
                    {inventory.map(inv => (
                      <SelectItem key={`p-${inv.type}`} value={inv.type}>{inv.type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="pt-4 border-t space-y-4">
                <h4 className="font-medium text-sm flex items-center gap-2">
                  <Shield className="w-4 h-4 text-muted-foreground" /> Guardian Information
                </h4>
                <div className="space-y-2">
                  <Label>Guardian Name</Label>
                  <Input 
                    placeholder="Enter guardian name (optional)" 
                    value={editGuardianName}
                    onChange={(e) => setEditGuardianName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Guardian Blood Group</Label>
                  <Select value={editGuardianBg} onValueChange={(v) => setEditGuardianBg(v as any)}>
                    <SelectTrigger disabled={!editGuardianName}>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Unknown">Unknown</SelectItem>
                      {inventory.map(inv => (
                        <SelectItem key={`g-${inv.type}`} value={inv.type}>{inv.type}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsUpdatePatientOpen(false)}>Cancel</Button>
              <Button onClick={handleUpdatePatient}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
};

export default HospitalMemberDashboard;