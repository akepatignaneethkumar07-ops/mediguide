import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Salad, Apple, Dumbbell, Moon, Brain, ChevronDown, ChevronUp,
  Sparkles, RefreshCw, CheckCircle, AlertTriangle, Heart,
  Coffee, Utensils, Sun,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import AppLayout from '@/components/layouts/AppLayout';
import { cn } from '@/lib/utils';

const CONDITIONS = [
  'Diabetes (Type 2)',
  'Hypertension (High Blood Pressure)',
  'Obesity / Weight Management',
  'Heart Disease',
  'High Cholesterol',
  'Kidney Disease (CKD)',
  'Thyroid Disorders',
  'PCOS / PCOD',
  'Anemia',
  'Acid Reflux / GERD',
  'Arthritis',
  'Asthma',
  'Other',
];

interface DayMeal { breakfast: string; lunch: string; dinner: string; snacks: string }
interface DietPlan {
  condition: string;
  summary: string;
  weeklyMeals: Record<string, DayMeal>;
  avoidFoods: { food: string; reason: string }[];
  lifestyleTips: { category: string; tips: string[] }[];
  treatmentNotes: string;
}

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

// Template plans by condition keyword
const getPlan = (condition: string, notes: string): DietPlan => {
  const isDiabetes   = condition.toLowerCase().includes('diabet');
  const isHypert     = condition.toLowerCase().includes('hypert') || condition.toLowerCase().includes('blood pressure');
  const isObesity    = condition.toLowerCase().includes('obes') || condition.toLowerCase().includes('weight');
  const isHeart      = condition.toLowerCase().includes('heart');

  const base: DayMeal = {
    breakfast: isDiabetes   ? 'Vegetable oats upma + low-fat milk (no sugar)'
               : isHypert   ? 'Idli (2) + sambar + coconut chutney'
               : isObesity  ? 'Moong dal cheela + green tea'
               : isHeart    ? 'Oatmeal with berries + walnuts'
               : 'Whole grain toast + boiled egg + fruit',
    lunch:    isDiabetes    ? 'Brown rice (½ cup) + dal + salad + curd'
               : isHypert   ? 'Jowar roti + vegetable curry (low salt) + buttermilk'
               : isObesity  ? 'Salad bowl + grilled paneer + dal'
               : isHeart    ? 'Quinoa + steamed vegetables + fish curry'
               : 'Rice + dal + sabzi + salad',
    dinner:   isDiabetes    ? 'Multigrain roti + methi sabzi + dal'
               : isHypert   ? 'Brown rice + moong dal + steamed vegetables'
               : isObesity  ? 'Vegetable soup + 2 rotis + dal'
               : isHeart    ? 'Grilled fish + vegetables + whole wheat roti'
               : 'Roti + sabzi + dal',
    snacks:   isDiabetes    ? 'Handful of almonds; cucumber slices'
               : isHypert   ? 'Unsalted nuts; seasonal fruit'
               : isObesity  ? 'Green tea; small portion of roasted chana'
               : isHeart    ? 'Walnuts + apple slices'
               : 'Fruits; yoghurt',
  };

  const weeklyMeals: Record<string, DayMeal> = {};
  const variations = [
    { breakfast: 'Poha + green tea', lunch: 'Wheat dosa + sambar', dinner: 'Palak roti + paneer bhurji', snacks: 'Apple; buttermilk' },
    { breakfast: 'Moong sprouts chaat', lunch: 'Bajra roti + kadhi', dinner: 'Vegetable khichdi', snacks: 'Pear; green tea' },
    { breakfast: 'Besan chilla + curd', lunch: 'Rice + rajma + salad', dinner: 'Soup + 2 rotis', snacks: 'Pomegranate seeds' },
    { breakfast: 'Methi paratha (no butter) + curd', lunch: 'Jeera rice + dal + sabzi', dinner: 'Quinoa pulao', snacks: 'Handful walnuts' },
    { breakfast: 'Oats porridge + banana', lunch: 'Brown rice + fish curry + salad', dinner: 'Roti + lauki sabzi', snacks: 'Coconut water; almonds' },
  ];

  DAYS.forEach((day, i) => {
    weeklyMeals[day] = i === 0 ? base : (variations[(i - 1) % variations.length]);
  });

  const avoidFoods = isDiabetes ? [
    { food: 'White rice & refined flour (maida)', reason: 'Causes rapid blood sugar spikes' },
    { food: 'Sugary drinks & juices', reason: 'High glycemic index raises glucose levels fast' },
    { food: 'Fried snacks (samosa, puri)', reason: 'High fat + carbs worsen insulin resistance' },
    { food: 'Full-fat dairy & processed meats', reason: 'Increases cardiovascular risk in diabetics' },
    { food: 'Alcohol & sweetened desserts', reason: 'Directly elevates blood sugar' },
  ] : isHypert ? [
    { food: 'Excess table salt & pickles', reason: 'Sodium raises blood pressure directly' },
    { food: 'Processed & packaged foods', reason: 'Hidden sodium in large quantities' },
    { food: 'Red meat & organ meats', reason: 'Saturated fat increases arterial stiffness' },
    { food: 'Alcohol & caffeinated drinks', reason: 'Cause acute blood pressure spikes' },
    { food: 'Full-fat dairy products', reason: 'Contributes to cholesterol buildup' },
  ] : isObesity ? [
    { food: 'Sugary beverages & energy drinks', reason: 'Empty calories, high sugar content' },
    { food: 'Deep-fried foods', reason: 'Calorie-dense with no nutritional value' },
    { food: 'White bread & refined grains', reason: 'Cause rapid insulin spikes leading to fat storage' },
    { food: 'Fast food & processed snacks', reason: 'High in trans fats and hidden sugars' },
    { food: 'Alcohol', reason: 'High in calories, disrupts metabolism' },
  ] : [
    { food: 'Processed / packaged foods', reason: 'High sodium, trans fats and preservatives' },
    { food: 'Saturated fats & red meat', reason: 'Increases LDL cholesterol' },
    { food: 'Refined sugar & sweets', reason: 'Promotes inflammation' },
    { food: 'Alcohol & smoking', reason: 'Damages heart and blood vessels' },
    { food: 'Excess salt', reason: 'Retains fluid and increases blood pressure' },
  ];

  const lifestyleTips = [
    {
      category: 'Exercise',
      tips: isDiabetes
        ? ['30 min brisk walk daily', 'Resistance training 3×/week reduces insulin resistance', 'Post-meal 10 min walk controls glucose spikes', 'Avoid long sitting — move every hour']
        : ['30–45 min moderate aerobic exercise 5 days/week', 'Include strength training twice a week', 'Morning stretches and yoga for flexibility', 'Take stairs instead of lift'],
    },
    {
      category: 'Sleep',
      tips: ['Sleep 7–8 hours per night', 'Maintain a consistent bedtime and wake-up time', 'Avoid screens 1 hour before bed', 'Keep bedroom cool and dark'],
    },
    {
      category: 'Stress Management',
      tips: ['Practice deep breathing or meditation 10 min/day', 'Pursue a hobby to unwind', 'Connect socially — isolation worsens chronic illness', 'Journalling reduces cortisol (stress hormone)'],
    },
    {
      category: 'Hydration',
      tips: ['Drink 8–10 glasses of water daily', 'Start the day with warm water + lemon', 'Avoid sugary and carbonated drinks', 'Coconut water is a healthy electrolyte source'],
    },
  ];

  const treatmentNotes = isDiabetes
    ? 'Monitor fasting blood glucose daily. Target HbA1c < 7%. Eat meals at regular intervals — do not skip breakfast. Portion control is more important than food elimination.'
    : isHypert
    ? 'Restrict sodium to < 2.3 g/day. Follow the DASH diet pattern. Check BP twice weekly. Reduce stress — it directly elevates blood pressure. Medication timing is important; do not miss doses.'
    : isObesity
    ? 'Aim for a 500–700 kcal deficit per day for safe weight loss of 0.5 kg/week. Track meals using a journal. Emotional eating triggers — identify and address them. Consult a dietitian for a personalized calorie goal.'
    : 'Maintain a heart-healthy diet rich in fiber, omega-3 fatty acids, and antioxidants. Regular medical check-ups every 3 months. Take prescribed medications as directed. Report any new symptoms to your doctor immediately.';

  return { condition, summary: `Personalised plan for: ${condition}${notes ? ` — ${notes.slice(0, 60)}` : ''}`, weeklyMeals, avoidFoods, lifestyleTips, treatmentNotes };
};

const DietAgentPage: React.FC = () => {
  const [condition, setCondition] = useState('');
  const [customCondition, setCustomCondition] = useState('');
  const [notes, setNotes] = useState('');
  const [plan, setPlan] = useState<DietPlan | null>(null);
  const [generating, setGenerating] = useState(false);
  const [selectedDay, setSelectedDay] = useState('Monday');
  const [expandedTip, setExpandedTip] = useState<number | null>(0);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    const finalCondition = condition === 'Other' ? customCondition : condition;
    if (!finalCondition) return;
    setGenerating(true);
    await new Promise(r => setTimeout(r, 1800)); // simulate AI thinking
    setPlan(getPlan(finalCondition, notes));
    setGenerating(false);
  };

  const mealIcons = { breakfast: Sun, lunch: Utensils, dinner: Moon, snacks: Coffee };

  return (
    <AppLayout title="Diet & Health Agent" subtitle="AI-powered personal wellness plan">
      <div className="space-y-6 max-w-4xl">

        {/* Input card */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" /> Tell us your health condition
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleGenerate} className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Health Condition</Label>
                  <Select value={condition} onValueChange={setCondition}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your condition" />
                    </SelectTrigger>
                    <SelectContent>
                      {CONDITIONS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {condition === 'Other' && (
                  <div className="space-y-1.5">
                    <Label htmlFor="custom">Describe your condition</Label>
                    <input
                      id="custom"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      placeholder="e.g. Post-surgery recovery"
                      value={customCondition}
                      onChange={e => setCustomCondition(e.target.value)}
                    />
                  </div>
                )}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="health-notes">Additional notes <span className="text-muted-foreground font-normal">(optional)</span></Label>
                <Textarea
                  id="health-notes"
                  placeholder="e.g. vegetarian, no onion/garlic, allergic to nuts, age 55…"
                  rows={2}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                />
              </div>
              <Button type="submit" disabled={generating || (!condition) || (condition === 'Other' && !customCondition)}>
                {generating ? (
                  <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Generating plan…</>
                ) : (
                  <><Sparkles className="w-4 h-4 mr-2" />Generate My Health Plan</>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Generated plan */}
        <AnimatePresence>
          {plan && (
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              {/* Summary banner */}
              <div className="rounded-xl bg-primary/6 border border-primary/20 p-4 flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Heart className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{plan.condition}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{plan.treatmentNotes}</p>
                </div>
              </div>

              {/* Weekly Meal Plan */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Salad className="w-4 h-4 text-green-600" /> Weekly Meal Plan
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {/* Day selector */}
                  <div className="flex gap-1.5 flex-wrap mb-4">
                    {DAYS.map(d => (
                      <button
                        key={d}
                        onClick={() => setSelectedDay(d)}
                        className={cn(
                          'text-xs font-medium px-3 py-1.5 rounded-full border transition-colors',
                          selectedDay === d
                            ? 'bg-primary text-primary-foreground border-primary'
                            : 'border-border hover:bg-muted'
                        )}
                      >
                        {d.slice(0, 3)}
                      </button>
                    ))}
                  </div>
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={selectedDay}
                      initial={{ opacity: 0, x: 8 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -8 }}
                      transition={{ duration: 0.15 }}
                      className="grid md:grid-cols-2 gap-3"
                    >
                      {Object.entries(plan.weeklyMeals[selectedDay] || {}).map(([meal, text]) => {
                        const Icon = mealIcons[meal as keyof typeof mealIcons] || Utensils;
                        return (
                          <div key={meal} className="p-3 rounded-xl border border-border bg-muted/20">
                            <div className="flex items-center gap-2 mb-1.5">
                              <Icon className="w-4 h-4 text-primary" />
                              <span className="text-xs font-semibold capitalize text-muted-foreground">{meal}</span>
                            </div>
                            <p className="text-sm leading-relaxed">{text}</p>
                          </div>
                        );
                      })}
                    </motion.div>
                  </AnimatePresence>
                </CardContent>
              </Card>

              {/* Foods to Avoid */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-destructive" /> Foods to Avoid
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {plan.avoidFoods.map((f, i) => (
                      <motion.div
                        key={f.food}
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.07 }}
                        className="flex items-start gap-3 p-3 rounded-xl border border-destructive/10 bg-destructive/4"
                      >
                        <div className="w-5 h-5 rounded-full bg-destructive/10 flex items-center justify-center shrink-0 mt-0.5">
                          <span className="text-destructive text-[10px] font-bold">✕</span>
                        </div>
                        <div>
                          <p className="text-sm font-medium">{f.food}</p>
                          <p className="text-xs text-muted-foreground mt-0.5">{f.reason}</p>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Lifestyle Tips */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Dumbbell className="w-4 h-4 text-accent" /> Lifestyle Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {plan.lifestyleTips.map((section, i) => {
                    const icons: Record<string, React.ElementType> = { Exercise: Dumbbell, Sleep: Moon, 'Stress Management': Brain, Hydration: Apple };
                    const Icon = icons[section.category] || CheckCircle;
                    return (
                      <div key={section.category} className="border border-border rounded-xl overflow-hidden">
                        <button
                          className="w-full flex items-center justify-between p-3 hover:bg-muted/30 transition-colors text-left"
                          onClick={() => setExpandedTip(expandedTip === i ? null : i)}
                        >
                          <div className="flex items-center gap-2.5">
                            <Icon className="w-4 h-4 text-accent shrink-0" />
                            <span className="text-sm font-semibold">{section.category}</span>
                            <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{section.tips.length} tips</Badge>
                          </div>
                          {expandedTip === i ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                        </button>
                        <AnimatePresence>
                          {expandedTip === i && (
                            <motion.div
                              initial={{ height: 0 }}
                              animate={{ height: 'auto' }}
                              exit={{ height: 0 }}
                              className="overflow-hidden"
                            >
                              <ul className="px-5 py-3 space-y-1.5 border-t border-border bg-muted/10">
                                {section.tips.map((tip, j) => (
                                  <li key={j} className="flex items-start gap-2 text-sm text-muted-foreground">
                                    <CheckCircle className="w-3.5 h-3.5 text-green-500 shrink-0 mt-0.5" />
                                    {tip}
                                  </li>
                                ))}
                              </ul>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              {/* Reset */}
              <div className="flex justify-center pb-2">
                <Button variant="outline" size="sm" onClick={() => { setPlan(null); setCondition(''); setNotes(''); setCustomCondition(''); }}>
                  <RefreshCw className="w-3.5 h-3.5 mr-1.5" />Generate a New Plan
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </AppLayout>
  );
};

export default DietAgentPage;
