import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  Calendar, Bot, Mic, Stethoscope, FileText, Bell,
  Clock, TrendingUp, Heart, Activity, ArrowRight, Plus,
  AlertTriangle, Salad, MapPin,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import AppLayout from '@/components/layouts/AppLayout';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { getUpcomingAppointments, getNotifications } from '@/lib/api';
import type { Appointment, Notification } from '@/types/types';
import { cn } from '@/lib/utils';

const quickActions = [
  { icon: Calendar,      label: 'Book Appointment',  path: '/appointments', color: 'primary' },
  { icon: Bot,           label: 'AI Chat',           path: '/chat',         color: 'accent' },
  { icon: FileText,      label: 'Report Maker',      path: '/report-maker', color: 'primary' },
  { icon: Stethoscope,   label: 'Find Doctor',       path: '/doctors',      color: 'accent' },
  { icon: FileText,      label: 'Medical Reports',   path: '/reports',      color: 'primary' },
  { icon: Bell,          label: 'Medicine Reminder', path: '/reminders',    color: 'accent' },
  { icon: AlertTriangle, label: 'Emergency SOS',     path: '/emergency',    color: 'primary' },
  { icon: FileText,      label: 'Pill Scanner',      path: '/pill-scanner', color: 'accent' },
  { icon: Salad,         label: 'Diet & Health',     path: '/diet',         color: 'primary' },
  { icon: MapPin,        label: 'Hospital Locations',path: '/hospital-map', color: 'accent' },
];

const healthStats = [
  { label: 'Heart Rate', value: '72', unit: 'bpm', icon: Heart, trend: '+2%', good: true },
  { label: 'Blood Pressure', value: '120/80', unit: 'mmHg', icon: Activity, trend: 'Normal', good: true },
  { label: 'BMI', value: '22.4', unit: 'kg/m²', icon: TrendingUp, trend: 'Healthy', good: true },
  { label: 'Next Checkup', value: '7', unit: 'days', icon: Clock, trend: 'Upcoming', good: false },
];

const statusColors: Record<string, string> = {
  confirmed: 'bg-green-500/10 text-green-600 border-green-200',
  pending: 'bg-warning/10 text-warning border-warning/20',
  cancelled: 'bg-destructive/10 text-destructive border-destructive/20',
  'in-progress': 'bg-primary/10 text-primary border-primary/20',
  completed: 'bg-muted text-muted-foreground border-border',
};

const PatientDashboard: React.FC = () => {
  const { user } = useApp();
  const { user: authUser } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [notifs, setNotifs] = useState<Notification[]>([]);
  const [loadingAppts, setLoadingAppts] = useState(true);
  const [loadingNotifs, setLoadingNotifs] = useState(true);

  useEffect(() => {
    if (!authUser?.id) return;
    getUpcomingAppointments(authUser.id)
      .then(setAppointments)
      .finally(() => setLoadingAppts(false));
    getNotifications(authUser.id)
      .then(setNotifs)
      .finally(() => setLoadingNotifs(false));
  }, [authUser?.id]);

  const unreadNotifs = notifs.filter(n => !n.read);

  return (
    <AppLayout title="Patient Dashboard">
      <div className="space-y-6 max-w-7xl">
        {/* Welcome */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-primary rounded-xl text-primary-foreground"
        >
          <div className="flex items-center gap-4">
            <img
              src={user?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || 'User')}&background=2563EB&color=fff`}
              alt={user?.name}
              className="w-14 h-14 rounded-full object-cover border-2 border-white/30"
            />
            <div>
              <p className="text-sm text-primary-foreground/70">Welcome back,</p>
              <h2 className="text-xl font-bold">{user?.name || 'Patient'}</h2>
              <p className="text-sm text-primary-foreground/70">How are you feeling today?</p>
            </div>
          </div>
          <Button asChild variant="secondary" size="sm">
            <Link to="/appointments"><Plus className="w-4 h-4 mr-1.5" /> Book Appointment</Link>
          </Button>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Quick Actions</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {quickActions.map((action, i) => {
                    const Icon = action.icon;
                    return (
                      <motion.div key={action.label} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.06 }}>
                        <Link to={action.path} className={cn('flex flex-col items-center gap-2 p-4 rounded-xl border border-border hover:border-primary/30 hover:shadow-hover transition-all group text-center')}>
                          <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center transition-colors', action.color === 'primary' ? 'bg-primary/10 group-hover:bg-primary/20' : 'bg-accent/10 group-hover:bg-accent/20')}>
                            <Icon className={cn('w-5 h-5', action.color === 'primary' ? 'text-primary' : 'text-accent')} />
                          </div>
                          <span className="text-xs font-medium leading-tight">{action.label}</span>
                        </Link>
                      </motion.div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Appointments */}
            <Card>
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-base">Upcoming Appointments</CardTitle>
                <Button asChild variant="ghost" size="sm" className="text-primary h-auto p-0">
                  <Link to="/appointments">View all <ArrowRight className="w-3.5 h-3.5 ml-1" /></Link>
                </Button>
              </CardHeader>
              <CardContent className="space-y-3">
                {loadingAppts ? (
                  [1,2,3].map(i => (
                    <div key={i} className="flex items-center gap-3 p-3">
                      <Skeleton className="w-10 h-10 rounded-full" />
                      <div className="flex-1 space-y-2"><Skeleton className="h-3 w-3/4" /><Skeleton className="h-3 w-1/2" /></div>
                    </div>
                  ))
                ) : appointments.length === 0 ? (
                  <div className="text-center py-8">
                    <Calendar className="w-8 h-8 text-muted-foreground mx-auto mb-2 opacity-40" />
                    <p className="text-sm text-muted-foreground">No upcoming appointments</p>
                    <Button asChild size="sm" className="mt-3"><Link to="/appointments">Book Now</Link></Button>
                  </div>
                ) : appointments.map((appt) => (
                  <div key={appt.id} className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-muted/30 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <Stethoscope className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{appt.doctor_name}</p>
                      <p className="text-xs text-muted-foreground">{appt.department} · {appt.type}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-medium">{appt.date}</p>
                      <p className="text-xs text-muted-foreground">{appt.time}</p>
                    </div>
                    <Badge className={cn('text-xs ml-2 shrink-0', statusColors[appt.status])}>{appt.status}</Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Notifications Panel */}
          <div className="space-y-4">
            <Card className="h-fit">
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-base">Notifications</CardTitle>
                <Badge className="bg-accent text-accent-foreground text-xs">{unreadNotifs.length} new</Badge>
              </CardHeader>
              <CardContent className="space-y-3">
                {loadingNotifs ? (
                  [1,2,3].map(i => <Skeleton key={i} className="h-16 w-full rounded-lg" />)
                ) : notifs.length === 0 ? (
                  <div className="text-center py-6">
                    <Bell className="w-7 h-7 text-muted-foreground mx-auto mb-2 opacity-40" />
                    <p className="text-xs text-muted-foreground">No notifications yet</p>
                  </div>
                ) : notifs.slice(0, 5).map((notif) => (
                  <div key={notif.id} className={cn('p-3 rounded-lg border transition-colors', notif.read ? 'border-border' : 'border-primary/20 bg-primary/5')}>
                    <div className="flex items-start gap-2">
                      {!notif.read && <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />}
                      <div className="min-w-0">
                        <p className="text-xs font-semibold mb-0.5">{notif.title}</p>
                        <p className="text-xs text-muted-foreground leading-snug">{notif.message}</p>
                        <p className="text-xs text-muted-foreground/60 mt-1">{new Date(notif.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                  </div>
                ))}
                <Button asChild variant="ghost" size="sm" className="w-full text-primary">
                  <Link to="/notifications">View all notifications</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Health Summary */}
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Health Summary</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {[
                  { label: 'Appointments this month', value: appointments.length, pct: Math.min(appointments.length * 20, 100), color: 'bg-primary' },
                  { label: 'Medication adherence', value: '92%', pct: 92, color: 'bg-green-500' },
                ].map(s => (
                  <div key={s.label} className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">{s.label}</span>
                      <span className="font-semibold">{s.value}</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-1.5">
                      <div className={cn('h-1.5 rounded-full', s.color)} style={{ width: `${s.pct}%` }} />
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default PatientDashboard;
