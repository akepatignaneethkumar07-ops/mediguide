import React, { useState, useRef } from 'react';
import { Upload, AlertCircle, Info, FileText, CheckCircle2, Scan } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import AppLayout from '@/components/layouts/AppLayout';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { motion, AnimatePresence } from 'motion/react';

const PillScannerPage: React.FC = () => {
  const { user } = useAuth();
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<any | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const simulateUploadScan = () => {
    setIsScanning(true);
    setScanResult(null);
    setTimeout(() => {
      setScanResult({
        name: 'Amoxicillin 500mg',
        type: 'Antibiotic',
        uses: 'Used to treat bacterial infections, such as pneumonia, bronchitis, and infections of the ear, nose, throat, urinary tract, and skin.',
        dosage: "Typical adult dose is 500 mg every 8 hours or 875 mg every 12 hours. Please follow your doctor's prescription exactly.",
        sideEffects: [
          'Nausea, vomiting, or diarrhea',
          'Skin rash',
          'Vaginal itching or discharge'
        ],
        warnings: 'Do not take if you are allergic to penicillin. Finish the entire prescribed course even if symptoms improve.',
      });
      setIsScanning(false);
    }, 2500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const objectUrl = URL.createObjectURL(file);
    setSelectedImage(objectUrl);
    setScanResult(null); // Clear previous results when new image is uploaded
  };

  const handleReset = () => {
    setSelectedImage(null);
    setScanResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <AppLayout title="Pill & Tablet Scanner">
      <div className="max-w-4xl space-y-6">
        <Card className="border-primary/20 shadow-sm overflow-hidden">
          <div className="bg-primary/5 p-6 border-b border-border text-center space-y-2">
            <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
              <Scan className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-xl font-semibold text-primary">Scan Your Medication</h2>
            <p className="text-sm text-muted-foreground max-w-lg mx-auto">
              Use your camera to scan a pill or upload a photo of the tablet packaging to instantly view dosage instructions, uses, and side effects.
            </p>
          </div>
          <CardContent className="p-6">
            <div className="flex flex-col items-center gap-4">
              {!selectedImage ? (
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="w-full max-w-sm h-32 flex flex-col items-center justify-center gap-3 border-dashed border-2"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isScanning}
                >
                  <Upload className="w-8 h-8 text-muted-foreground" />
                  <div className="space-y-1">
                    <p className="font-medium">Upload Photo</p>
                    <p className="text-xs text-muted-foreground font-normal">Click to browse your files</p>
                  </div>
                </Button>
              ) : (
                <div className="w-full max-w-sm space-y-4">
                  <div className="relative aspect-square rounded-xl overflow-hidden border border-border bg-muted/30">
                    <img 
                      src={selectedImage} 
                      alt="Pill to analyze" 
                      className="w-full h-full object-contain"
                    />
                    {!isScanning && !scanResult && (
                      <div className="absolute inset-0 bg-background/50 flex flex-col items-center justify-center gap-3 opacity-0 hover:opacity-100 transition-opacity">
                        <Button variant="secondary" size="sm" onClick={() => fileInputRef.current?.click()}>
                          Change Image
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  {!scanResult && (
                    <div className="flex gap-3">
                      <Button 
                        variant="outline" 
                        className="flex-1" 
                        onClick={handleReset}
                        disabled={isScanning}
                      >
                        Cancel
                      </Button>
                      <Button 
                        className="flex-1" 
                        onClick={simulateUploadScan}
                        disabled={isScanning}
                      >
                        {isScanning ? 'Analyzing...' : 'Analyze Pill'}
                      </Button>
                    </div>
                  )}
                </div>
              )}
              
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*"
                onChange={handleFileUpload}
              />
            </div>
          </CardContent>
        </Card>

        {isScanning && (
          <Card>
            <CardContent className="p-8 text-center space-y-4">
              <div className="relative w-24 h-24 mx-auto">
                <div className="absolute inset-0 border-4 border-primary/20 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"></div>
                <Scan className="absolute inset-0 m-auto w-8 h-8 text-primary animate-pulse" />
              </div>
              <p className="text-lg font-medium text-primary">Analyzing medication image...</p>
              <p className="text-sm text-muted-foreground">Identifying shape, color, and imprints</p>
            </CardContent>
          </Card>
        )}

        <AnimatePresence>
          {scanResult && !isScanning && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Card className="border-green-500/20 overflow-hidden">
                <div className="bg-green-500/5 px-6 py-4 flex items-center justify-between border-b border-border">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-600" />
                    <div>
                      <h3 className="font-semibold text-lg">{scanResult.name}</h3>
                      <p className="text-sm text-muted-foreground">{scanResult.type}</p>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6 space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <h4 className="flex items-center gap-2 font-medium mb-2 text-primary">
                          <Info className="w-4 h-4" /> Primary Uses
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {scanResult.uses}
                        </p>
                      </div>
                      <div>
                        <h4 className="flex items-center gap-2 font-medium mb-2 text-primary">
                          <FileText className="w-4 h-4" /> Standard Dosage
                        </h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {scanResult.dosage}
                        </p>
                      </div>
                    </div>
                    <div className="space-y-4 bg-muted/30 p-4 rounded-xl">
                      <div>
                        <h4 className="flex items-center gap-2 font-medium mb-2 text-destructive">
                          <AlertCircle className="w-4 h-4" /> Potential Side Effects
                        </h4>
                        <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside pl-1">
                          {scanResult.sideEffects.map((se: string, i: number) => (
                            <li key={i}>{se}</li>
                          ))}
                        </ul>
                      </div>
                      <div className="pt-2 border-t border-border">
                        <p className="text-xs font-medium text-warning flex items-start gap-1.5 mt-2">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                          <span>{scanResult.warnings}</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Alert className="mt-6 bg-primary/5 text-primary border-primary/20">
                <AlertCircle className="w-4 h-4" />
                <AlertDescription className="text-xs ml-2">
                  <strong>Disclaimer:</strong> This digital prescription guide provides reference information only. It does not replace professional medical advice. Always consult your doctor or pharmacist regarding your medication.
                </AlertDescription>
              </Alert>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </AppLayout>
  );
};

export default PillScannerPage;
