import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Paperclip, Bot, User, AlertCircle, X, Sparkles, Globe, ChevronDown, Check, Volume2, VolumeX, Loader2, Mic, MicOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import { getChatMessages, saveChatMessage } from '@/lib/api';
import { supabase } from '@/db/supabase';
import type { ChatMessage } from '@/types/types';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface LocalMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  lang: string;
}

// ── Language config ────────────────────────────────────────────────────────────
interface LangConfig {
  code: string;
  label: string;
  flag: string;
  nativeLabel: string;
  placeholder: string;
  disclaimer: string;
  typingLabel: string;
  suggestedLabel: string;
  prompts: string[];
  responses: { appointment: string; doctor: string; default: string };
}

const LANGUAGES: LangConfig[] = [
  {
    code: 'en', label: 'English', flag: '🇬🇧', nativeLabel: 'English',
    placeholder: 'Ask me anything about your health, reports, appointments…',
    disclaimer: 'AI responses are for informational purposes only and are not a substitute for professional medical advice.',
    typingLabel: 'MediGuide AI is typing…',
    suggestedLabel: 'Suggested prompts',
    prompts: ['Explain my CBC report', 'Find a cardiologist', 'Book an appointment', 'Common cold symptoms', 'Normal blood pressure?', 'Diet tips for diabetes'],
    responses: {
      appointment: "I'd be happy to help you book an appointment!\n\n1. **Click 'Book Appointment'** in your dashboard\n2. **Browse our Doctor Directory** to find a specialist\n3. **Tell me your symptoms** and I'll recommend the right department\n\nWhich would you prefer?",
      doctor: "I can help you find the right doctor! Please tell me:\n- What symptoms are you experiencing?\n- Which department are you looking for?\n\nWe have 200+ verified specialists available across all major departments.",
      default: "I understand your concern. Based on general medical knowledge, I can provide some information. However, please remember this is for informational purposes only and doesn't replace professional medical advice.\n\nFor accurate diagnosis and treatment, I strongly recommend consulting with one of our qualified specialists. Would you like me to help you book an appointment?",
    },
  },
  {
    code: 'hi', label: 'Hindi', flag: '🇮🇳', nativeLabel: 'हिंदी',
    placeholder: 'अपने स्वास्थ्य, रिपोर्ट या अपॉइंटमेंट के बारे में कुछ भी पूछें…',
    disclaimer: 'AI उत्तर केवल सूचनात्मक उद्देश्यों के लिए हैं और ये पेशेवर चिकित्सा सलाह का विकल्प नहीं हैं।',
    typingLabel: 'MediGuide AI टाइप कर रहा है…',
    suggestedLabel: 'सुझाए गए प्रश्न',
    prompts: ['मेरी CBC रिपोर्ट समझाएं', 'हृदय रोग विशेषज्ञ खोजें', 'अपॉइंटमेंट बुक करें', 'सर्दी-जुकाम के लक्षण', 'सामान्य रक्तचाप क्या है?', 'मधुमेह के लिए आहार सुझाव'],
    responses: {
      appointment: "मैं आपकी अपॉइंटमेंट बुक करने में मदद करूंगा!\n\n1. **'अपॉइंटमेंट बुक करें'** पर क्लिक करें\n2. **डॉक्टर डायरेक्टरी** में विशेषज्ञ खोजें\n3. **अपने लक्षण बताएं** और मैं सही विभाग बताऊंगा\n\nआप क्या चाहेंगे?",
      doctor: "मैं आपके लिए सही डॉक्टर खोज सकता हूं! कृपया बताएं:\n- आप क्या लक्षण अनुभव कर रहे हैं?\n- आप किस विभाग की तलाश कर रहे हैं?\n\nहमारे पास 200+ सत्यापित विशेषज्ञ उपलब्ध हैं।",
      default: "मैं आपकी चिंता समझता हूं। सामान्य चिकित्सा ज्ञान के आधार पर कुछ जानकारी दे सकता हूं। लेकिन कृपया याद रखें यह केवल सूचनात्मक है।\n\nसटीक निदान के लिए हमारे विशेषज्ञ से परामर्श लें। क्या मैं आपके लिए अपॉइंटमेंट बुक करूं?",
    },
  },
  {
    code: 'te', label: 'Telugu', flag: '🇮🇳', nativeLabel: 'తెలుగు',
    placeholder: 'మీ ఆరోగ్యం, నివేదికలు లేదా అపాయింట్‌మెంట్ గురించి అడగండి…',
    disclaimer: 'AI సమాధానాలు కేవలం సమాచార అవసరాల కోసం మాత్రమే, ఇవి వైద్య సలహాకు ప్రత్యామ్నాయం కాదు.',
    typingLabel: 'MediGuide AI టైప్ చేస్తోంది…',
    suggestedLabel: 'సూచించిన ప్రశ్నలు',
    prompts: ['నా CBC నివేదిక వివరించండి', 'హృదయ వైద్యుడిని కనుగొనండి', 'అపాయింట్‌మెంట్ బుక్ చేయండి', 'జలుబు లక్షణాలు', 'సాధారణ రక్తపోటు ఏమిటి?', 'మధుమేహానికి ఆహార చిట్కాలు'],
    responses: {
      appointment: "అపాయింట్‌మెంట్ బుక్ చేయడానికి సహాయం చేయడానికి సంతోషంగా ఉన్నాను!\n\n1. **'అపాయింట్‌మెంట్ బుక్ చేయండి'** క్లిక్ చేయండి\n2. **డాక్టర్ డైరెక్టరీ** లో నిపుణులను వెతకండి\n3. **మీ లక్షణాలు చెప్పండి** అప్పుడు సరైన విభాగం సూచిస్తాను\n\nమీకు ఏది కావాలి?",
      doctor: "మీకు సరైన డాక్టర్ వెతకడంలో సహాయపడగలను!\n- మీరు ఏ లక్షణాలు అనుభవిస్తున్నారు?\n- మీరు ఏ విభాగం కోసం చూస్తున్నారు?\n\nమా దగ్గర 200+ ధృవీకరించబడిన నిపుణులు అందుబాటులో ఉన్నారు.",
      default: "మీ ఆందోళన అర్థమవుతోంది. సాధారణ వైద్య జ్ఞానం ఆధారంగా కొంత సమాచారం ఇవ్వగలను. అయితే ఇది కేవలం సమాచారం మాత్రమే.\n\nసరైన రోగ నిర్ధారణ కోసం మా నిపుణులను సంప్రదించండి. నేను అపాయింట్‌మెంట్ బుక్ చేయనా?",
    },
  },
  {
    code: 'ta', label: 'Tamil', flag: '🇮🇳', nativeLabel: 'தமிழ்',
    placeholder: 'உங்கள் உடல்நலம், அறிக்கைகள் அல்லது சந்திப்பு பற்றி கேளுங்கள்…',
    disclaimer: 'AI பதில்கள் தகவல் நோக்கங்களுக்காக மட்டுமே, இவை மருத்துவ ஆலோசனைக்கு மாற்றாகா.',
    typingLabel: 'MediGuide AI தட்டச்சு செய்கிறது…',
    suggestedLabel: 'பரிந்துரைக்கப்பட்ட கேள்விகள்',
    prompts: ['என் CBC அறிக்கை விளக்கவும்', 'இதய மருத்துவர் தேடுங்கள்', 'சந்திப்பு பதிவு செய்யுங்கள்', 'சளி அறிகுறிகள்', 'இயல்பான இரத்த அழுத்தம்?', 'நீரிழிவுக்கு உணவு குறிப்புகள்'],
    responses: {
      appointment: "சந்திப்பு பதிவு செய்ய உதவ மகிழ்ச்சியாக இருக்கிறேன்!\n\n1. **'சந்திப்பு பதிவு'** பொத்தானை அழுத்துங்கள்\n2. **மருத்துவர் அட்டவணை** இல் நிபுணர் தேடுங்கள்\n3. **உங்கள் அறிகுறிகளை சொல்லுங்கள்**\n\nநீங்கள் என்ன விரும்புகிறீர்கள்?",
      doctor: "சரியான மருத்துவர் கண்டுபிடிக்க உதவுவேன்!\n- என்ன அறிகுறிகள் உணர்கிறீர்கள்?\n- எந்த பிரிவை தேடுகிறீர்கள்?\n\nஎங்களிடம் 200+ சரிபார்க்கப்பட்ட நிபுணர்கள் உள்ளனர்.",
      default: "உங்கள் கவலை புரிகிறது. பொது மருத்துவ அறிவின் அடிப்படையில் தகவல் தர முடியும். ஆனால் இது தகவல் மட்டுமே.\n\nசரியான நோயறிதலுக்கு எங்கள் நிபுணரை அணுகுங்கள். சந்திப்பு பதிவு செய்யட்டுமா?",
    },
  },
  {
    code: 'kn', label: 'Kannada', flag: '🇮🇳', nativeLabel: 'ಕನ್ನಡ',
    placeholder: 'ನಿಮ್ಮ ಆರೋಗ್ಯ, ವರದಿಗಳು ಅಥವಾ ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಬಗ್ಗೆ ಕೇಳಿ…',
    disclaimer: 'AI ಉತ್ತರಗಳು ಮಾಹಿತಿ ಉದ್ದೇಶಗಳಿಗಾಗಿ ಮಾತ್ರ, ಇವು ವೈದ್ಯಕೀಯ ಸಲಹೆಯ ಪರ್ಯಾಯವಲ್ಲ.',
    typingLabel: 'MediGuide AI ಟೈಪ್ ಮಾಡುತ್ತಿದೆ…',
    suggestedLabel: 'ಸೂಚಿಸಲಾದ ಪ್ರಶ್ನೆಗಳು',
    prompts: ['ನನ್ನ CBC ವರದಿ ವಿವರಿಸಿ', 'ಹೃದ್ರೋಗ ತಜ್ಞರನ್ನು ಹುಡುಕಿ', 'ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಬುಕ್ ಮಾಡಿ', 'ನೆಗಡಿ ರೋಗಲಕ್ಷಣಗಳು', 'ಸಾಮಾನ್ಯ ರಕ್ತದೊತ್ತಡ?', 'ಮಧುಮೇಹಕ್ಕೆ ಆಹಾರ ಸಲಹೆಗಳು'],
    responses: {
      appointment: "ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಬುಕ್ ಮಾಡಲು ಸಹಾಯ ಮಾಡಲು ಸಂತೋಷ!\n\n1. **'ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಬುಕ್ ಮಾಡಿ'** ಕ್ಲಿಕ್ ಮಾಡಿ\n2. **ವೈದ್ಯರ ಡೈರೆಕ್ಟರಿ** ಯಲ್ಲಿ ತಜ್ಞರನ್ನು ಹುಡುಕಿ\n3. **ನಿಮ್ಮ ರೋಗಲಕ್ಷಣಗಳು ಹೇಳಿ**\n\nನೀವು ಏನು ಬಯಸುತ್ತೀರಿ?",
      doctor: "ಸರಿಯಾದ ವೈದ್ಯರನ್ನು ಹುಡುಕಲು ಸಹಾಯ ಮಾಡಬಲ್ಲೆ!\n- ಯಾವ ರೋಗಲಕ್ಷಣಗಳಿವೆ?\n- ಯಾವ ವಿಭಾಗ ಬೇಕು?\n\nನಮ್ಮಲ್ಲಿ 200+ ಪರಿಶೀಲಿಸಲಾದ ತಜ್ಞರಿದ್ದಾರೆ.",
      default: "ನಿಮ್ಮ ಕಾಳಜಿ ಅರ್ಥವಾಗುತ್ತದೆ. ಸಾಮಾನ್ಯ ವೈದ್ಯಕೀಯ ಜ್ಞಾನದ ಆಧಾರದ ಮೇಲೆ ಮಾಹಿತಿ ನೀಡಬಲ್ಲೆ. ಆದರೆ ಇದು ಮಾಹಿತಿ ಮಾತ್ರ.\n\nಸರಿಯಾದ ರೋಗನಿರ್ಣಯಕ್ಕೆ ತಜ್ಞರನ್ನು ಸಂಪರ್ಕಿಸಿ. ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಬುಕ್ ಮಾಡಲಾ?",
    },
  },
  {
    code: 'ml', label: 'Malayalam', flag: '🇮🇳', nativeLabel: 'മലയാളം',
    placeholder: 'നിങ്ങളുടെ ആരോഗ്യം, റിപ്പോർട്ടുകൾ അല്ലെങ്കിൽ അപ്പോയ്ൻ്റ്മെൻ്റ് കുറിച്ച് ചോദിക്കൂ…',
    disclaimer: 'AI ഉത്തരങ്ങൾ വിവര ആവശ്യങ്ങൾക്ക് മാത്രം, ഇവ വൈദ്യ ഉപദേശത്തിൻ്റെ പകരമല്ല.',
    typingLabel: 'MediGuide AI ടൈപ്പ് ചെയ്യുന്നു…',
    suggestedLabel: 'നിർദ്ദേശിച്ച ചോദ്യങ്ങൾ',
    prompts: ['എൻ്റെ CBC റിപ്പോർട്ട് വിശദീകരിക്കൂ', 'ഹൃദ്രോഗ ഡോക്ടറെ കണ്ടെത്തൂ', 'അപ്പോയ്ൻ്റ്മെൻ്റ് ബുക്ക് ചെയ്യൂ', 'ജലദോഷ ലക്ഷണങ്ങൾ', 'സാധാരണ രക്തസമ്മർദ്ദം?', 'പ്രമേഹത്തിന് ഭക്ഷണ നുറുങ്ങുകൾ'],
    responses: {
      appointment: "അപ്പോയ്ൻ്റ്മെൻ്റ് ബുക്ക് ചെയ്യാൻ സഹായിക്കാൻ സന്തോഷം!\n\n1. **'അപ്പോയ്ൻ്റ്മെൻ്റ് ബുക്ക് ചെയ്യൂ'** ക്ലിക്ക് ചെയ്യൂ\n2. **ഡോക്ടർ ഡയറക്ടറി**യിൽ വിദഗ്ദ്ധരെ തിരയൂ\n3. **ലക്ഷണങ്ങൾ പറയൂ**\n\nനിങ്ങൾ എന്ത് ആഗ്രഹിക്കുന്നു?",
      doctor: "ശരിയായ ഡോക്ടറെ കണ്ടെത്താൻ സഹായിക്കാം!\n- ഏത് ലക്ഷണങ്ങൾ അനുഭവിക്കുന്നു?\n- ഏത് വിഭാഗം വേണം?\n\nഞങ്ങളുടെ 200+ പരിശോധിത വിദഗ്ദ്ധർ ലഭ്യമാണ്.",
      default: "നിങ്ങളുടെ ആശങ്ക മനസ്സിലാകുന്നു. പൊതു വൈദ്യ അറിവ് അടിസ്ഥാനത്തിൽ വിവരം നൽകാം. ഇത് വിവര മാത്രം.\n\nകൃത്യമായ രോഗനിർണ്ണയത്തിന് വിദഗ്ദ്ധനെ ബന്ധപ്പെടൂ. അപ്പോയ്ൻ്റ്മെൻ്റ് ബുക്ക് ചെയ്യട്ടെ?",
    },
  },
  {
    code: 'ar', label: 'Arabic', flag: '🇸🇦', nativeLabel: 'العربية',
    placeholder: 'اسألني أي شيء عن صحتك أو تقاريرك أو مواعيدك…',
    disclaimer: 'ردود الذكاء الاصطناعي لأغراض إعلامية فقط وليست بديلاً عن المشورة الطبية المتخصصة.',
    typingLabel: 'MediGuide AI يكتب…',
    suggestedLabel: 'أسئلة مقترحة',
    prompts: ['اشرح تقرير CBC', 'ابحث عن طبيب قلب', 'احجز موعداً', 'أعراض نزلات البرد', 'ما هو ضغط الدم الطبيعي؟', 'نصائح غذائية للسكري'],
    responses: {
      appointment: "يسعدني مساعدتك في حجز موعد!\n\n1. **انقر على 'حجز موعد'** في لوحة التحكم\n2. **تصفح دليل الأطباء** للعثور على متخصص\n3. **أخبرني بأعراضك** وسأوصي بالقسم المناسب\n\nماذا تفضل؟",
      doctor: "يمكنني مساعدتك في إيجاد الطبيب المناسب!\n- ما الأعراض التي تعاني منها؟\n- ما القسم الذي تبحث عنه؟\n\nلدينا أكثر من 200 متخصص معتمد.",
      default: "أفهم قلقك. بناءً على المعرفة الطبية العامة، يمكنني تقديم بعض المعلومات. تذكر أن هذا للأغراض الإعلامية فقط.\n\nللحصول على تشخيص دقيق، أنصحك باستشارة أحد متخصصينا. هل تريد حجز موعد؟",
    },
  },
  {
    code: 'fr', label: 'French', flag: '🇫🇷', nativeLabel: 'Français',
    placeholder: 'Posez-moi des questions sur votre santé, rapports ou rendez-vous…',
    disclaimer: 'Les réponses de l\'IA sont uniquement à titre informatif et ne remplacent pas les conseils médicaux professionnels.',
    typingLabel: 'MediGuide AI écrit…',
    suggestedLabel: 'Questions suggérées',
    prompts: ['Expliquer mon bilan NFS', 'Trouver un cardiologue', 'Prendre un rendez-vous', 'Symptômes du rhume', 'Tension artérielle normale?', 'Conseils diét. diabète'],
    responses: {
      appointment: "Je serais ravi de vous aider à prendre rendez-vous!\n\n1. **Cliquez sur 'Prendre rendez-vous'** dans votre tableau de bord\n2. **Parcourez l'annuaire des médecins** pour trouver un spécialiste\n3. **Décrivez vos symptômes** et je vous recommanderai le bon service\n\nQue préférez-vous?",
      doctor: "Je peux vous aider à trouver le bon médecin!\n- Quels symptômes ressentez-vous?\n- Quel service recherchez-vous?\n\nNous avons plus de 200 spécialistes vérifiés disponibles.",
      default: "Je comprends votre préoccupation. Sur la base des connaissances médicales générales, je peux fournir quelques informations. N'oubliez pas que cela est à titre informatif uniquement.\n\nPour un diagnostic précis, je vous recommande de consulter l'un de nos spécialistes. Voulez-vous prendre rendez-vous?",
    },
  },
  {
    code: 'es', label: 'Spanish', flag: '🇪🇸', nativeLabel: 'Español',
    placeholder: 'Pregúntame sobre tu salud, informes o citas médicas…',
    disclaimer: 'Las respuestas de IA son solo para fines informativos y no sustituyen el consejo médico profesional.',
    typingLabel: 'MediGuide AI está escribiendo…',
    suggestedLabel: 'Preguntas sugeridas',
    prompts: ['Explicar mi informe CBC', 'Buscar cardiólogo', 'Reservar una cita', 'Síntomas del resfriado', '¿Presión arterial normal?', 'Dieta para diabetes'],
    responses: {
      appointment: "¡Con gusto te ayudo a reservar una cita!\n\n1. **Haz clic en 'Reservar cita'** en tu panel\n2. **Explora el directorio médico** para encontrar un especialista\n3. **Describe tus síntomas** y te recomendaré el departamento adecuado\n\n¿Qué prefieres?",
      doctor: "¡Puedo ayudarte a encontrar el médico adecuado!\n- ¿Qué síntomas tienes?\n- ¿Qué departamento buscas?\n\nTenemos más de 200 especialistas verificados disponibles.",
      default: "Entiendo tu preocupación. Basándome en conocimientos médicos generales, puedo brindarte información. Sin embargo, recuerda que esto es solo informativo.\n\nPara un diagnóstico preciso, te recomiendo consultar con uno de nuestros especialistas. ¿Te gustaría reservar una cita?",
    },
  },
  // ── Additional Indian languages ──────────────────────────────────────────────
  {
    code: 'bn', label: 'Bengali', flag: '🇮🇳', nativeLabel: 'বাংলা',
    placeholder: 'আপনার স্বাস্থ্য, রিপোর্ট বা অ্যাপয়েন্টমেন্ট সম্পর্কে জিজ্ঞাসা করুন…',
    disclaimer: 'AI উত্তরগুলি কেবল তথ্যের উদ্দেশ্যে এবং পেশাদার চিকিৎসা পরামর্শের বিকল্প নয়।',
    typingLabel: 'MediGuide AI টাইপ করছে…',
    suggestedLabel: 'প্রস্তাবিত প্রশ্ন',
    prompts: ['আমার CBC রিপোর্ট বুঝিয়ে দিন', 'হৃদরোগ বিশেষজ্ঞ খুঁজুন', 'অ্যাপয়েন্টমেন্ট বুক করুন', 'সর্দির লক্ষণ', 'স্বাভাবিক রক্তচাপ কত?', 'ডায়াবেটিসের জন্য খাদ্য পরামর্শ'],
    responses: {
      appointment: "আমি আপনার অ্যাপয়েন্টমেন্ট বুক করতে সাহায্য করতে পারি!\n\n1. **'অ্যাপয়েন্টমেন্ট বুক করুন'** ক্লিক করুন\n2. **ডাক্তার ডিরেক্টরি** তে বিশেষজ্ঞ খুঁজুন\n3. **আপনার লক্ষণ বলুন** এবং আমি সঠিক বিভাগ সুপারিশ করব\n\nআপনি কী চান?",
      doctor: "আমি আপনার জন্য সঠিক ডাক্তার খুঁজে পেতে সাহায্য করতে পারি!\n- আপনি কী লক্ষণ অনুভব করছেন?\n- কোন বিভাগ দরকার?\n\nআমাদের কাছে ২০০+ যাচাইকৃত বিশেষজ্ঞ রয়েছেন।",
      default: "আপনার উদ্বেগ বুঝতে পারছি। সাধারণ চিকিৎসা জ্ঞানের ভিত্তিতে কিছু তথ্য দিতে পারি। তবে এটি কেবল তথ্যমূলক।\n\nসঠিক রোগ নির্ণয়ের জন্য আমাদের বিশেষজ্ঞের সাথে পরামর্শ করুন। অ্যাপয়েন্টমেন্ট বুক করব কি?",
    },
  },
  {
    code: 'gu', label: 'Gujarati', flag: '🇮🇳', nativeLabel: 'ગુજરાતી',
    placeholder: 'તમારા સ્વાસ્થ્ય, રિપોર્ટ અથવા અપોઈન્ટમેન્ટ વિશે પૂછો…',
    disclaimer: 'AI જવાબો ફક્ત માહિતી હેતુ માટે છે અને વ્યાવસાયિક તબીબી સલાહનો વિકલ્પ નથી.',
    typingLabel: 'MediGuide AI ટાઇપ કરી રહ્યું છે…',
    suggestedLabel: 'સૂચિત પ્રશ્નો',
    prompts: ['મારો CBC રિપોર્ટ સમજાવો', 'હૃદય નિષ્ણાત શોધો', 'અપોઈન્ટમેન્ટ બુક કરો', 'શરદીના લક્ષણો', 'સામાન્ય બ્લડ પ્રેશર?', 'ડાયાબિટીસ માટે આહાર'],
    responses: {
      appointment: "હું તમારી અપોઈન્ટમેન્ટ બુક કરવામાં મદદ કરીશ!\n\n1. **'અપોઈન્ટમેન્ટ બુક કરો'** ક્લિક કરો\n2. **ડૉક્ટર ડિરેક્ટ્રી** માં નિષ્ણાત શોધો\n3. **તમારા લક્ષણ જણાવો** અને હું યોગ્ય વિભાગ સૂચવીશ\n\nતમે શું ઇચ્છો?",
      doctor: "સાચો ડૉક્ટર શોધવામાં મદદ કરી શકું!\n- તમે કેવા લક્ષણ અનુભવ કરો છો?\n- કયો વિભાગ જોઈએ?\n\nઅમારી પાસે ૨૦૦+ ચકાસાયેલ નિષ્ણાતો છે.",
      default: "તમારી ચિંતા સમજી. સામાન્ય તબીબી જ્ઞાનના આધારે માહિતી આપી શકું. પરંતુ આ ફક્ત માહિતી છે.\n\nસચોટ નિદાન માટે અમારા નિષ્ણાતની સલાહ લો. અપોઈન્ટમેન્ટ બુક કરું?",
    },
  },
  {
    code: 'mr', label: 'Marathi', flag: '🇮🇳', nativeLabel: 'मराठी',
    placeholder: 'तुमच्या आरोग्य, अहवाल किंवा अपॉइंटमेंटबद्दल विचारा…',
    disclaimer: 'AI उत्तरे केवळ माहितीच्या उद्देशाने आहेत आणि व्यावसायिक वैद्यकीय सल्ल्याचा पर्याय नाहीत.',
    typingLabel: 'MediGuide AI टाइप करत आहे…',
    suggestedLabel: 'सुचवलेले प्रश्न',
    prompts: ['माझा CBC अहवाल समजावा', 'हृदयरोग तज्ञ शोधा', 'अपॉइंटमेंट बुक करा', 'सर्दीची लक्षणे', 'सामान्य रक्तदाब?', 'मधुमेहासाठी आहार'],
    responses: {
      appointment: "अपॉइंटमेंट बुक करण्यास मदत करतो!\n\n1. **'अपॉइंटमेंट बुक करा'** क्लिक करा\n2. **डॉक्टर डिरेक्टरी** मध्ये तज्ञ शोधा\n3. **लक्षणे सांगा** आणि मी योग्य विभाग सुचवेन\n\nतुम्हाला काय हवे?",
      doctor: "योग्य डॉक्टर शोधण्यास मदत करेन!\n- कोणती लक्षणे जाणवत आहेत?\n- कोणता विभाग हवा?\n\nआमच्याकडे २००+ प्रमाणित तज्ञ उपलब्ध आहेत.",
      default: "तुमची काळजी समजते. सामान्य वैद्यकीय ज्ञानावर आधारित माहिती देऊ शकतो. परंतु हे केवळ माहितीसाठी आहे.\n\nअचूक निदानासाठी तज्ञांशी सल्लामसलत करा. अपॉइंटमेंट बुक करू का?",
    },
  },
  {
    code: 'pa', label: 'Punjabi', flag: '🇮🇳', nativeLabel: 'ਪੰਜਾਬੀ',
    placeholder: 'ਆਪਣੀ ਸਿਹਤ, ਰਿਪੋਰਟਾਂ ਜਾਂ ਅਪੌਇੰਟਮੈਂਟ ਬਾਰੇ ਪੁੱਛੋ…',
    disclaimer: 'AI ਜਵਾਬ ਸਿਰਫ਼ ਜਾਣਕਾਰੀ ਦੇ ਮਕਸਦ ਲਈ ਹਨ ਅਤੇ ਡਾਕਟਰੀ ਸਲਾਹ ਦਾ ਬਦਲ ਨਹੀਂ।',
    typingLabel: 'MediGuide AI ਟਾਈਪ ਕਰ ਰਿਹਾ ਹੈ…',
    suggestedLabel: 'ਸੁਝਾਏ ਗਏ ਸਵਾਲ',
    prompts: ['ਮੇਰੀ CBC ਰਿਪੋਰਟ ਦੱਸੋ', 'ਦਿਲ ਦੇ ਡਾਕਟਰ ਲੱਭੋ', 'ਅਪੌਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰੋ', 'ਜ਼ੁਕਾਮ ਦੇ ਲੱਛਣ', 'ਆਮ ਬਲੱਡ ਪ੍ਰੈਸ਼ਰ?', 'ਸ਼ੂਗਰ ਲਈ ਖੁਰਾਕ'],
    responses: {
      appointment: "ਅਪੌਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰਨ ਵਿੱਚ ਮਦਦ ਕਰਾਂਗਾ!\n\n1. **'ਅਪੌਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰੋ'** ਕਲਿੱਕ ਕਰੋ\n2. **ਡਾਕਟਰ ਡਾਇਰੈਕਟਰੀ** ਵਿੱਚ ਮਾਹਰ ਲੱਭੋ\n3. **ਲੱਛਣ ਦੱਸੋ** ਅਤੇ ਮੈਂ ਸਹੀ ਵਿਭਾਗ ਦੱਸਾਂਗਾ\n\nਤੁਸੀਂ ਕੀ ਚਾਹੁੰਦੇ ਹੋ?",
      doctor: "ਸਹੀ ਡਾਕਟਰ ਲੱਭਣ ਵਿੱਚ ਮਦਦ ਕਰ ਸਕਦਾ ਹਾਂ!\n- ਕਿਹੜੇ ਲੱਛਣ ਹਨ?\n- ਕਿਹੜਾ ਵਿਭਾਗ ਚਾਹੀਦਾ?\n\nਸਾਡੇ ਕੋਲ ੨੦੦+ ਪ੍ਰਮਾਣਿਤ ਮਾਹਰ ਹਨ।",
      default: "ਤੁਹਾਡੀ ਚਿੰਤਾ ਸਮਝ ਆਉਂਦੀ ਹੈ। ਆਮ ਡਾਕਟਰੀ ਜਾਣਕਾਰੀ ਦੇ ਸਕਦਾ ਹਾਂ। ਪਰ ਇਹ ਸਿਰਫ਼ ਜਾਣਕਾਰੀ ਹੈ।\n\nਸਹੀ ਜਾਂਚ ਲਈ ਮਾਹਰ ਨਾਲ ਸਲਾਹ ਕਰੋ। ਅਪੌਇੰਟਮੈਂਟ ਬੁੱਕ ਕਰਾਂ?",
    },
  },
  {
    code: 'or', label: 'Odia', flag: '🇮🇳', nativeLabel: 'ଓଡ଼ିଆ',
    placeholder: 'ଆପଣଙ୍କ ସ୍ୱାସ୍ଥ୍ୟ, ରିପୋର୍ଟ ବା ଆପଏଣ୍ଟମେଣ୍ଟ ବିଷୟରେ ପଚାରନ୍ତୁ…',
    disclaimer: 'AI ଉତ୍ତରଗୁଡ଼ିକ କେବଳ ସୂଚନା ଉଦ୍ଦେଶ୍ୟ ପାଇଁ ଏବଂ ଚିକିତ୍ସା ପରାମର୍ଶର ବିକଳ୍ପ ନୁହେଁ।',
    typingLabel: 'MediGuide AI ଟାଇପ କରୁଛି…',
    suggestedLabel: 'ପ୍ରସ୍ତାବିତ ପ୍ରଶ୍ନ',
    prompts: ['ମୋ CBC ରିପୋର୍ଟ ବ୍ୟାଖ୍ୟା କରନ୍ତୁ', 'ହୃଦ ରୋଗ ବିଶେଷଜ୍ଞ ଖୋଜନ୍ତୁ', 'ଆପଏଣ୍ଟମେଣ୍ଟ ବୁକ କରନ୍ତୁ', 'ଥଣ୍ଡା ଲକ୍ଷଣ', 'ସ୍ୱାଭାବିକ ରକ୍ତଚାପ?', 'ମଧୁମେହ ଖାଦ୍ୟ ପରାମର୍ଶ'],
    responses: {
      appointment: "ଆପଏଣ୍ଟମେଣ୍ଟ ବୁକ କରିବାକୁ ସାହାଯ୍ୟ କରିବି!\n\n1. **'ଆପଏଣ୍ଟମେଣ୍ଟ ବୁକ'** କ୍ଲିକ କରନ୍ତୁ\n2. **ଡାକ୍ତର ଡାଇରେକ୍ଟ୍ରି** ରେ ବିଶେଷଜ୍ଞ ଖୋଜନ୍ତୁ\n3. **ଲକ୍ଷଣ କୁହନ୍ତୁ** ଏବଂ ମୁଁ ଉଚିତ ବିଭାଗ ସୁପାରିଶ କରିବି\n\nଆପଣ କ'ଣ ଚାହୁଁଛନ୍ତି?",
      doctor: "ଉଚିତ ଡାକ୍ତର ଖୋଜିବାକୁ ସାହାଯ୍ୟ କରିବି!\n- କ'ଣ ଲକ୍ଷଣ ଅନୁଭବ କରୁଛନ୍ତି?\n- କେଉଁ ବିଭାଗ ଦରକାର?\n\nଆମ ପାଖରେ ୨୦୦+ ଯାଞ୍ଚ ବିଶେଷଜ୍ଞ ଅଛନ୍ତି।",
      default: "ଆପଣଙ୍କ ଚିନ୍ତା ବୁଝୁଛି। ସାଧାରଣ ଚିକିତ୍ସା ଜ୍ଞାନ ଉପରେ ଆଧାର କରି ସୂଚନା ଦେଇ ପାରିବି। ଏହା କେବଳ ସୂଚନା।\n\nସଠିକ ରୋଗ ନିର୍ଣ୍ଣୟ ପାଇଁ ବିଶେଷଜ୍ଞଙ୍କ ସହ ପରାମର୍ଶ କରନ୍ତୁ। ଆପଏଣ୍ଟମେଣ୍ଟ ବୁକ କରିବୁ?",
    },
  },
  {
    code: 'ur', label: 'Urdu', flag: '🇮🇳', nativeLabel: 'اردو',
    placeholder: 'اپنی صحت، رپورٹس یا اپائنٹمنٹ کے بارے میں پوچھیں…',
    disclaimer: 'AI کے جوابات صرف معلوماتی مقاصد کے لیے ہیں اور پیشہ ورانہ طبی مشورے کا متبادل نہیں۔',
    typingLabel: 'MediGuide AI لکھ رہا ہے…',
    suggestedLabel: 'تجویز کردہ سوالات',
    prompts: ['میری CBC رپورٹ سمجھائیں', 'دل کا ڈاکٹر تلاش کریں', 'اپائنٹمنٹ بک کریں', 'نزلہ کی علامات', 'نارمل بلڈ پریشر؟', 'ذیابیطس کی خوراک'],
    responses: {
      appointment: "اپائنٹمنٹ بک کرنے میں مدد کرتا ہوں!\n\n1. **'اپائنٹمنٹ بک کریں'** پر کلک کریں\n2. **ڈاکٹر ڈائریکٹری** میں ماہر تلاش کریں\n3. **علامات بتائیں** اور میں صحیح شعبہ تجویز کروں گا\n\nآپ کیا چاہتے ہیں؟",
      doctor: "صحیح ڈاکٹر ڈھونڈنے میں مدد کر سکتا ہوں!\n- کیا علامات ہیں؟\n- کون سا شعبہ چاہیے؟\n\nہمارے پاس ۲۰۰ سے زیادہ تصدیق شدہ ماہرین ہیں۔",
      default: "آپ کی فکر سمجھ آتی ہے۔ عام طبی علم کی بنیاد پر معلومات دے سکتا ہوں۔ لیکن یہ صرف معلومات ہے۔\n\nصحیح تشخیص کے لیے ہمارے ماہر سے مشورہ کریں۔ اپائنٹمنٹ بک کروں؟",
    },
  },
  {
    code: 'as', label: 'Assamese', flag: '🇮🇳', nativeLabel: 'অসমীয়া',
    placeholder: 'আপোনাৰ স্বাস্থ্য, ৰিপোৰ্ট বা এপয়েণ্টমেণ্টৰ বিষয়ে সুধক…',
    disclaimer: 'AI উত্তৰবোৰ কেৱল তথ্যৰ বাবে আৰু পেছাদাৰী চিকিৎসা পৰামৰ্শৰ বিকল্প নহয়।',
    typingLabel: 'MediGuide AI টাইপ কৰি আছে…',
    suggestedLabel: 'পৰামৰ্শ দিয়া প্ৰশ্নসমূহ',
    prompts: ['মোৰ CBC ৰিপোৰ্ট বুজাওক', 'হৃদৰোগ বিশেষজ্ঞ বিচাৰক', 'এপয়েণ্টমেণ্ট বুক কৰক', 'চৰ্দিৰ লক্ষণ', 'স্বাভাৱিক ৰক্তচাপ?', 'ডায়েবেটিছৰ বাবে আহাৰ'],
    responses: {
      appointment: "এপয়েণ্টমেণ্ট বুক কৰিবলৈ সহায় কৰিম!\n\n1. **'এপয়েণ্টমেণ্ট বুক কৰক'** ক্লিক কৰক\n2. **ডাক্তৰ ডাইৰেক্টৰী** ত বিশেষজ্ঞ বিচাৰক\n3. **লক্ষণ কওক** আৰু মই সঠিক বিভাগ পৰামৰ্শ দিম\n\nআপুনি কি বিচাৰে?",
      doctor: "সঠিক ডাক্তৰ বিচাৰিবলৈ সহায় কৰিব পাৰিম!\n- কি লক্ষণ অনুভৱ কৰিছে?\n- কোনটো বিভাগ লাগে?\n\nআমাৰ ওচৰত ২০০+ যাচাই কৰা বিশেষজ্ঞ আছে।",
      default: "আপোনাৰ উদ্বেগ বুজি পাইছো। সাধাৰণ চিকিৎসা জ্ঞানৰ ভিত্তিত কিছু তথ্য দিব পাৰিম। কিন্তু এয়া কেৱল তথ্য।\n\nসঠিক ৰোগ নিৰ্ণয়ৰ বাবে বিশেষজ্ঞৰ পৰামৰ্শ লওক। এপয়েণ্টমেণ্ট বুক কৰিমনে?",
    },
  },
];

const AIChatPage: React.FC = () => {
  const { user: authUser } = useAuth();
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [showPrompts, setShowPrompts] = useState(true);
  const [selectedLang, setSelectedLang] = useState<LangConfig>(LANGUAGES[0]);
  const [langOpen, setLangOpen] = useState(false);

  // TTS playback state: msgId → 'loading' | 'playing' | null
  const [voiceState, setVoiceState] = useState<Record<string, 'loading' | 'playing' | null>>({});
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const playingIdRef = useRef<string | null>(null);

  // Mic / STT recording state
  const [micState, setMicState] = useState<'idle' | 'recording' | 'transcribing'>('idle');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (!authUser?.id) return;
    getChatMessages(authUser.id).then((data: ChatMessage[]) => {
      const local: LocalMessage[] = data.map(m => ({
        id: m.id,
        role: m.role as 'user' | 'assistant',
        content: m.content,
        timestamp: new Date(m.created_at),
        lang: 'en',
      }));
      setMessages(local);
      if (local.length > 0) setShowPrompts(false);
    });
  }, [authUser?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // ── TTS: stop any playing audio ────────────────────────────────────────────
  const stopAudio = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
      audioRef.current = null;
    }
    if (playingIdRef.current) {
      setVoiceState(prev => ({ ...prev, [playingIdRef.current!]: null }));
      playingIdRef.current = null;
    }
  }, []);

  // ── TTS: play a message ─────────────────────────────────────────────────────
  const handleSpeak = useCallback(async (msg: LocalMessage) => {
    if (playingIdRef.current === msg.id) { stopAudio(); return; }
    stopAudio();
    setVoiceState(prev => ({ ...prev, [msg.id]: 'loading' }));
    try {
      const { data, error } = await supabase.functions.invoke('text-to-speech', {
        body: { input: msg.content, voice: 'heart', response_format: 'mp3' },
      });
      if (error) throw error;
      const audio = new Audio(data.audioUrl);
      audioRef.current = audio;
      playingIdRef.current = msg.id;
      setVoiceState(prev => ({ ...prev, [msg.id]: 'playing' }));
      audio.play();
      audio.onended = () => {
        setVoiceState(prev => ({ ...prev, [msg.id]: null }));
        playingIdRef.current = null;
        audioRef.current = null;
      };
      audio.onerror = () => {
        setVoiceState(prev => ({ ...prev, [msg.id]: null }));
        playingIdRef.current = null;
        audioRef.current = null;
        toast.error('Failed to play audio');
      };
    } catch {
      setVoiceState(prev => ({ ...prev, [msg.id]: null }));
      toast.error('Could not generate voice. Please try again.');
    }
  }, [stopAudio]);

  // ── STT: upload blob to storage → transcribe ───────────────────────────────
  const transcribeBlob = useCallback(async (blob: Blob) => {
    setMicState('transcribing');
    try {
      // Upload recording to Supabase storage
      const fileName = `voice-${Date.now()}.webm`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('generated-media')
        .upload(`recordings/${fileName}`, blob, { contentType: blob.type || 'audio/webm' });
      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('generated-media')
        .getPublicUrl(uploadData.path);

      // Call speech-to-text edge function with public URL
      const { data, error } = await supabase.functions.invoke('speech-to-text', {
        body: { fileUrl: urlData.publicUrl, language: selectedLang.code === 'en' ? 'english' : undefined },
      });
      if (error) throw error;

      const transcript: string = data?.text?.trim() ?? '';
      if (transcript) {
        setInput(transcript);
        textareaRef.current?.focus();
        toast.success('Voice transcribed — review and send');
      } else {
        toast.warning('Could not detect speech. Please try again.');
      }
    } catch {
      toast.error('Transcription failed. Please type your message instead.');
    } finally {
      setMicState('idle');
    }
  }, [selectedLang.code]);

  // ── STT: start / stop mic recording ────────────────────────────────────────
  const handleMicToggle = useCallback(async () => {
    if (micState === 'recording') {
      mediaRecorderRef.current?.stop();
      return;
    }
    if (micState === 'transcribing') return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4';
      const recorder = new MediaRecorder(stream, { mimeType });
      audioChunksRef.current = [];

      recorder.ondataavailable = e => { if (e.data.size > 0) audioChunksRef.current.push(e.data); };
      recorder.onstop = () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: mimeType });
        transcribeBlob(blob);
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setMicState('recording');
    } catch {
      toast.error('Microphone access denied. Please allow microphone permission and try again.');
    }
  }, [micState, transcribeBlob]);

  const handleLangChange = (lang: LangConfig) => {
    setSelectedLang(lang);
    setLangOpen(false);
    toast.success(`Language set to ${lang.nativeLabel}`);
  };

  const simulateResponse = async (userMsg: string, lang: LangConfig) => {
    setIsTyping(true);
    await new Promise(r => setTimeout(r, 1200 + Math.random() * 800));
    const key = userMsg.toLowerCase().includes('appointment') || userMsg.includes('अपॉइंटमेंट') || userMsg.includes('موعد') ? 'appointment'
      : userMsg.toLowerCase().includes('doctor') || userMsg.toLowerCase().includes('डॉक्टर') || userMsg.toLowerCase().includes('طبيب') || userMsg.toLowerCase().includes('find') ? 'doctor'
      : 'default';
    const content = lang.responses[key as keyof typeof lang.responses];
    const aiMsg: LocalMessage = { id: Date.now().toString(), role: 'assistant', content, timestamp: new Date(), lang: lang.code };
    setMessages(prev => [...prev, aiMsg]);
    setIsTyping(false);
    if (authUser?.id) await saveChatMessage({ role: 'assistant', content });
  };

  const handleSend = async () => {
    if (!input.trim()) return;
    const content = input.trim();
    const userMsg: LocalMessage = { id: Date.now().toString(), role: 'user', content, timestamp: new Date(), lang: selectedLang.code };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setShowPrompts(false);
    if (authUser?.id) await saveChatMessage({ role: 'user', content });
    await simulateResponse(content, selectedLang);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handlePrompt = (prompt: string) => {
    setInput(prompt);
    setShowPrompts(false);
    textareaRef.current?.focus();
  };

  const formatContent = (content: string) =>
    content.split('\n').map((line, i, arr) => {
      const html = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
      return <span key={i}><span dangerouslySetInnerHTML={{ __html: html }} />{i < arr.length - 1 && <br />}</span>;
    });

  const isRtl = selectedLang.code === 'ar';

  return (
    <AppLayout title="AI Medical Assistant">
      <div className="flex flex-col h-[calc(100vh-8rem)] max-w-4xl mx-auto">

        {/* Top bar: disclaimer + language picker */}
        <div className="flex items-start gap-3 mb-4">
          <div className="flex-1 flex items-start gap-2.5 p-3 bg-warning/10 border border-warning/20 rounded-xl">
            <AlertCircle className="w-4 h-4 text-warning shrink-0 mt-0.5" />
            <p className={cn('text-xs text-muted-foreground leading-relaxed', isRtl && 'text-right')} dir={isRtl ? 'rtl' : 'ltr'}>
              <strong className="text-foreground">
                {selectedLang.code === 'en' ? 'Medical Disclaimer: ' : ''}
              </strong>
              {selectedLang.disclaimer}
            </p>
          </div>

          {/* Language Selector */}
          <Popover open={langOpen} onOpenChange={setLangOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="shrink-0 gap-1.5 h-auto py-2.5 px-3">
                <Globe className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-sm">{selectedLang.flag}</span>
                <span className="text-xs font-medium hidden sm:inline">{selectedLang.nativeLabel}</span>
                <ChevronDown className="w-3 h-3 text-muted-foreground" />
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-56 p-1">
              <div className="mb-1 px-2 py-1.5">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Select Language</p>
              </div>
              <div className="space-y-0.5 max-h-72 overflow-y-auto">
                {LANGUAGES.map(lang => (
                  <button key={lang.code} onClick={() => handleLangChange(lang)}
                    className={cn('w-full flex items-center gap-2.5 px-2 py-2 rounded-lg text-sm transition-colors text-left',
                      selectedLang.code === lang.code ? 'bg-primary/10 text-primary' : 'hover:bg-muted')}>
                    <span className="text-base">{lang.flag}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium leading-none">{lang.nativeLabel}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{lang.label}</p>
                    </div>
                    {selectedLang.code === lang.code && <Check className="w-3.5 h-3.5 text-primary shrink-0" />}
                  </button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1 min-h-0">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div key={msg.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}
                className={cn('flex gap-3', msg.role === 'user' ? 'flex-row-reverse' : 'flex-row')}>
                <div className={cn('w-8 h-8 rounded-full flex items-center justify-center shrink-0',
                  msg.role === 'assistant' ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground')}>
                  {msg.role === 'assistant' ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>
                <div className={cn('max-w-[75%] flex flex-col gap-1', msg.role === 'user' ? 'items-end' : 'items-start')}>
                  <div className={cn('rounded-2xl px-4 py-3 text-sm leading-relaxed',
                    msg.role === 'assistant' ? 'bg-muted text-foreground rounded-tl-sm' : 'bg-primary text-primary-foreground rounded-tr-sm')}
                    dir={msg.lang === 'ar' ? 'rtl' : 'ltr'}>
                    {formatContent(msg.content)}
                    <p className={cn('text-[10px] mt-1', msg.role === 'assistant' ? 'text-muted-foreground' : 'text-primary-foreground/60')}>
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                  {/* Voice button — every message */}
                  <button
                    onClick={() => handleSpeak(msg)}
                    disabled={voiceState[msg.id] === 'loading'}
                    title={voiceState[msg.id] === 'playing' ? 'Stop audio' : 'Listen to this message'}
                    className={cn(
                      'flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-medium transition-colors border',
                      voiceState[msg.id] === 'playing'
                        ? 'border-primary/40 bg-primary/10 text-primary'
                        : voiceState[msg.id] === 'loading'
                        ? 'border-border bg-muted text-muted-foreground cursor-wait'
                        : 'border-border bg-transparent text-muted-foreground hover:border-primary/30 hover:text-primary hover:bg-primary/5'
                    )}>
                    {voiceState[msg.id] === 'loading' ? (
                      <><Loader2 className="w-3 h-3 animate-spin" />Generating…</>
                    ) : voiceState[msg.id] === 'playing' ? (
                      <><VolumeX className="w-3 h-3" />Stop</>
                    ) : (
                      <><Volume2 className="w-3 h-3" />Listen</>
                    )}
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-muted rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-3">
                <div className="flex gap-1 items-center">
                  {[0,1,2].map(i => (
                    <motion.span key={i} className="w-1.5 h-1.5 rounded-full bg-muted-foreground block"
                      animate={{ y: [0, -4, 0] }} transition={{ duration: 0.6, delay: i * 0.15, repeat: Infinity }} />
                  ))}
                </div>
                <span className="text-xs text-muted-foreground">{selectedLang.typingLabel}</span>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick prompts */}
        {showPrompts && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-4 mb-3">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-accent" />
              <span className="text-xs text-muted-foreground font-medium">{selectedLang.suggestedLabel}</span>
            </div>
            <div className={cn('flex flex-wrap gap-2', isRtl && 'flex-row-reverse')}>
              {selectedLang.prompts.map(p => (
                <button key={p} onClick={() => handlePrompt(p)}
                  className="text-xs px-3 py-1.5 rounded-full border border-border hover:border-primary/40 hover:bg-primary/5 transition-colors"
                  dir={isRtl ? 'rtl' : 'ltr'}>
                  {p}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Input area */}
        <div className="border border-border rounded-xl overflow-hidden bg-card mt-2">
          <Textarea ref={textareaRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown}
            placeholder={selectedLang.placeholder} rows={2} dir={isRtl ? 'rtl' : 'ltr'}
            className="border-0 resize-none focus-visible:ring-0 focus-visible:ring-offset-0 text-sm px-4 pt-3 pb-2" />
          <div className="flex items-center justify-between px-3 py-2 border-t border-border">
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={() => toast.info('File upload coming soon')}>
                <Paperclip className="w-4 h-4" />
              </Button>
              {/* Mic button: record voice → transcribe → populate input */}
              <button
                onClick={handleMicToggle}
                disabled={micState === 'transcribing'}
                title={micState === 'recording' ? 'Stop recording' : micState === 'transcribing' ? 'Transcribing…' : 'Speak your question'}
                className={cn(
                  'flex items-center gap-1.5 h-8 px-2.5 rounded-lg text-xs font-medium border transition-colors',
                  micState === 'recording'
                    ? 'border-red-400/60 bg-red-500/10 text-red-500 animate-pulse'
                    : micState === 'transcribing'
                    ? 'border-border bg-muted text-muted-foreground cursor-wait'
                    : 'border-border bg-transparent text-muted-foreground hover:border-primary/30 hover:text-primary hover:bg-primary/5'
                )}>
                {micState === 'transcribing' ? (
                  <><Loader2 className="w-3.5 h-3.5 animate-spin" /><span className="hidden sm:inline">Transcribing…</span></>
                ) : micState === 'recording' ? (
                  <><MicOff className="w-3.5 h-3.5" /><span className="hidden sm:inline">Stop</span></>
                ) : (
                  <><Mic className="w-3.5 h-3.5" /><span className="hidden sm:inline">Speak</span></>
                )}
              </button>
              {input && (
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground" onClick={() => setInput('')}>
                  <X className="w-4 h-4" />
                </Button>
              )}
              {/* Active language badge */}
              <div className="flex items-center gap-1 ml-1 px-2 py-1 rounded-full bg-primary/8 border border-primary/20">
                <span className="text-xs">{selectedLang.flag}</span>
                <span className="text-[10px] font-medium text-primary hidden sm:inline">{selectedLang.nativeLabel}</span>
              </div>
            </div>
            <Button size="sm" onClick={handleSend} disabled={!input.trim() || isTyping}>
              <Send className="w-3.5 h-3.5 mr-1.5" />
              {selectedLang.code === 'en' ? 'Send' : selectedLang.code === 'hi' ? 'भेजें' : selectedLang.code === 'ar' ? 'إرسال' : selectedLang.code === 'fr' ? 'Envoyer' : selectedLang.code === 'es' ? 'Enviar' : 'Send'}
            </Button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default AIChatPage;
