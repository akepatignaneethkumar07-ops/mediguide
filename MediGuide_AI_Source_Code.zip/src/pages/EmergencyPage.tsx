import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import {
  Phone, MapPin, AlertTriangle, Heart, ChevronDown, ChevronUp,
  Ambulance, User, Navigation, Shield, Zap, Wind,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import AppLayout from '@/components/layouts/AppLayout';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/db/supabase';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
}

const EMERGENCY_SERVICES = [
  { label: 'Ambulance',   number: '108', desc: 'National Ambulance Service', color: 'bg-red-600',    icon: Ambulance },
  { label: 'Emergency',  number: '112', desc: 'Unified Emergency Helpline', color: 'bg-orange-600', icon: AlertTriangle },
  { label: 'Police',     number: '100', desc: 'Police Emergency',            color: 'bg-blue-600',   icon: Shield },
  { label: 'Fire',       number: '101', desc: 'Fire Department',             color: 'bg-yellow-600', icon: Zap },
];

const FIRST_AID = [
  {
    title: 'CPR (Cardiac Arrest)',
    icon: Heart,
    steps: [
      'Call 108 immediately.',
      'Place the person on their back on a firm surface.',
      'Kneel beside them and place the heel of your hand on the center of their chest.',
      'Place your other hand on top and interlace your fingers.',
      'Push down hard and fast — 100–120 compressions per minute, about 5 cm deep.',
      'Give 2 rescue breaths after every 30 compressions (if trained).',
      'Continue until ambulance arrives.',
    ],
  },
  {
    title: 'Choking',
    icon: Wind,
    steps: [
      'Encourage the person to cough hard.',
      'Give 5 sharp back blows between the shoulder blades.',
      'If object not cleared, perform 5 abdominal thrusts (Heimlich maneuver).',
      'Alternate back blows and abdominal thrusts until object is expelled or help arrives.',
      'If person becomes unconscious, begin CPR and call 108.',
    ],
  },
  {
    title: 'Severe Bleeding',
    icon: Zap,
    steps: [
      'Call 108 if bleeding is severe or does not stop.',
      'Apply firm pressure on the wound with a clean cloth.',
      'Do not remove the cloth — add more on top if it soaks through.',
      'Elevate the injured limb above heart level if possible.',
      'Keep the person still and calm until help arrives.',
    ],
  },
  {
    title: 'Heart Attack Signs',
    icon: Heart,
    steps: [
      'Call 108 immediately — do not wait.',
      'Have the person sit or lie in a comfortable position.',
      'Loosen any tight clothing around neck and chest.',
      'If the person is conscious, give them an aspirin (325 mg) to chew if not allergic.',
      'Do not leave the person alone; monitor breathing.',
      'Be ready to perform CPR if they become unresponsive.',
    ],
  },
  {
    title: 'Burns',
    icon: Zap,
    steps: [
      'Cool the burn with running cold water for at least 10–20 minutes.',
      'Do NOT use ice, butter, or toothpaste.',
      'Remove jewelry or tight items near the burn.',
      'Cover loosely with a clean, non-fluffy material.',
      'Do not burst blisters.',
      'Seek medical attention for large, deep, or facial burns.',
    ],
  },
];

// Nearby hospitals in major Indian cities
const NEARBY_HOSPITALS = [
  { name: 'Apollo Hospitals',              city: 'Hyderabad', query: 'Apollo Hospitals Hyderabad' },
  { name: 'Fortis Hospital',               city: 'Bangalore', query: 'Fortis Hospital Bangalore' },
  { name: 'AIIMS New Delhi',               city: 'New Delhi', query: 'AIIMS New Delhi' },
  { name: 'Kokilaben Hospital',            city: 'Mumbai',    query: 'Kokilaben Hospital Mumbai' },
  { name: 'Narayana Health',               city: 'Bangalore', query: 'Narayana Health Bangalore' },
];

const MAPS_KEY = 'AIzaSyB_LJOYJL-84SMuxNB7LtRGhxEQLjswvy0';

const EmergencyPage: React.FC = () => {
  const { user } = useAuth();
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [openTip, setOpenTip] = useState<number | null>(null);
  const [ambulanceRequested, setAmbulanceRequested] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('emergency_contacts')
      .select('id, name, phone, relationship')
      .eq('user_id', user.id)
      .order('created_at')
      .then(({ data }) => setContacts(data || []));
  }, [user]);

  const handleAmbulance = () => {
    setAmbulanceRequested(true);
    toast.success('Ambulance request sent! ETA: 10–15 minutes. Call 108 if urgent.');
    setTimeout(() => setAmbulanceRequested(false), 8000);
  };

  return (
    <AppLayout title="Emergency" subtitle="Get help fast">
      <div className="space-y-6 max-w-4xl">

        {/* SOS Header */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          className="rounded-2xl bg-red-600/8 border border-red-200 dark:border-red-900/40 p-6 text-center"
        >
          <div className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center mx-auto mb-4 shadow-lg">
            <AlertTriangle className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-xl font-semibold mb-1.5">Emergency Assistance</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Tap a number below to call emergency services immediately
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {EMERGENCY_SERVICES.map(({ label, number, desc, color, icon: Icon }) => (
              <a
                key={number}
                href={`tel:${number}`}
                className={cn(
                  'flex flex-col items-center gap-1.5 py-4 px-3 rounded-xl text-white text-center transition-transform active:scale-95',
                  color
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="text-2xl font-bold leading-none">{number}</span>
                <span className="text-xs font-medium">{label}</span>
                <span className="text-[10px] opacity-80">{desc}</span>
              </a>
            ))}
          </div>
        </motion.div>

        {/* Ambulance booking */}
        <Card>
          <CardContent className="p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center shrink-0">
              <Ambulance className="w-6 h-6 text-orange-600" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm">Request Ambulance</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Request an ambulance to your current location. ETA 10–15 min.
              </p>
            </div>
            <Button
              className={cn('shrink-0', ambulanceRequested && 'bg-green-600 hover:bg-green-700')}
              onClick={handleAmbulance}
              disabled={ambulanceRequested}
            >
              {ambulanceRequested ? 'Requested ✓' : 'Request Now'}
            </Button>
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <User className="w-4 h-4 text-primary" /> Your Emergency Contacts
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {contacts.length === 0 ? (
              <div className="text-center py-6 border border-dashed border-border rounded-xl">
                <p className="text-sm text-muted-foreground">No emergency contacts saved.</p>
                <p className="text-xs text-muted-foreground/70 mt-1">
                  Add contacts in Profile → Emergency Contacts
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {contacts.map(c => (
                  <div key={c.id} className="flex items-center justify-between p-3 rounded-xl border border-border bg-muted/30">
                    <div className="min-w-0">
                      <p className="text-sm font-medium">{c.name}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {c.relationship || 'Contact'}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{c.phone}</span>
                      </div>
                    </div>
                    <a
                      href={`tel:${c.phone}`}
                      className="ml-3 shrink-0 w-10 h-10 rounded-full bg-green-600 hover:bg-green-700 flex items-center justify-center text-white transition-colors"
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Nearest Hospital Map */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <MapPin className="w-4 h-4 text-primary" /> Nearest Hospitals
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-4">
            <div className="w-full rounded-xl overflow-hidden border border-border">
              <iframe
                width="100%"
                height="300"
                frameBorder="0"
                style={{ border: 0 }}
                referrerPolicy="no-referrer-when-downgrade"
                src={`https://www.google.com/maps/embed/v1/search?key=${MAPS_KEY}&q=hospitals+near+me&language=en&region=IN`}
                allowFullScreen
                title="Nearest Hospitals Map"
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {NEARBY_HOSPITALS.map(h => (
                <a
                  key={h.name}
                  href={`https://maps.google.com/?q=${encodeURIComponent(h.query)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2.5 p-2.5 rounded-lg border border-border hover:bg-muted/40 transition-colors group"
                >
                  <Navigation className="w-4 h-4 text-primary shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate group-hover:text-primary transition-colors">{h.name}</p>
                    <p className="text-xs text-muted-foreground">{h.city}</p>
                  </div>
                </a>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* First Aid Tips */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Heart className="w-4 h-4 text-red-500" /> First Aid Quick Guide
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-2">
            {FIRST_AID.map((tip, i) => {
              const Icon = tip.icon;
              return (
                <Collapsible key={tip.title} open={openTip === i} onOpenChange={open => setOpenTip(open ? i : null)}>
                  <CollapsibleTrigger className="w-full flex items-center justify-between p-3 rounded-xl border border-border hover:bg-muted/30 transition-colors text-left">
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 text-red-500 shrink-0" />
                      <span className="text-sm font-medium">{tip.title}</span>
                    </div>
                    {openTip === i ? <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0" /> : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />}
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <ol className="mt-2 mb-1 px-4 space-y-1.5 list-decimal list-inside">
                      {tip.steps.map((s, j) => (
                        <li key={j} className="text-sm text-muted-foreground leading-relaxed">{s}</li>
                      ))}
                    </ol>
                  </CollapsibleContent>
                </Collapsible>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default EmergencyPage;
