// Real Indian hospital locations — single source of truth used by AppointmentBooking & LandingPage

export interface Location {
  id: string;
  name: string;
  city: string;
  address: string;
  type: string;
}

export const LOCATIONS: Location[] = [
  // ── Andhra Pradesh & Telangana ─────────────────────────────────────────────
  { id: 'loc1',  name: 'Apollo Hospitals',                          city: 'Hyderabad',          address: 'Jubilee Hills Road No.2, Hyderabad – 500033',             type: 'Multi-Specialty Hospital' },
  { id: 'loc2',  name: 'Yashoda Hospitals',                         city: 'Hyderabad',          address: 'Alexander Road, Secunderabad – 500003',                   type: 'Multi-Specialty Hospital' },
  { id: 'loc3',  name: 'KIMS Hospital',                             city: 'Hyderabad',          address: 'Minister Road, Secunderabad – 500003',                    type: 'Multi-Specialty Hospital' },
  { id: 'loc4',  name: 'Basavatarakam Indo American Cancer Hospital',city: 'Hyderabad',          address: 'Banjara Hills Road No.10, Hyderabad – 500034',            type: 'Speciality Hospital' },
  { id: 'loc5',  name: 'Care Hospitals',                            city: 'Visakhapatnam',      address: 'Ramnagar, Visakhapatnam – 530002',                        type: 'Multi-Specialty Hospital' },
  // ── Karnataka ──────────────────────────────────────────────────────────────
  { id: 'loc6',  name: 'Manipal Hospitals',                         city: 'Bangalore',          address: 'HAL Airport Road, Bangalore – 560017',                    type: 'Multi-Specialty Hospital' },
  { id: 'loc7',  name: 'Fortis Hospital Bannerghatta',              city: 'Bangalore',          address: 'Bannerghatta Road, Bangalore – 560076',                   type: 'Multi-Specialty Hospital' },
  { id: 'loc8',  name: 'Narayana Health City',                      city: 'Bangalore',          address: 'Bommasandra Industrial Area, Bangalore – 560099',         type: 'Multi-Specialty Hospital' },
  { id: 'loc9',  name: 'Aster CMI Hospital',                        city: 'Bangalore',          address: 'Hebbal Outer Ring Road, Bangalore – 560024',              type: 'Multi-Specialty Hospital' },
  // ── Tamil Nadu ─────────────────────────────────────────────────────────────
  { id: 'loc10', name: 'Apollo Hospitals Greams Road',              city: 'Chennai',            address: 'Greams Road, Chennai – 600006',                           type: 'Multi-Specialty Hospital' },
  { id: 'loc11', name: 'Fortis Malar Hospital',                     city: 'Chennai',            address: 'Adyar, Chennai – 600020',                                 type: 'Multi-Specialty Hospital' },
  { id: 'loc12', name: 'MIOT International',                        city: 'Chennai',            address: 'Mount Poonamallee Road, Chennai – 600089',                type: 'Multi-Specialty Hospital' },
  { id: 'loc13', name: 'Kovai Medical Center & Hospital',           city: 'Coimbatore',         address: 'Avanashi Road, Coimbatore – 641014',                      type: 'Multi-Specialty Hospital' },
  // ── Kerala ─────────────────────────────────────────────────────────────────
  { id: 'loc14', name: 'Aster Medcity',                             city: 'Kochi',              address: 'Kuttiattoor, Kochi – 682027',                             type: 'Multi-Specialty Hospital' },
  { id: 'loc15', name: 'Amrita Institute of Medical Sciences',      city: 'Kochi',              address: 'Ponekkara, Kochi – 682041',                               type: 'Multi-Specialty Hospital' },
  { id: 'loc16', name: 'KIMS Health Trivandrum',                    city: 'Thiruvananthapuram', address: 'Anayara PO, Thiruvananthapuram – 695029',                 type: 'Multi-Specialty Hospital' },
  // ── Maharashtra ────────────────────────────────────────────────────────────
  { id: 'loc17', name: 'Kokilaben Dhirubhai Ambani Hospital',       city: 'Mumbai',             address: 'Andheri West, Mumbai – 400053',                           type: 'Multi-Specialty Hospital' },
  { id: 'loc18', name: 'Lilavati Hospital',                         city: 'Mumbai',             address: 'Bandra West, Mumbai – 400050',                            type: 'Multi-Specialty Hospital' },
  { id: 'loc19', name: 'P.D. Hinduja National Hospital',            city: 'Mumbai',             address: 'Mahim, Mumbai – 400016',                                  type: 'Multi-Specialty Hospital' },
  { id: 'loc20', name: 'Ruby Hall Clinic',                          city: 'Pune',               address: 'Sassoon Road, Pune – 411001',                             type: 'Multi-Specialty Hospital' },
  { id: 'loc21', name: 'Jehangir Hospital',                         city: 'Pune',               address: '32 Sassoon Road, Pune – 411001',                          type: 'Multi-Specialty Hospital' },
  { id: 'loc22', name: 'Wockhardt Hospital',                        city: 'Nagpur',             address: 'Central Avenue Road, Nagpur – 440008',                    type: 'Multi-Specialty Hospital' },
  // ── Delhi NCR ──────────────────────────────────────────────────────────────
  { id: 'loc23', name: 'AIIMS New Delhi',                           city: 'New Delhi',          address: 'Ansari Nagar East, New Delhi – 110029',                   type: 'Government Teaching Hospital' },
  { id: 'loc24', name: 'Sir Ganga Ram Hospital',                    city: 'New Delhi',          address: 'Old Rajinder Nagar, New Delhi – 110060',                  type: 'Multi-Specialty Hospital' },
  { id: 'loc25', name: 'Max Super Speciality Hospital Saket',       city: 'New Delhi',          address: 'Press Enclave Road, Saket, New Delhi – 110017',           type: 'Multi-Specialty Hospital' },
  { id: 'loc26', name: 'Fortis Memorial Research Institute',        city: 'Gurugram',           address: 'Sector 44, Gurugram – 122002',                            type: 'Multi-Specialty Hospital' },
  { id: 'loc27', name: 'Jaypee Hospital',                           city: 'Noida',              address: 'Sector 128, Noida – 201304',                              type: 'Multi-Specialty Hospital' },
  // ── West Bengal ────────────────────────────────────────────────────────────
  { id: 'loc28', name: 'Apollo Gleneagles Hospitals',               city: 'Kolkata',            address: 'Canal Circular Road, Kolkata – 700054',                   type: 'Multi-Specialty Hospital' },
  { id: 'loc29', name: 'AMRI Hospital Dhakuria',                    city: 'Kolkata',            address: 'Dhakuria, Kolkata – 700029',                              type: 'Multi-Specialty Hospital' },
  // ── Gujarat ────────────────────────────────────────────────────────────────
  { id: 'loc30', name: 'Apollo Hospital Ahmedabad',                 city: 'Ahmedabad',          address: 'BHAT, Gandhinagar Highway, Ahmedabad – 382428',           type: 'Multi-Specialty Hospital' },
  { id: 'loc31', name: 'CIMS Hospital',                             city: 'Ahmedabad',          address: 'Science City Road, Sola, Ahmedabad – 380060',             type: 'Multi-Specialty Hospital' },
  { id: 'loc32', name: 'Sterling Hospital',                         city: 'Surat',              address: 'VIP Road, Vesu, Surat – 395007',                          type: 'Multi-Specialty Hospital' },
  // ── Rajasthan ──────────────────────────────────────────────────────────────
  { id: 'loc33', name: 'Fortis Escorts Hospital',                   city: 'Jaipur',             address: 'Jawaharlal Nehru Marg, Jaipur – 302017',                  type: 'Multi-Specialty Hospital' },
  { id: 'loc34', name: 'Narayana Multispeciality Hospital',         city: 'Jaipur',             address: 'Sector 28, Pratap Nagar, Jaipur – 302033',                type: 'Multi-Specialty Hospital' },
  // ── Uttar Pradesh ──────────────────────────────────────────────────────────
  { id: 'loc35', name: 'Medanta Lucknow',                           city: 'Lucknow',            address: 'Sector B, Sushant Golf City, Lucknow – 226030',           type: 'Multi-Specialty Hospital' },
  { id: 'loc36', name: 'Sahara Hospital',                           city: 'Lucknow',            address: 'Viraj Khand 5, Gomti Nagar, Lucknow – 226010',            type: 'Multi-Specialty Hospital' },
  // ── Punjab & Chandigarh ────────────────────────────────────────────────────
  { id: 'loc37', name: 'PGIMER',                                    city: 'Chandigarh',         address: 'Sector 12, Chandigarh – 160012',                          type: 'Government Teaching Hospital' },
  { id: 'loc38', name: 'Fortis Hospital Mohali',                    city: 'Chandigarh',         address: 'Phase VI, SAS Nagar, Mohali – 160055',                    type: 'Multi-Specialty Hospital' },
  // ── Madhya Pradesh ─────────────────────────────────────────────────────────
  { id: 'loc39', name: 'Bansal Hospital',                           city: 'Bhopal',             address: 'C-Sector, Shahpura, Bhopal – 462016',                     type: 'Multi-Specialty Hospital' },
  // ── Odisha ─────────────────────────────────────────────────────────────────
  { id: 'loc40', name: 'Apollo Hospital Bhubaneswar',               city: 'Bhubaneswar',        address: 'Unit 15, Bhubaneswar – 751005',                           type: 'Multi-Specialty Hospital' },
  // ── Assam ──────────────────────────────────────────────────────────────────
  { id: 'loc41', name: 'Dispur Hospitals',                          city: 'Guwahati',           address: 'GS Road, Dispur, Guwahati – 781006',                      type: 'Multi-Specialty Hospital' },
  // ── Uttarakhand ────────────────────────────────────────────────────────────
  { id: 'loc42', name: 'AIIMS Rishikesh',                           city: 'Rishikesh',          address: 'Virbhadra Road, Rishikesh – 249203',                      type: 'Government Teaching Hospital' },
  // ── Pharmacies ─────────────────────────────────────────────────────────────
  { id: 'loc43', name: 'Apollo Pharmacy 24/7',                      city: 'Hyderabad',          address: 'Banjara Hills Road No.1, Hyderabad – 500034',             type: 'Pharmacy' },
  { id: 'loc44', name: 'MedPlus Pharmacy',                          city: 'Bangalore',          address: 'Koramangala 4th Block, Bangalore – 560034',               type: 'Pharmacy' },
  { id: 'loc45', name: 'Wellness Forever',                          city: 'Mumbai',             address: 'Andheri West, Mumbai – 400053',                           type: 'Pharmacy' },
  { id: 'loc46', name: 'Frank Ross Pharmacy',                       city: 'Kolkata',            address: 'Park Street, Kolkata – 700016',                           type: 'Pharmacy' },
  { id: 'loc47', name: 'Guardian Pharmacy',                         city: 'New Delhi',          address: 'Connaught Place, New Delhi – 110001',                     type: 'Pharmacy' },
];

// Derived counts — used for stats display (no fake numbers)
export const HOSPITAL_COUNT = LOCATIONS.length;
export const CITY_COUNT = new Set(LOCATIONS.map(l => l.city)).size;
