import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { motion } from 'motion/react';
import {
  LayoutDashboard, Calendar, Bot, Stethoscope, FileText,
  Bell, User, Settings, X, Activity, Users, Mic, Pill,
  Shield, Upload, AlertTriangle, Salad, MapPin, Scan,
  type LucideIcon,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useApp } from '@/contexts/AppContext';
import { Badge } from '@/components/ui/badge';

interface NavItem {
  icon: LucideIcon;
  label: string;
  path: string;
  badge?: number;
}

const patientNav: NavItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard',        path: '/dashboard' },
  { icon: Calendar,        label: 'Appointments',     path: '/appointments' },
  { icon: Bot,             label: 'AI Assistant',     path: '/chat' },
  { icon: Mic,             label: 'Voice Assistant',  path: '/voice' },
  { icon: Stethoscope,     label: 'Doctors',          path: '/doctors' },
  { icon: MapPin,          label: 'Hospital Locations', path: '/hospital-map' },
  { icon: FileText,        label: 'Reports',          path: '/reports' },
  { icon: Pill,            label: 'Reminders',        path: '/reminders' },
  { icon: Scan,            label: 'Pill Scanner',     path: '/pill-scanner' },
  { icon: Upload,          label: 'Report Maker',     path: '/report-maker' },
  { icon: AlertTriangle,   label: 'Emergency',        path: '/emergency' },
  { icon: Salad,           label: 'Diet & Health',    path: '/diet' },
  { icon: Bell,            label: 'Notifications',    path: '/notifications', badge: 2 },
  { icon: User,            label: 'Profile',          path: '/profile' },
  { icon: Settings,        label: 'Settings',         path: '/settings' },
];

const staffNav: NavItem[] = [
  { icon: LayoutDashboard, label: 'Staff Portal',   path: '/staff-portal' },
  { icon: Calendar,        label: 'Appointments',   path: '/appointments' },
  { icon: Stethoscope,     label: 'Doctors',        path: '/doctors' },
  { icon: MapPin,          label: 'Hospital Map',   path: '/hospital-map' },
  { icon: Bell,            label: 'Notifications',  path: '/notifications', badge: 3 },
  { icon: User,            label: 'Profile',        path: '/profile' },
  { icon: Settings,        label: 'Settings',       path: '/settings' },
];

const doctorNav: NavItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/doctor-dashboard' },
  { icon: Calendar, label: 'Appointments', path: '/appointments' },
  { icon: Bot, label: 'AI Assistant', path: '/chat' },
  { icon: FileText, label: 'Reports', path: '/reports' },
  { icon: Bell, label: 'Notifications', path: '/notifications', badge: 1 },
  { icon: User, label: 'Profile', path: '/profile' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

const adminNav: NavItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/admin-dashboard' },
  { icon: Users, label: 'Users', path: '/admin-dashboard' },
  { icon: Upload, label: 'Knowledge Base', path: '/admin-dashboard' },
  { icon: Activity, label: 'Analytics', path: '/admin-dashboard' },
  { icon: Shield, label: 'Audit Logs', path: '/admin-dashboard' },
  { icon: Bell, label: 'Notifications', path: '/notifications' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

const hospitalMemberNav: NavItem[] = [
  { icon: LayoutDashboard, label: 'Blood Bank Dashboard', path: '/hospital-member-dashboard' },
  { icon: Bell, label: 'Notifications', path: '/notifications', badge: 1 },
  { icon: User, label: 'Profile', path: '/profile' },
  { icon: Settings, label: 'Settings', path: '/settings' },
];

interface SidebarProps {
  mobile?: boolean;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ mobile = false, onClose }) => {
  const { user } = useApp();
  const location = useLocation();
  const navItems =
    user?.role === 'staff' ? staffNav
    : user?.role === 'doctor' ? doctorNav
    : user?.role === 'admin' ? adminNav
    : user?.role === 'hospital_member' ? hospitalMemberNav
    : patientNav;

  return (
    <div className={cn(
      'flex flex-col h-full bg-sidebar border-r border-sidebar-border',
      mobile ? 'w-72' : 'w-64'
    )}>
      {/* Logo */}
      <div className="flex items-center justify-between px-6 py-5 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center shrink-0">
            <Activity className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-semibold text-base text-sidebar-foreground tracking-tight">MediGuide AI</span>
        </div>
        {mobile && onClose && (
          <button
            onClick={onClose}
            className="p-1.5 rounded-md hover:bg-sidebar-accent text-sidebar-foreground transition-colors"
            aria-label="Close sidebar"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
      {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <NavLink
              key={`${item.path}-${item.label}`}
              to={item.path}
              onClick={mobile ? onClose : undefined}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors relative group',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-foreground'
              )}
            >
              {isActive && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute inset-0 rounded-lg bg-primary"
                  style={{ zIndex: -1 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                />
              )}
              <Icon className="w-4 h-4 shrink-0" />
              <span className="flex-1">{item.label}</span>
              {item.badge != null && (
                <Badge className="h-4 min-w-4 px-1 text-[10px] font-semibold bg-accent text-accent-foreground">
                  {item.badge}
                </Badge>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* User info at bottom */}
      {user && (
        <div className="px-4 py-4 border-t border-sidebar-border">
          <div className="flex items-center gap-3">
            <img
              src={user.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=2563EB&color=fff`}
              alt={user.name}
              className="w-8 h-8 rounded-full object-cover shrink-0"
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-sidebar-foreground truncate">{user.name}</p>
              <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
