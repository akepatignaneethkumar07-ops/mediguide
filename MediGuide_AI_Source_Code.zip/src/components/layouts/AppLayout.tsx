import React from 'react';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import SOSButton from '@/components/SOSButton';

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children, title, subtitle }) => {
  return (
    <div className="flex min-h-screen w-full bg-background">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-border">
        <Sidebar />
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0 flex flex-col overflow-x-hidden">
        <TopBar title={title} subtitle={subtitle} />
        <main className="flex-1 p-4 md:p-6">
          {children}
        </main>
      </div>

      {/* Global SOS floating button — always on top */}
      <SOSButton />
    </div>
  );
};

export default AppLayout;
