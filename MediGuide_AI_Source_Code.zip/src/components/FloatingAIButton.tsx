import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const FloatingAIButton: React.FC = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const suggestions = [
    { label: 'Chat with AI', path: '/chat' },
    { label: 'Voice Assistant', path: '/voice' },
    { label: 'Book Appointment', path: '/appointments' },
    { label: 'Find a Doctor', path: '/doctors' },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="bg-card border border-border rounded-xl shadow-hover p-3 flex flex-col gap-1.5 mb-1"
          >
            {suggestions.map(s => (
              <button
                key={s.label}
                onClick={() => { navigate(s.path); setOpen(false); }}
                className="text-sm text-left px-3 py-2 rounded-lg hover:bg-primary/10 hover:text-primary transition-colors whitespace-nowrap"
              >
                {s.label}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setOpen(!open)}
        whileTap={{ scale: 0.95 }}
        className="w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-hover flex items-center justify-center hover:bg-primary/90 transition-colors"
        aria-label="Open AI Assistant"
      >
        {open ? <X className="w-6 h-6" /> : <Bot className="w-6 h-6" />}
      </motion.button>
    </div>
  );
};

export default FloatingAIButton;
