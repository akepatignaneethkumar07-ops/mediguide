import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, X, MapPin, Copy, AlertTriangle, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/db/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relationship: string;
}

const EMERGENCY_SERVICES = [
  { label: 'Ambulance', number: '108', color: 'bg-red-600 hover:bg-red-700', description: 'National Ambulance' },
  { label: 'Emergency', number: '112', color: 'bg-orange-600 hover:bg-orange-700', description: 'Unified Emergency' },
];

const SOSButton: React.FC = () => {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [location, setLocation] = useState<string>('');
  const [loadingLocation, setLoadingLocation] = useState(false);

  useEffect(() => {
    if (!open || !user) return;
    supabase
      .from('emergency_contacts')
      .select('id, name, phone, relationship')
      .eq('user_id', user.id)
      .order('created_at')
      .then(({ data }) => setContacts(data || []));
  }, [open, user]);

  const getLocation = () => {
    if (!navigator.geolocation) {
      setLocation('Geolocation not supported on this device.');
      return;
    }
    setLoadingLocation(true);
    navigator.geolocation.getCurrentPosition(
      pos => {
        const { latitude, longitude } = pos.coords;
        setLocation(`Lat: ${latitude.toFixed(5)}, Lng: ${longitude.toFixed(5)} — https://maps.google.com/?q=${latitude},${longitude}`);
        setLoadingLocation(false);
      },
      () => {
        setLocation('Unable to retrieve location. Please share your address manually.');
        setLoadingLocation(false);
      }
    );
  };

  const copyLocation = () => {
    if (!location) return;
    navigator.clipboard.writeText(location).then(() => toast.success('Location copied!'));
  };

  return (
    <>
      {/* Floating SOS trigger */}
      <motion.button
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.94 }}
        onClick={() => { setOpen(true); getLocation(); }}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-red-600 text-white shadow-lg flex flex-col items-center justify-center gap-0.5 border-2 border-red-400"
        aria-label="Open SOS Emergency"
      >
        <AlertTriangle className="w-5 h-5" />
        <span className="text-[9px] font-bold tracking-wider leading-none">SOS</span>
      </motion.button>

      {/* Overlay + Modal */}
      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop */}
            <motion.div
              key="sos-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
            />

            {/* Modal */}
            <motion.div
              key="sos-modal"
              initial={{ opacity: 0, scale: 0.95, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 16 }}
              transition={{ duration: 0.2 }}
              className="fixed z-50 inset-x-4 bottom-24 md:inset-auto md:bottom-24 md:right-6 md:w-96 bg-card border border-border rounded-2xl shadow-2xl overflow-hidden max-h-[80dvh] flex flex-col"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-5 py-4 border-b border-border bg-red-600/10">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center">
                    <AlertTriangle className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm text-foreground">Emergency Help</p>
                    <p className="text-xs text-muted-foreground">Call for immediate assistance</p>
                  </div>
                </div>
                <button onClick={() => setOpen(false)} className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-muted transition-colors">
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1 p-5 space-y-5">
                {/* Emergency Services */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Emergency Services</p>
                  <div className="grid grid-cols-2 gap-3">
                    {EMERGENCY_SERVICES.map(({ label, number, color, description }) => (
                      <a
                        key={number}
                        href={`tel:${number}`}
                        className={`flex flex-col items-center gap-1.5 py-4 px-3 rounded-xl text-white text-center transition-transform active:scale-95 ${color}`}
                      >
                        <Phone className="w-5 h-5" />
                        <span className="text-xl font-bold leading-none">{number}</span>
                        <span className="text-xs font-medium opacity-90">{label}</span>
                        <span className="text-[10px] opacity-70">{description}</span>
                      </a>
                    ))}
                  </div>
                </div>

                {/* Personal Emergency Contacts */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Your Emergency Contacts</p>
                  {contacts.length === 0 ? (
                    <div className="text-center py-5 border border-dashed border-border rounded-xl">
                      <User className="w-6 h-6 text-muted-foreground mx-auto mb-1.5 opacity-50" />
                      <p className="text-xs text-muted-foreground">No contacts saved</p>
                      <p className="text-[11px] text-muted-foreground/60 mt-0.5">Add contacts in Profile → Emergency Contacts</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {contacts.map(c => (
                        <div key={c.id} className="flex items-center justify-between p-3 rounded-xl border border-border bg-muted/30">
                          <div className="min-w-0">
                            <p className="text-sm font-medium truncate">{c.name}</p>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">{c.relationship || 'Contact'}</Badge>
                              <span className="text-xs text-muted-foreground">{c.phone}</span>
                            </div>
                          </div>
                          <a
                            href={`tel:${c.phone}`}
                            className="ml-3 shrink-0 w-9 h-9 rounded-full bg-green-600 hover:bg-green-700 flex items-center justify-center text-white transition-colors"
                            aria-label={`Call ${c.name}`}
                          >
                            <Phone className="w-4 h-4" />
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Location */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Your Location</p>
                  <div className="rounded-xl border border-border bg-muted/30 p-3 space-y-2">
                    {loadingLocation ? (
                      <p className="text-xs text-muted-foreground">Detecting location…</p>
                    ) : location ? (
                      <>
                        <p className="text-xs text-foreground break-all">{location}</p>
                        <Button size="sm" variant="outline" onClick={copyLocation} className="h-7 text-xs gap-1.5 w-full">
                          <Copy className="w-3 h-3" /> Copy Location
                        </Button>
                      </>
                    ) : (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-muted-foreground shrink-0" />
                        <p className="text-xs text-muted-foreground">Location unavailable</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default SOSButton;
