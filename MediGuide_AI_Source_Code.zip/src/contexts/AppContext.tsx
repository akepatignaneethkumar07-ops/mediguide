import React, { createContext, useContext, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import type { UserRole } from '@/types/types';

interface AppContextType {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  // Legacy shim for pages still referencing useApp().user
  user: { id: string; name: string; email: string; role: UserRole; avatar?: string } | null;
}

const AppContext = createContext<AppContextType>({
  sidebarOpen: false,
  setSidebarOpen: () => {},
  user: null,
});

export const useApp = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { profile } = useAuth();

  const user = profile
    ? { id: profile.id, name: profile.name, email: profile.email, role: profile.role, avatar: profile.avatar_url }
    : null;

  return (
    <AppContext.Provider value={{ sidebarOpen, setSidebarOpen, user }}>
      {children}
    </AppContext.Provider>
  );
};
