export type UserRole = 'patient' | 'doctor' | 'staff' | 'hospital_member' | 'admin';
export type AvailabilityStatus = 'available' | 'busy' | 'offline';
export type ApptStatus = 'pending' | 'confirmed' | 'in-progress' | 'completed' | 'cancelled';
export type ApptType = 'Consultation' | 'Follow-up' | 'Emergency';
export type ReportStatus = 'normal' | 'review' | 'abnormal';
export type ReminderFrequency = 'once-daily' | 'twice-daily' | 'three-daily' | 'as-needed';
export type NotifType = 'appointment' | 'medicine' | 'report' | 'alert' | 'announcement';
export type ChatRole = 'user' | 'assistant';

export interface Profile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar_url?: string;
  phone?: string;
  blood_group?: string;
  address?: string;
  date_of_birth?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  emergency_contact_relation?: string;
  allergies?: string;
  medical_conditions?: string;
  medical_history?: string[];
  bio?: string;
  hospital_id?: string;
  created_at: string;
  updated_at: string;
}

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  department: string;
  experience: number;
  rating: number;
  reviews: number;
  availability: AvailabilityStatus;
  fee: number;
  bio?: string;
  next_slot?: string;
  avatar_url?: string;
  user_id?: string;
  created_at: string;
}

export interface Appointment {
  id: string;
  patient_id: string;
  doctor_id?: string;
  doctor_name: string;
  department: string;
  date: string;
  time: string;
  symptoms?: string;
  status: ApptStatus;
  type: ApptType;
  notes?: string;
  created_at: string;
}

export interface MedicalReport {
  id: string;
  patient_id: string;
  doctor_name: string;
  title: string;
  report_type: string;
  date: string;
  status: ReportStatus;
  summary?: string;
  file_url?: string;
  created_at: string;
}

export interface MedicineReminder {
  id: string;
  patient_id: string;
  name: string;
  dosage: string;
  frequency: ReminderFrequency;
  times: string[];
  taken_today: boolean[];
  color: string;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: NotifType;
  title: string;
  message: string;
  read: boolean;
  created_at: string;
}

export interface ChatMessage {
  id: string;
  user_id: string;
  role: ChatRole;
  content: string;
  created_at: string;
}
