import React from 'react';
import type { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import PatientDashboard from './pages/PatientDashboard';
import AppointmentBooking from './pages/AppointmentBooking';
import AIChatPage from './pages/AIChatPage';
import VoiceAssistantPage from './pages/VoiceAssistantPage';
import DoctorDirectoryPage from './pages/DoctorDirectoryPage';
import MedicalReportsPage from './pages/MedicalReportsPage';
import MedicineReminderPage from './pages/MedicineReminderPage';
import NotificationsPage from './pages/NotificationsPage';
import ProfilePage from './pages/ProfilePage';
import SettingsPage from './pages/SettingsPage';
import StaffDashboard from './pages/StaffDashboard';
import AdminDashboard from './pages/AdminDashboard';
import NotFound from './pages/NotFound';
import EmergencyPage from './pages/EmergencyPage';
import PillScannerPage from './pages/PillScannerPage';
import ReportMakerPage from './pages/ReportMakerPage';
import DietAgentPage from './pages/DietAgentPage';
import HospitalMapPage from './pages/HospitalMapPage';

// Doctor Portal
import DoctorLoginPage from './pages/doctor/DoctorLoginPage';
import DoctorDashboardPage from './pages/doctor/DoctorDashboardPage';
import DoctorAppointmentsPage from './pages/doctor/DoctorAppointmentsPage';
import DoctorPatientsPage from './pages/doctor/DoctorPatientsPage';

// Staff Portal pages
import StaffLoginPage from './pages/staff/StaffLoginPage';
import StaffPortalPage from './pages/staff/StaffPortalPage';

// Hospital Member Portal
import HospitalMemberDashboard from './pages/HospitalMemberDashboard';

import { useAuth } from './contexts/AuthContext';

/** Guard: only role=doctor may access; others go to /doctor-login */
const DoctorGuard: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { profile, loading } = useAuth();
  if (loading) return null;
  if (!profile) return <Navigate to="/doctor-login" replace />;
  if (profile.role !== 'doctor') return <Navigate to="/doctor-login" replace />;
  return <>{children}</>;
};

/** Guard: only role=staff may access; others go to /staff-login */
const StaffGuard: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { profile, loading } = useAuth();
  if (loading) return null;
  if (!profile) return <Navigate to="/staff-login" replace />;
  if (profile.role !== 'staff') return <Navigate to="/staff-login" replace />;
  return <>{children}</>;
};

/** Guard: only role=hospital_member may access; others go to /login */
const HospitalMemberGuard: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { profile, loading } = useAuth();
  if (loading) return null;
  if (!profile) return <Navigate to="/login" replace />;
  if (profile.role !== 'hospital_member') return <Navigate to="/dashboard" replace />;
  return <>{children}</>;
};

export interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
  public?: boolean;
}

export const routes: RouteConfig[] = [
  // Public
  { name: 'Home',    path: '/',       element: <LandingPage />, public: true },
  { name: 'Login',   path: '/login',  element: <AuthPage />,    public: true },
  { name: 'Sign Up', path: '/signup', element: <AuthPage />,    public: true },

  // Doctor Portal
  { name: 'Doctor Login',           path: '/doctor-login',           element: <DoctorLoginPage />, public: true },
  { name: 'Doctor Dashboard',       path: '/doctor-dashboard',       element: <DoctorGuard><DoctorDashboardPage /></DoctorGuard> },
  { name: 'Doctor Appointments',    path: '/doctor-appointments',    element: <DoctorGuard><DoctorAppointmentsPage /></DoctorGuard> },
  { name: 'Doctor Patients',        path: '/doctor-patients',        element: <DoctorGuard><DoctorPatientsPage /></DoctorGuard> },

  // Staff Portal
  { name: 'Staff Login',   path: '/staff-login',   element: <StaffLoginPage />, public: true },
  { name: 'Staff Portal',  path: '/staff-portal',  element: <StaffGuard><StaffPortalPage /></StaffGuard> },

  // Patient Portal
  { name: 'Dashboard',          path: '/dashboard',     element: <PatientDashboard /> },
  { name: 'Appointments',       path: '/appointments',  element: <AppointmentBooking /> },
  { name: 'AI Assistant',       path: '/chat',          element: <AIChatPage /> },
  { name: 'Voice Assistant',    path: '/voice',         element: <VoiceAssistantPage /> },
  { name: 'Doctors',            path: '/doctors',       element: <DoctorDirectoryPage /> },
  { name: 'Hospital Locations', path: '/hospital-map',  element: <HospitalMapPage /> },
  { name: 'Reports',            path: '/reports',       element: <MedicalReportsPage /> },
  { name: 'Medicine Reminders', path: '/reminders',     element: <MedicineReminderPage /> },
  { name: 'Emergency',          path: '/emergency',     element: <EmergencyPage /> },
  { name: 'Pill Scanner',       path: '/pill-scanner',  element: <PillScannerPage /> },
  { name: 'Report Maker',       path: '/report-maker',  element: <ReportMakerPage /> },
  { name: 'Diet & Health Agent',path: '/diet',          element: <DietAgentPage /> },
  { name: 'Notifications',      path: '/notifications', element: <NotificationsPage /> },
  { name: 'Profile',            path: '/profile',       element: <ProfilePage /> },
  { name: 'Settings',           path: '/settings',      element: <SettingsPage /> },

  // Hospital Member Portal
  { name: 'Hospital Member Dashboard', path: '/hospital-member-dashboard', element: <HospitalMemberGuard><HospitalMemberDashboard /></HospitalMemberGuard> },

  // Staff & Admin (legacy)
  { name: 'Staff Dashboard', path: '/staff-dashboard', element: <StaffDashboard /> },
  { name: 'Admin Dashboard', path: '/admin-dashboard', element: <AdminDashboard /> },

  // 404
  { name: 'Not Found', path: '/404', element: <NotFound />, public: true },
];
